# FactoryCharge — المرحلة 1: الأساس

مشروع Android واحد يحتوي على:

| الموديول | الدور | المعرّف |
|---|---|---|
| `app-admin` | تطبيق المسؤول | `com.factorycharge.admin` |
| `app-client` | تطبيق العميل | `com.factorycharge.client` |
| `core-common` | نماذج بيانات، تصميم موحد، عقد اتصال (واجهات فقط) | `com.factorycharge.core` |

## القرارات
- Kotlin + Jetpack Compose + Material 3 + Room (قاعدة مستقلة لكل تطبيق).
- لا Firebase ولا Supabase ولا Backend ولا خدمات سحابية.
- هاتف المسؤول هو المصدر الوحيد الموثوق للأرصدة والمديونيات والأسعار وحالة الطلبات.
- تطبيق العميل لا يحتوي جدول قيود مالية. حراس `DeviceRole` و`require` حراس برمجية فقط وليست حماية أمنية (انظر `docs/DESIGN-NOTES.md`).
- `allowBackup=false` في التطبيقين حتى لا تُنسخ البيانات إلى أي خدمة سحابية تلقائياً.

## البناء
GitHub Actions (`.github/workflows/android-debug.yml`) يبني كل تطبيق في Job مستقل، يشغّل الاختبارات، ثم يرفع
APK الـ Debug كـ Artifact باسم `factorycharge-admin-debug` و`factorycharge-client-debug`.
لا يوجد `gradlew` في المستودع؛ الـ Workflow يثبّت Gradle 8.9 وSDK platform 35 وbuild-tools 34.0.0 مباشرة.
بعد أول بناء: أودع ملفات `schemas/` من Artifacts المسماة `room-schema-*`.

## خارج نطاق المرحلة 1 (عمداً)
Mesh Relay، المزامنة المالية، إنشاء الطلبات، إدارة العملاء، أي تنفيذ فعلي لـ `DeviceTransport`.
