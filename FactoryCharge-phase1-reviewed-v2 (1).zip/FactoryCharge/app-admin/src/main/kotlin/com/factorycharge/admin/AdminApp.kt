package com.factorycharge.admin

import android.app.Application
import com.factorycharge.admin.data.AdminDatabase

class AdminApp : Application() {
    val database: AdminDatabase by lazy { AdminDatabase.build(this) }
}
