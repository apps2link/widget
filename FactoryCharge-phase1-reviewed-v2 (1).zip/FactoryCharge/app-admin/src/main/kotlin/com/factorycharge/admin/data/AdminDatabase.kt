package com.factorycharge.admin.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters

/**
 * قاعدة بيانات المسؤول (المصدر الوحيد للقيود المالية).
 *
 * سياسة الإصدارات:
 * - الإصدار 1 لم يُنشر بعد، لذلك عدّلنا مخططه قبل تجميد أول ملف schema.
 *   بعد إيداع `schemas/.../1.json` في Git، أي تغيير في الكيانات يتطلب رفع `version`
 *   وإضافة `Migration` صريحة. ممنوع `fallbackToDestructiveMigration`.
 * - إن ثبّتَّ APK تجريبياً سابقاً على الهاتف فاحذفه قبل تثبيت هذه النسخة
 *   (تغيّر المخطط داخل الإصدار 1 فيرفضه Room بسبب اختلاف الـ hash).
 */
@Database(
    entities = [CustomerEntity::class, ChargeRequestEntity::class, TransactionEntity::class],
    version = 1,
    exportSchema = true,
)
@TypeConverters(Converters::class)
abstract class AdminDatabase : RoomDatabase() {
    abstract fun customerDao(): CustomerDao
    abstract fun chargeRequestDao(): ChargeRequestDao
    abstract fun transactionDao(): TransactionDao

    companion object {
        /** بدون fallbackToDestructiveMigration عمداً: لا نحذف بيانات مالية بصمت. */
        fun build(context: Context): AdminDatabase =
            Room.databaseBuilder(context.applicationContext, AdminDatabase::class.java, "factorycharge_admin.db")
                .build()
    }
}
