package com.factorycharge.admin.data

import androidx.room.TypeConverter
import com.factorycharge.core.model.NetworkProvider
import com.factorycharge.core.model.RequestStatus
import com.factorycharge.core.model.ServiceType
import com.factorycharge.core.model.TransactionType

class Converters {
    @TypeConverter fun providerToString(v: NetworkProvider): String = v.name
    @TypeConverter fun stringToProvider(v: String): NetworkProvider = NetworkProvider.valueOf(v)

    @TypeConverter fun serviceToString(v: ServiceType): String = v.name
    @TypeConverter fun stringToService(v: String): ServiceType = ServiceType.valueOf(v)

    @TypeConverter fun statusToString(v: RequestStatus): String = v.name
    @TypeConverter fun stringToStatus(v: String): RequestStatus = RequestStatus.valueOf(v)

    @TypeConverter fun transactionTypeToString(v: TransactionType): String = v.name
    @TypeConverter fun stringToTransactionType(v: String): TransactionType = TransactionType.valueOf(v)
}
