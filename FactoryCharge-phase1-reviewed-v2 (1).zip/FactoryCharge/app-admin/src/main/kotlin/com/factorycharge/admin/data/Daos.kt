package com.factorycharge.admin.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface CustomerDao {
    @Query("SELECT COUNT(*) FROM customers")
    fun observeCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(customer: CustomerEntity)
}

@Dao
interface ChargeRequestDao {
    /** الأسماء هنا يجب أن تطابق RequestStatus.SUBMITTED و UNDER_REVIEW. */
    @Query("SELECT COUNT(*) FROM charge_requests WHERE status IN ('SUBMITTED', 'UNDER_REVIEW')")
    fun observePendingReviewCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(request: ChargeRequestEntity)
}

@Dao
interface TransactionDao {
    // لا يوجد هنا منطق مالي عمداً. الإدراج الفعلي سيمر لاحقاً عبر طبقة معاملات معتمدة
    // تولّد sequence وتتحقق من الطلب داخل معاملة Room واحدة.
    @Query("SELECT COUNT(*) FROM transactions")
    fun observeCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(transaction: TransactionEntity)
}
