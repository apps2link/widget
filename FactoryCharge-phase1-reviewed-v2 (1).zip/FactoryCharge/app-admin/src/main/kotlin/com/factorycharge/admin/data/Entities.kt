package com.factorycharge.admin.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.factorycharge.core.model.NetworkProvider
import com.factorycharge.core.model.RequestStatus
import com.factorycharge.core.model.ServiceType
import com.factorycharge.core.model.TransactionType

@Entity(tableName = "customers")
data class CustomerEntity(
    @PrimaryKey val id: String,
    val displayName: String,
    val phone: String,
    val createdAtMillis: Long,
    val isActive: Boolean,
)

@Entity(
    tableName = "charge_requests",
    foreignKeys = [
        ForeignKey(
            entity = CustomerEntity::class,
            parentColumns = ["id"],
            childColumns = ["customerId"],
            onDelete = ForeignKey.RESTRICT,
        ),
    ],
    indices = [Index("customerId"), Index("status")],
)
data class ChargeRequestEntity(
    @PrimaryKey val id: String,
    val customerId: String,
    val provider: NetworkProvider,
    val serviceType: ServiceType,
    val targetPhone: String,
    val amountMinor: Long,
    val status: RequestStatus,
    val createdAtMillis: Long,
    val updatedAtMillis: Long,
    val note: String?,
)

/**
 * القيود المعتمدة: تُنشأ على جهاز المسؤول فقط.
 *
 * قرارات التصميم (مقترحة، وتُثبَّت نهائياً في مرحلة التصميم المالي):
 * - [sequence] **عالمي على مستوى دفتر المسؤول كله** وليس لكل عميل: المسؤول هو الكاتب الوحيد،
 *   فيكفي عدّاد واحد ويعطي ترتيباً كلياً واضحاً. الترتيب الخاص بعميل يُشتق بالاستعلام
 *   (`WHERE customerId = ? ORDER BY sequence`). الفهرس الفريد يمنع تكرار الرقم فقط؛
 *   لا يضمن غياب الثغرات، ولا يولّد الرقم. توليده يجب أن يتم لاحقاً داخل معاملة Room واحدة
 *   مع كتابة القيد نفسه.
 * - [requestId] له فهرس **فريد**: لا يُسجَّل أكثر من قيد واحد لنفس ChargeRequest، ويرفض SQLite
 *   المحاولة الثانية بـ SQLiteConstraintException. القيم NULL مسموحة وغير متعارضة في الفهرس
 *   الفريد (للقيود غير المرتبطة بطلب). التسويات والعكس ستكون قيوداً منفصلة بتصميم يُحدَّد لاحقاً
 *   (ولا تعيد استخدام requestId).
 * - المفاتيح الأجنبية RESTRICT: لا يُحذف عميل أو طلب له قيود.
 * - قيد "المبلغ موجب" يفرضه نموذج [com.factorycharge.core.model.TransactionRecord] لا قاعدة البيانات.
 */
@Entity(
    tableName = "transactions",
    foreignKeys = [
        ForeignKey(
            entity = CustomerEntity::class,
            parentColumns = ["id"],
            childColumns = ["customerId"],
            onDelete = ForeignKey.RESTRICT,
        ),
        ForeignKey(
            entity = ChargeRequestEntity::class,
            parentColumns = ["id"],
            childColumns = ["requestId"],
            onDelete = ForeignKey.RESTRICT,
        ),
    ],
    indices = [
        Index(value = ["customerId", "sequence"]),
        Index(value = ["sequence"], unique = true),
        Index(value = ["requestId"], unique = true),
    ],
)
data class TransactionEntity(
    @PrimaryKey val id: String,
    val customerId: String,
    val type: TransactionType,
    val amountMinor: Long,
    val requestId: String?,
    val sequence: Long,
    val createdAtMillis: Long,
)
