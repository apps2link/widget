package com.factorycharge.admin.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.res.stringResource
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.factorycharge.admin.R
import com.factorycharge.admin.ui.AdminHomeScreen
import com.factorycharge.core.design.OnboardingScreen

object AdminRoutes {
    const val ONBOARDING = "onboarding"
    const val HOME = "home"
}

@Composable
fun AdminNavHost(
    onboardingDone: Boolean,
    onOnboardingFinished: () -> Unit,
) {
    val navController = rememberNavController()
    NavHost(
        navController = navController,
        startDestination = if (onboardingDone) AdminRoutes.HOME else AdminRoutes.ONBOARDING,
    ) {
        composable(AdminRoutes.ONBOARDING) {
            OnboardingScreen(
                roleLabel = stringResource(R.string.onboarding_role),
                title = stringResource(R.string.onboarding_title),
                description = stringResource(R.string.onboarding_description),
                points = listOf(
                    stringResource(R.string.onboarding_point_1),
                    stringResource(R.string.onboarding_point_2),
                    stringResource(R.string.onboarding_point_3),
                ),
                continueLabel = stringResource(R.string.onboarding_start),
                onContinue = {
                    onOnboardingFinished()
                    navController.navigate(AdminRoutes.HOME) {
                        popUpTo(AdminRoutes.ONBOARDING) { inclusive = true }
                    }
                },
            )
        }
        composable(AdminRoutes.HOME) {
            AdminHomeScreen()
        }
    }
}
