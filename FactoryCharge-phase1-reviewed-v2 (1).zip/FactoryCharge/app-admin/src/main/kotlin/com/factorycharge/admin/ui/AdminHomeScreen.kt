package com.factorycharge.admin.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.factorycharge.admin.R
import com.factorycharge.core.design.EmptyState
import com.factorycharge.core.design.ErrorState
import com.factorycharge.core.design.InfoBanner
import com.factorycharge.core.design.LoadingState
import com.factorycharge.core.design.StatCard
import com.factorycharge.core.design.UiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminHomeScreen(
    viewModel: AdminHomeViewModel = viewModel(factory = AdminHomeViewModel.Factory),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(title = { Text(stringResource(R.string.home_title)) })
        },
    ) { padding ->
        Box(modifier = Modifier.padding(padding).fillMaxSize()) {
            when (val s = state) {
                UiState.Loading -> LoadingState()
                is UiState.Error -> ErrorState(onRetry = viewModel::load)
                is UiState.Success -> AdminHomeContent(s.data)
            }
        }
    }
}

@Composable
private fun AdminHomeContent(data: AdminHomeData) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        InfoBanner(
            text = stringResource(R.string.home_trust_banner),
            icon = Icons.Default.Lock,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard(
                label = stringResource(R.string.stat_customers),
                value = data.customers.toString(),
                icon = Icons.Default.Person,
                modifier = Modifier.weight(1f),
            )
            StatCard(
                label = stringResource(R.string.stat_pending_requests),
                value = data.pendingRequests.toString(),
                icon = Icons.Default.Notifications,
                modifier = Modifier.weight(1f),
            )
        }
        StatCard(
            label = stringResource(R.string.stat_transactions),
            value = data.transactions.toString(),
            icon = Icons.AutoMirrored.Filled.List,
            modifier = Modifier.fillMaxWidth(),
        )
        if (data.customers == 0) {
            EmptyState(
                icon = Icons.Default.Person,
                title = stringResource(R.string.empty_customers_title),
                message = stringResource(R.string.empty_customers_message),
            )
        }
    }
}
