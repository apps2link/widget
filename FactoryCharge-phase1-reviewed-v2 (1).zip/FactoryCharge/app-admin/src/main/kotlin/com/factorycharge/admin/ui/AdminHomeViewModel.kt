package com.factorycharge.admin.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.factorycharge.admin.AdminApp
import com.factorycharge.admin.data.AdminDatabase
import com.factorycharge.core.design.UiState
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

data class AdminHomeData(
    val customers: Int,
    val pendingRequests: Int,
    val transactions: Int,
)

class AdminHomeViewModel(private val database: AdminDatabase) : ViewModel() {

    private val _state = MutableStateFlow<UiState<AdminHomeData>>(UiState.Loading)
    val state: StateFlow<UiState<AdminHomeData>> = _state.asStateFlow()

    private var loadJob: Job? = null

    init {
        load()
    }

    fun load() {
        loadJob?.cancel()
        _state.value = UiState.Loading
        loadJob = viewModelScope.launch {
            combine(
                database.customerDao().observeCount(),
                database.chargeRequestDao().observePendingReviewCount(),
                database.transactionDao().observeCount(),
            ) { customers, pending, transactions ->
                AdminHomeData(customers, pending, transactions)
            }
                .catch { _state.value = UiState.Error(it) }
                .collect { _state.value = UiState.Success(it) }
        }
    }

    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                AdminHomeViewModel((this[APPLICATION_KEY] as AdminApp).database)
            }
        }
    }
}
