package com.factorycharge.admin

import com.factorycharge.admin.data.Converters
import com.factorycharge.core.model.NetworkProvider
import com.factorycharge.core.model.RequestStatus
import com.factorycharge.core.model.ServiceType
import com.factorycharge.core.model.TransactionType
import org.junit.Assert.assertEquals
import org.junit.Test

class ConvertersTest {
    private val c = Converters()

    @Test
    fun enumsRoundTrip() {
        NetworkProvider.entries.forEach { assertEquals(it, c.stringToProvider(c.providerToString(it))) }
        ServiceType.entries.forEach { assertEquals(it, c.stringToService(c.serviceToString(it))) }
        RequestStatus.entries.forEach { assertEquals(it, c.stringToStatus(c.statusToString(it))) }
        TransactionType.entries.forEach { assertEquals(it, c.stringToTransactionType(c.transactionTypeToString(it))) }
    }

    /** الاستعلام في ChargeRequestDao يستخدم هذه الأسماء كنصوص ثابتة. */
    @Test
    fun pendingReviewQueryNamesMatchEnum() {
        assertEquals("SUBMITTED", RequestStatus.SUBMITTED.name)
        assertEquals("UNDER_REVIEW", RequestStatus.UNDER_REVIEW.name)
    }
}
