package com.factorycharge.core.util

import java.math.BigDecimal

object Money {
    /**
     * يعرض المبلغ المخزَّن بأصغر وحدة. يفترض منزلتين عشريتين (قرش لكل 100).
     * إن احتجنا عملة بعدد منازل مختلف نوسّع هذه الدالة لاحقاً.
     */
    fun format(amountMinor: Long, currencyCode: String): String =
        "${BigDecimal.valueOf(amountMinor, 2).toPlainString()} $currencyCode"
}
