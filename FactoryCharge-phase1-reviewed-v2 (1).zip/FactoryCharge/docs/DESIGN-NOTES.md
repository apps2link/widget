# ملاحظات التصميم (المرحلة 1 بعد المراجعة)

## 1) نموذج الثقة
- هاتف المسؤول هو المصدر الوحيد للقيود المالية وحالة الطلبات المعتمدة.
- `DeviceRole` و`RequestStatus.canTransitionTo` و`require` في `TransactionRecord` **حراس برمجية** تكشف أخطاء الاستخدام داخل كودنا. ليست نظام صلاحيات، ولا تمنع جهازاً معدَّلاً أو رسالة مزوّرة من ادعاء أي دور.
- الحماية الفعلية مؤجلة لمرحلة الأمان: هوية الأجهزة، التوقيع، منع إعادة الإرسال، وتحقق المسؤول من كل ما يصله. حتى ذلك الحين لا يُرسل أي شيء مالي بين الأجهزة.
- نسخة الحساب `wallet_snapshot` عند العميل كاش للعرض غير موثَّق ولا تُبنى عليه أي عملية.

## 2) قاعدة بيانات المسؤول
| الجدول | قيود/فهارس |
|---|---|
| `customers` | PK = id |
| `charge_requests` | FK→customers (RESTRICT)، فهرس customerId وstatus |
| `transactions` | FK→customers وFK→charge_requests (RESTRICT)، فهرس (customerId, sequence)، **فريد** sequence، **فريد** requestId |

- `sequence` **عالمي** على مستوى دفتر المسؤول، لا لكل عميل. الفهرس الفريد يمنع التكرار فقط ولا يولّد الرقم ولا يمنع الثغرات؛ التوليد يتم لاحقاً داخل معاملة Room واحدة.
- الفهرس الفريد على `requestId` يمنع تسجيل أكثر من قيد لنفس الطلب (NULL مسموح لقيود غير مرتبطة بطلب). التسويات/العكس تصميمها لاحق ولن تعيد استخدام `requestId`.
- لا يوجد منطق مالي: DAO فيه إدراج خام فقط.

## 3) سياسة Room
- `exportSchema = true` وملفات schema في `app-admin/schemas` و`app-client/schemas` عبر Room Gradle Plugin.
- بعد أول بناء ناجح: نزّل Artifact باسم `room-schema-admin` و`room-schema-client` وأودع الملفات في Git.
- بعد إيداعها: أي تغيير في الكيانات = رفع `version` + `Migration` صريحة. الـ Workflow يفشل إن تغيّر schema مودَع دون ذلك.
- ممنوع `fallbackToDestructiveMigration`.
- الإصدار 1 عُدِّل قبل أي إيداع schema؛ احذف أي APK تجريبي قديم من هاتف المسؤول قبل التثبيت.
