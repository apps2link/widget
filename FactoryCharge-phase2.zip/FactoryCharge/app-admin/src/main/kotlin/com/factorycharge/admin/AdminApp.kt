package com.factorycharge.admin

import android.app.Application
import com.factorycharge.admin.data.AdminDatabase
import com.factorycharge.admin.data.FinancialRepository

class AdminApp : Application() {
    val database: AdminDatabase by lazy { AdminDatabase.build(this) }
    val repository: FinancialRepository by lazy { FinancialRepository(database) }
}
