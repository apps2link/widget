package com.factorycharge.admin

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.remember
import com.factorycharge.admin.navigation.AdminNavHost
import com.factorycharge.core.design.FactoryChargeTheme
import com.factorycharge.core.prefs.OnboardingPrefs

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            FactoryChargeTheme {
                val prefs = remember { OnboardingPrefs(applicationContext, "admin_prefs") }
                val alreadyDone = remember { prefs.isDone }
                AdminNavHost(
                    onboardingDone = alreadyDone,
                    onOnboardingFinished = prefs::markDone,
                )
            }
        }
    }
}
