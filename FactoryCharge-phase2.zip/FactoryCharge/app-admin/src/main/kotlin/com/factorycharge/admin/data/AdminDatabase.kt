package com.factorycharge.admin.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters

/**
 * قاعدة بيانات المسؤول (المصدر الوحيد للقيود المالية).
 *
 * سياسة الإصدارات:
 * - الإصدار 1 لم يُنشر بعد، لذلك عُدِّل مخططه في المرحلة 2 (جداول الدفتر والعملاء).
 *   إن كنتَ أودعتَ `schemas/.../1.json` من المرحلة 1 أو ثبّتَّ APK سابقاً فاحذفهما (ملف schema القديم
 *   والتطبيق من الهاتف) ثم أعد البناء. بعد إيداع schema الجديد: أي تغيير يتطلب رفع `version` + `Migration`.
 * - ممنوع `fallbackToDestructiveMigration`.
 */
@Database(
    entities = [CustomerEntity::class, ChargeRequestEntity::class, LedgerEntryEntity::class],
    version = 1,
    exportSchema = true,
)
@TypeConverters(Converters::class)
abstract class AdminDatabase : RoomDatabase() {
    abstract fun customerDao(): CustomerDao
    abstract fun chargeRequestDao(): ChargeRequestDao
    abstract fun ledgerDao(): LedgerDao

    companion object {
        /** بدون fallbackToDestructiveMigration عمداً: لا نحذف بيانات مالية بصمت. */
        fun build(context: Context): AdminDatabase =
            Room.databaseBuilder(context.applicationContext, AdminDatabase::class.java, "factorycharge_admin.db")
                .addCallback(LedgerTriggers.callback)
                .build()
    }
}
