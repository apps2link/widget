package com.factorycharge.admin.data

import androidx.room.Dao
import androidx.room.Embedded
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

/** عميل مع رصيده ومديونيته المحسوبين من مجموع قيود الدفتر. */
data class CustomerWithBalances(
    @Embedded val customer: CustomerEntity,
    val balanceMinor: Long,
    val debtMinor: Long,
)

/** مجاميع الدفتر (لعميل واحد أو للكل). */
data class LedgerTotals(
    val totalBalanceMinor: Long,
    val totalDebtMinor: Long,
)

@Dao
interface CustomerDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(customer: CustomerEntity)

    @Query("SELECT * FROM customers WHERE id = :id")
    suspend fun getById(id: String): CustomerEntity?

    @Query("UPDATE customers SET displayName = :name, phone = :phone WHERE id = :id")
    suspend fun updateProfile(id: String, name: String, phone: String): Int

    @Query("UPDATE customers SET isActive = :active WHERE id = :id")
    suspend fun setActive(id: String, active: Boolean): Int

    @Query("UPDATE customers SET creditLimitMinor = :limitMinor WHERE id = :id")
    suspend fun setCreditLimit(id: String, limitMinor: Long): Int

    @Query("SELECT COUNT(*) FROM customers")
    fun observeCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM customers WHERE isActive = 1")
    fun observeActiveCount(): Flow<Int>

    /** [query] يجب أن يكون مُهرَّباً (escape بالرمز !) من المستودع. */
    @Query(
        """
        SELECT c.*,
               COALESCE(SUM(l.balanceDeltaMinor), 0) AS balanceMinor,
               COALESCE(SUM(l.debtDeltaMinor), 0) AS debtMinor
        FROM customers AS c
        LEFT JOIN ledger_entries AS l ON l.customerId = c.id
        WHERE (:query = ''
               OR c.displayName LIKE '%' || :query || '%' ESCAPE '!'
               OR c.phone LIKE '%' || :query || '%' ESCAPE '!')
        GROUP BY c.id
        ORDER BY c.displayName COLLATE NOCASE
        """,
    )
    fun observeWithBalances(query: String): Flow<List<CustomerWithBalances>>

    @Query(
        """
        SELECT c.*,
               COALESCE(SUM(l.balanceDeltaMinor), 0) AS balanceMinor,
               COALESCE(SUM(l.debtDeltaMinor), 0) AS debtMinor
        FROM customers AS c
        LEFT JOIN ledger_entries AS l ON l.customerId = c.id
        WHERE c.id = :id
        GROUP BY c.id
        """,
    )
    fun observeWithBalancesById(id: String): Flow<CustomerWithBalances?>
}

@Dao
interface LedgerDao {
    /** الإدراج هو العملية الكتابية الوحيدة على الدفتر. لا تعديل ولا حذف. */
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(entry: LedgerEntryEntity)

    @Query("SELECT COALESCE(MAX(sequence), 0) FROM ledger_entries")
    suspend fun maxSequence(): Long

    @Query("SELECT COUNT(*) FROM ledger_entries WHERE operationId = :operationId")
    suspend fun countByOperation(operationId: String): Int

    @Query("SELECT COUNT(*) FROM ledger_entries WHERE reversesEntryId = :entryId")
    suspend fun countReversalsOf(entryId: String): Int

    @Query("SELECT * FROM ledger_entries WHERE id = :id")
    suspend fun getById(id: String): LedgerEntryEntity?

    @Query(
        """
        SELECT COALESCE(SUM(balanceDeltaMinor), 0) AS totalBalanceMinor,
               COALESCE(SUM(debtDeltaMinor), 0) AS totalDebtMinor
        FROM ledger_entries WHERE customerId = :customerId
        """,
    )
    suspend fun getTotals(customerId: String): LedgerTotals

    @Query(
        """
        SELECT COALESCE(SUM(balanceDeltaMinor), 0) AS totalBalanceMinor,
               COALESCE(SUM(debtDeltaMinor), 0) AS totalDebtMinor
        FROM ledger_entries
        """,
    )
    fun observeAllTotals(): Flow<LedgerTotals>

    /** الأقدم أولاً (للتحقق والاختبار). */
    @Query("SELECT * FROM ledger_entries WHERE customerId = :customerId ORDER BY sequence ASC")
    suspend fun listForCustomer(customerId: String): List<LedgerEntryEntity>

    /** كشف الحساب: الأحدث أولاً، بالترتيب المتسلسل لا بالتوقيت (الساعة قد تتغير). */
    @Query("SELECT * FROM ledger_entries WHERE customerId = :customerId ORDER BY sequence DESC")
    fun observeStatement(customerId: String): Flow<List<LedgerEntryEntity>>

    @Query("SELECT COUNT(*) FROM ledger_entries")
    suspend fun count(): Int
}

@Dao
interface ChargeRequestDao {
    /** الأسماء هنا يجب أن تطابق RequestStatus.SUBMITTED و UNDER_REVIEW. */
    @Query("SELECT COUNT(*) FROM charge_requests WHERE status IN ('SUBMITTED', 'UNDER_REVIEW')")
    fun observePendingReviewCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(request: ChargeRequestEntity)
}
