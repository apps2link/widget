package com.factorycharge.admin.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.factorycharge.core.ledger.LedgerEntryType
import com.factorycharge.core.ledger.OperationKind
import com.factorycharge.core.model.NetworkProvider
import com.factorycharge.core.model.RequestStatus
import com.factorycharge.core.model.ServiceType

/**
 * عميل. [id] معرّف ثابت (UUID) لا يتغير أبداً. الرصيد والمديونية **غير مخزَّنين** هنا؛
 * يُحسبان دائماً من مجموع قيود الدفتر. [creditLimitMinor] إعداد (سياسة) وليس رصيداً.
 * رقم الهاتف فريد لمنع تكرار العميل.
 */
@Entity(
    tableName = "customers",
    indices = [Index(value = ["phone"], unique = true)],
)
data class CustomerEntity(
    @PrimaryKey val id: String,
    val displayName: String,
    val phone: String,
    val createdAtMillis: Long,
    val isActive: Boolean,
    val creditLimitMinor: Long,
)

@Entity(
    tableName = "charge_requests",
    foreignKeys = [
        ForeignKey(
            entity = CustomerEntity::class,
            parentColumns = ["id"],
            childColumns = ["customerId"],
            onDelete = ForeignKey.RESTRICT,
        ),
    ],
    indices = [Index("customerId"), Index("status")],
)
data class ChargeRequestEntity(
    @PrimaryKey val id: String,
    val customerId: String,
    val provider: NetworkProvider,
    val serviceType: ServiceType,
    val targetPhone: String,
    val amountMinor: Long,
    val status: RequestStatus,
    val createdAtMillis: Long,
    val updatedAtMillis: Long,
    val note: String?,
)

/**
 * قيد في الدفتر (append-only). لا يُعدَّل ولا يُحذف أبداً: يمنع ذلك Triggers في SQLite
 * (انظر [LedgerTriggers]) ولا يوجد أي DAO للتعديل أو الحذف. التصحيح = قيد جديد من نوع REVERSAL.
 *
 * - [operationId]: معرّف العملية (مفتاح عدم التكرار). قيود العملية الواحدة تتشارك المعرّف وتُرقَّم بـ [lineNo].
 * - [sequence]: رقم عالمي متسلسل بلا ثغرات على مستوى الدفتر كله (يفرضه Trigger).
 * - [balanceDeltaMinor] / [debtDeltaMinor]: الأثر الموقَّع؛ واحد منهما فقط غير صفري.
 * - [balanceAfterMinor] / [debtAfterMinor]: الرصيد/المديونية بعد القيد (يتحقق منها Trigger مقابل مجموع الدفتر).
 * - [reversesEntryId]: للقيد العكسي فقط، وفريد: القيد يُعكس مرة واحدة.
 */
@Entity(
    tableName = "ledger_entries",
    foreignKeys = [
        ForeignKey(
            entity = CustomerEntity::class,
            parentColumns = ["id"],
            childColumns = ["customerId"],
            onDelete = ForeignKey.RESTRICT,
        ),
        ForeignKey(
            entity = LedgerEntryEntity::class,
            parentColumns = ["id"],
            childColumns = ["reversesEntryId"],
            onDelete = ForeignKey.RESTRICT,
        ),
    ],
    indices = [
        Index(value = ["sequence"], unique = true),
        Index(value = ["operationId", "lineNo"], unique = true),
        Index(value = ["customerId", "sequence"]),
        Index(value = ["reversesEntryId"], unique = true),
    ],
)
data class LedgerEntryEntity(
    @PrimaryKey val id: String,
    val operationId: String,
    val lineNo: Int,
    val customerId: String,
    val type: LedgerEntryType,
    val operationKind: OperationKind,
    val amountMinor: Long,
    val balanceDeltaMinor: Long,
    val debtDeltaMinor: Long,
    val balanceAfterMinor: Long,
    val debtAfterMinor: Long,
    val sequence: Long,
    val createdAtMillis: Long,
    val description: String?,
    val reversesEntryId: String?,
)
