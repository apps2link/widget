package com.factorycharge.admin.data

import android.database.sqlite.SQLiteConstraintException
import androidx.room.withTransaction
import com.factorycharge.core.ledger.AccountState
import com.factorycharge.core.ledger.CustomerError
import com.factorycharge.core.ledger.LedgerRules
import com.factorycharge.core.ledger.OperationKind
import com.factorycharge.core.ledger.OperationRejection
import com.factorycharge.core.ledger.PlanResult
import com.factorycharge.core.ledger.Posting
import com.factorycharge.core.util.PhoneNumber
import kotlinx.coroutines.flow.Flow
import java.util.UUID

sealed interface OperationOutcome {
    /** سُجّلت كل قيود العملية في الدفتر في معاملة واحدة. */
    data class Recorded(
        val entries: List<LedgerEntryEntity>,
        val resulting: AccountState,
    ) : OperationOutcome

    /** رُفضت العملية ولم يُكتب أي شيء في الدفتر. */
    data class Rejected(val reason: OperationRejection) : OperationOutcome
}

sealed interface CustomerResult {
    data class Saved(val customerId: String) : CustomerResult
    data class Failed(val error: CustomerError) : CustomerResult
}

/**
 * المكان الوحيد الذي يكتب في الدفتر. كل عملية مالية = معاملة Room واحدة (all-or-nothing):
 * فحص التكرار + قراءة الحالة + تخطيط القيود + إدراجها. القواعد الحسابية في [LedgerRules].
 *
 * معاملات الإنشاء:
 * [afterEntryInserted] نقطة اختبار فقط: تُستدعى بعد إدراج كل قيد داخل المعاملة، ليتمكن الاختبار
 * من إفشال العملية في المنتصف والتأكد من التراجع الكامل. القيمة الافتراضية لا تفعل شيئاً.
 */
class FinancialRepository(
    private val db: AdminDatabase,
    private val nowMillis: () -> Long = { System.currentTimeMillis() },
    private val newId: () -> String = { UUID.randomUUID().toString() },
    private val afterEntryInserted: (index: Int) -> Unit = {},
) {
    private val customers get() = db.customerDao()
    private val ledger get() = db.ledgerDao()

    // ---------------------------------------------------------------- العملاء

    suspend fun addCustomer(name: String, phone: String, creditLimitMinor: Long = 0L): CustomerResult {
        val cleanName = cleanName(name) ?: return CustomerResult.Failed(CustomerError.INVALID_NAME)
        val cleanPhone = PhoneNumber.normalize(phone) ?: return CustomerResult.Failed(CustomerError.INVALID_PHONE)
        if (creditLimitMinor < 0) return CustomerResult.Failed(CustomerError.NEGATIVE_LIMIT)
        val id = newId()
        return try {
            customers.insert(
                CustomerEntity(
                    id = id,
                    displayName = cleanName,
                    phone = cleanPhone,
                    createdAtMillis = nowMillis(),
                    isActive = true,
                    creditLimitMinor = creditLimitMinor,
                ),
            )
            CustomerResult.Saved(id)
        } catch (e: SQLiteConstraintException) {
            CustomerResult.Failed(CustomerError.DUPLICATE_PHONE)
        }
    }

    suspend fun updateCustomer(id: String, name: String, phone: String): CustomerResult {
        val cleanName = cleanName(name) ?: return CustomerResult.Failed(CustomerError.INVALID_NAME)
        val cleanPhone = PhoneNumber.normalize(phone) ?: return CustomerResult.Failed(CustomerError.INVALID_PHONE)
        return try {
            if (customers.updateProfile(id, cleanName, cleanPhone) == 0) {
                CustomerResult.Failed(CustomerError.NOT_FOUND)
            } else {
                CustomerResult.Saved(id)
            }
        } catch (e: SQLiteConstraintException) {
            CustomerResult.Failed(CustomerError.DUPLICATE_PHONE)
        }
    }

    suspend fun setCustomerActive(id: String, active: Boolean): CustomerResult =
        if (customers.setActive(id, active) == 0) CustomerResult.Failed(CustomerError.NOT_FOUND) else CustomerResult.Saved(id)

    /** لا يُقبل حد أقل من المديونية الحالية (للإيقاف الفعلي للائتمان اجعله مساوياً لها). */
    suspend fun setCreditLimit(id: String, limitMinor: Long): CustomerResult {
        if (limitMinor < 0) return CustomerResult.Failed(CustomerError.NEGATIVE_LIMIT)
        return db.withTransaction<CustomerResult> {
            if (customers.getById(id) == null) return@withTransaction CustomerResult.Failed(CustomerError.NOT_FOUND)
            if (limitMinor < ledger.getTotals(id).totalDebtMinor) {
                return@withTransaction CustomerResult.Failed(CustomerError.LIMIT_BELOW_DEBT)
            }
            customers.setCreditLimit(id, limitMinor)
            CustomerResult.Saved(id)
        }
    }

    suspend fun getCustomer(id: String): CustomerEntity? = customers.getById(id)

    // ---------------------------------------------------------------- العمليات المالية

    /** إيداع نقدي: تسوية المديونية أولاً ثم الباقي للمحفظة، في معاملة واحدة. */
    suspend fun deposit(customerId: String, amountMinor: Long, operationId: String, description: String? = null): OperationOutcome =
        runPlanned(customerId, operationId, OperationKind.CASH_DEPOSIT, description) {
            LedgerRules.planDeposit(it, amountMinor)
        }

    /** سحب نقدي (تسليم نقد للعميل) من رصيد المحفظة فقط. */
    suspend fun withdraw(customerId: String, amountMinor: Long, operationId: String, description: String? = null): OperationOutcome =
        runPlanned(customerId, operationId, OperationKind.CASH_WITHDRAWAL, description) {
            LedgerRules.planWithdrawal(it, amountMinor)
        }

    /**
     * خصم بسياسة partial (للاستخدام المستقبلي من مرحلة الشحن؛ لا تنفيذ للشحن هنا ولا شاشة لها):
     * الرصيد أولاً ثم الفرق مديونية ضمن الحد الائتماني، وكل الأجزاء تُسجَّل في معاملة واحدة.
     */
    suspend fun recordConsumption(customerId: String, amountMinor: Long, operationId: String, description: String? = null): OperationOutcome =
        runPlanned(customerId, operationId, OperationKind.CONSUMPTION, description) {
            LedgerRules.planPartialConsumption(it, amountMinor)
        }

    /**
     * تصحيح بقيد عكسي: ينشئ قيداً جديداً بأثر معاكس لقيد سابق دون المساس بالأصل.
     * القيد يُعكس مرة واحدة، ولا يُعكس قيد عكسي، ولا يجوز أن ينتج رصيد/دين سالب.
     */
    suspend fun reverseEntry(entryId: String, operationId: String, description: String? = null): OperationOutcome =
        guarded {
            db.withTransaction<OperationOutcome> {
                precheck(operationId)?.let { return@withTransaction it }
                val original = ledger.getById(entryId)
                    ?: return@withTransaction OperationOutcome.Rejected(OperationRejection.ENTRY_NOT_FOUND)
                if (ledger.countReversalsOf(entryId) > 0) {
                    return@withTransaction OperationOutcome.Rejected(OperationRejection.ENTRY_ALREADY_REVERSED)
                }
                val customer = customers.getById(original.customerId)
                    ?: return@withTransaction OperationOutcome.Rejected(OperationRejection.CUSTOMER_NOT_FOUND)
                val state = loadState(customer)
                val originalPosting = Posting(original.type, original.balanceDeltaMinor, original.debtDeltaMinor)
                when (val plan = LedgerRules.planReversal(state, originalPosting)) {
                    is PlanResult.Rejected -> OperationOutcome.Rejected(plan.reason)
                    is PlanResult.Ok -> record(customer.id, operationId, OperationKind.REVERSAL, description, entryId, state, plan.postings)
                }
            }
        }

    // ---------------------------------------------------------------- القراءة

    fun observeCustomers(query: String): Flow<List<CustomerWithBalances>> =
        customers.observeWithBalances(escapeLike(query.trim()))

    fun observeCustomer(id: String): Flow<CustomerWithBalances?> = customers.observeWithBalancesById(id)

    fun observeStatement(customerId: String): Flow<List<LedgerEntryEntity>> = ledger.observeStatement(customerId)

    fun observeTotals(): Flow<LedgerTotals> = ledger.observeAllTotals()

    fun observeCustomerCount(): Flow<Int> = customers.observeCount()

    fun observeActiveCustomerCount(): Flow<Int> = customers.observeActiveCount()

    // ---------------------------------------------------------------- داخلي

    private suspend fun runPlanned(
        customerId: String,
        operationId: String,
        kind: OperationKind,
        description: String?,
        plan: (AccountState) -> PlanResult,
    ): OperationOutcome = guarded {
        db.withTransaction<OperationOutcome> {
            precheck(operationId)?.let { return@withTransaction it }
            val customer = customers.getById(customerId)
                ?: return@withTransaction OperationOutcome.Rejected(OperationRejection.CUSTOMER_NOT_FOUND)
            if (!customer.isActive) {
                return@withTransaction OperationOutcome.Rejected(OperationRejection.CUSTOMER_INACTIVE)
            }
            val state = loadState(customer)
            when (val p = plan(state)) {
                is PlanResult.Rejected -> OperationOutcome.Rejected(p.reason)
                is PlanResult.Ok -> record(customer.id, operationId, kind, description, null, state, p.postings)
            }
        }
    }

    private suspend fun precheck(operationId: String): OperationOutcome.Rejected? {
        if (operationId.isBlank()) return OperationOutcome.Rejected(OperationRejection.INVALID_OPERATION_ID)
        if (ledger.countByOperation(operationId) > 0) return OperationOutcome.Rejected(OperationRejection.DUPLICATE_OPERATION)
        return null
    }

    /** الحالة تُشتق دائماً من مجموع الدفتر داخل نفس المعاملة، لا من أي قيمة مخزَّنة. */
    private suspend fun loadState(customer: CustomerEntity): AccountState {
        val totals = ledger.getTotals(customer.id)
        return AccountState(totals.totalBalanceMinor, totals.totalDebtMinor, customer.creditLimitMinor)
    }

    private suspend fun record(
        customerId: String,
        operationId: String,
        kind: OperationKind,
        description: String?,
        reversesEntryId: String?,
        startState: AccountState,
        postings: List<Posting>,
    ): OperationOutcome.Recorded {
        val now = nowMillis()
        val note = description?.trim()?.take(MAX_DESCRIPTION)?.ifBlank { null }
        var state = startState
        var sequence = ledger.maxSequence()
        val saved = ArrayList<LedgerEntryEntity>(postings.size)
        postings.forEachIndexed { index, posting ->
            state = LedgerRules.apply(state, posting)
            sequence += 1
            val entry = LedgerEntryEntity(
                id = newId(),
                operationId = operationId,
                lineNo = index,
                customerId = customerId,
                type = posting.type,
                operationKind = kind,
                amountMinor = posting.amountMinor,
                balanceDeltaMinor = posting.balanceDeltaMinor,
                debtDeltaMinor = posting.debtDeltaMinor,
                balanceAfterMinor = state.balanceMinor,
                debtAfterMinor = state.debtMinor,
                sequence = sequence,
                createdAtMillis = now,
                description = note,
                reversesEntryId = reversesEntryId,
            )
            ledger.insert(entry)
            afterEntryInserted(index)
            saved += entry
        }
        return OperationOutcome.Recorded(saved, state)
    }

    /** تحويل مخالفة التفرد على operationId (سباق نظري) إلى رفض واضح؛ غير ذلك يُعاد رميه. */
    private suspend fun guarded(block: suspend () -> OperationOutcome): OperationOutcome =
        try {
            block()
        } catch (e: SQLiteConstraintException) {
            if (e.message?.contains("ledger_entries.operationId") == true) {
                OperationOutcome.Rejected(OperationRejection.DUPLICATE_OPERATION)
            } else {
                throw e
            }
        }

    private fun cleanName(raw: String): String? =
        raw.trim().replace(Regex("\\s+"), " ").takeIf { it.isNotEmpty() && it.length <= MAX_NAME }

    /** يهرّب % و _ و ! لأن البحث نصي حرفي (ESCAPE '!' في الاستعلام). */
    private fun escapeLike(q: String): String =
        q.replace("!", "!!").replace("%", "!%").replace("_", "!_")

    private companion object {
        const val MAX_DESCRIPTION = 200
        const val MAX_NAME = 100
    }
}
