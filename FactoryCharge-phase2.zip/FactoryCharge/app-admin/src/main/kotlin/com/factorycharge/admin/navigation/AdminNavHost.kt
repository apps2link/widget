package com.factorycharge.admin.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavBackStackEntry
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.factorycharge.admin.R
import com.factorycharge.admin.ui.AdminHomeScreen
import com.factorycharge.admin.ui.CashKind
import com.factorycharge.admin.ui.CashOperationScreen
import com.factorycharge.admin.ui.CreditLimitScreen
import com.factorycharge.admin.ui.CustomerDetailsScreen
import com.factorycharge.admin.ui.CustomerEditScreen
import com.factorycharge.admin.ui.CustomerListScreen
import com.factorycharge.admin.ui.StatementScreen
import com.factorycharge.core.design.OnboardingScreen

object AdminRoutes {
    const val ONBOARDING = "onboarding"
    const val HOME = "home"
    const val CUSTOMERS = "customers"
    const val CUSTOMER_NEW = "customer_new"

    private const val ID_ARG = "id"
    const val CUSTOMER_DETAILS = "customer/{$ID_ARG}"
    const val CUSTOMER_EDIT = "customer/{$ID_ARG}/edit"
    const val DEPOSIT = "customer/{$ID_ARG}/deposit"
    const val WITHDRAW = "customer/{$ID_ARG}/withdraw"
    const val STATEMENT = "customer/{$ID_ARG}/statement"
    const val CREDIT_LIMIT = "customer/{$ID_ARG}/limit"

    fun details(id: String) = "customer/$id"
    fun edit(id: String) = "customer/$id/edit"
    fun deposit(id: String) = "customer/$id/deposit"
    fun withdraw(id: String) = "customer/$id/withdraw"
    fun statement(id: String) = "customer/$id/statement"
    fun creditLimit(id: String) = "customer/$id/limit"

    fun idOf(entry: NavBackStackEntry): String = entry.arguments?.getString(ID_ARG).orEmpty()
    val idArguments = listOf(navArgument(ID_ARG) { type = NavType.StringType })
}

@Composable
fun AdminNavHost(
    onboardingDone: Boolean,
    onOnboardingFinished: () -> Unit,
) {
    val navController = rememberNavController()
    NavHost(
        navController = navController,
        startDestination = if (onboardingDone) AdminRoutes.HOME else AdminRoutes.ONBOARDING,
    ) {
        composable(AdminRoutes.ONBOARDING) {
            OnboardingScreen(
                roleLabel = stringResource(R.string.onboarding_role),
                title = stringResource(R.string.onboarding_title),
                description = stringResource(R.string.onboarding_description),
                points = listOf(
                    stringResource(R.string.onboarding_point_1),
                    stringResource(R.string.onboarding_point_2),
                    stringResource(R.string.onboarding_point_3),
                ),
                continueLabel = stringResource(R.string.onboarding_start),
                onContinue = {
                    onOnboardingFinished()
                    navController.navigate(AdminRoutes.HOME) {
                        popUpTo(AdminRoutes.ONBOARDING) { inclusive = true }
                    }
                },
            )
        }
        composable(AdminRoutes.HOME) {
            AdminHomeScreen(onOpenCustomers = { navController.navigate(AdminRoutes.CUSTOMERS) })
        }
        composable(AdminRoutes.CUSTOMERS) {
            CustomerListScreen(
                onBack = { navController.popBackStack() },
                onAdd = { navController.navigate(AdminRoutes.CUSTOMER_NEW) },
                onOpen = { id -> navController.navigate(AdminRoutes.details(id)) },
            )
        }
        composable(AdminRoutes.CUSTOMER_NEW) {
            CustomerEditScreen(
                customerId = null,
                onBack = { navController.popBackStack() },
                onSaved = { id ->
                    navController.navigate(AdminRoutes.details(id)) {
                        popUpTo(AdminRoutes.CUSTOMER_NEW) { inclusive = true }
                    }
                },
            )
        }
        composable(AdminRoutes.CUSTOMER_DETAILS, arguments = AdminRoutes.idArguments) { entry ->
            val id = AdminRoutes.idOf(entry)
            CustomerDetailsScreen(
                customerId = id,
                onBack = { navController.popBackStack() },
                onEdit = { navController.navigate(AdminRoutes.edit(id)) },
                onDeposit = { navController.navigate(AdminRoutes.deposit(id)) },
                onWithdraw = { navController.navigate(AdminRoutes.withdraw(id)) },
                onStatement = { navController.navigate(AdminRoutes.statement(id)) },
                onCreditLimit = { navController.navigate(AdminRoutes.creditLimit(id)) },
            )
        }
        composable(AdminRoutes.CUSTOMER_EDIT, arguments = AdminRoutes.idArguments) { entry ->
            CustomerEditScreen(
                customerId = AdminRoutes.idOf(entry),
                onBack = { navController.popBackStack() },
                onSaved = { navController.popBackStack() },
            )
        }
        composable(AdminRoutes.DEPOSIT, arguments = AdminRoutes.idArguments) { entry ->
            CashOperationScreen(
                customerId = AdminRoutes.idOf(entry),
                kind = CashKind.DEPOSIT,
                onBack = { navController.popBackStack() },
            )
        }
        composable(AdminRoutes.WITHDRAW, arguments = AdminRoutes.idArguments) { entry ->
            CashOperationScreen(
                customerId = AdminRoutes.idOf(entry),
                kind = CashKind.WITHDRAWAL,
                onBack = { navController.popBackStack() },
            )
        }
        composable(AdminRoutes.STATEMENT, arguments = AdminRoutes.idArguments) { entry ->
            StatementScreen(
                customerId = AdminRoutes.idOf(entry),
                onBack = { navController.popBackStack() },
            )
        }
        composable(AdminRoutes.CREDIT_LIMIT, arguments = AdminRoutes.idArguments) { entry ->
            CreditLimitScreen(
                customerId = AdminRoutes.idOf(entry),
                onBack = { navController.popBackStack() },
            )
        }
    }
}
