package com.factorycharge.admin.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.factorycharge.admin.data.FinancialRepository
import com.factorycharge.core.design.UiState
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

/** كل الأرقام محسوبة من مجموع الدفتر، لا من قيم مخزَّنة. */
data class AdminHomeData(
    val totalBalanceMinor: Long,
    val totalDebtMinor: Long,
    val customers: Int,
    val activeCustomers: Int,
)

class AdminHomeViewModel(private val repository: FinancialRepository) : ViewModel() {

    private val _state = MutableStateFlow<UiState<AdminHomeData>>(UiState.Loading)
    val state: StateFlow<UiState<AdminHomeData>> = _state.asStateFlow()

    private var loadJob: Job? = null

    init {
        load()
    }

    fun load() {
        loadJob?.cancel()
        _state.value = UiState.Loading
        loadJob = viewModelScope.launch {
            combine(
                repository.observeTotals(),
                repository.observeCustomerCount(),
                repository.observeActiveCustomerCount(),
            ) { totals, customers, active ->
                AdminHomeData(totals.totalBalanceMinor, totals.totalDebtMinor, customers, active)
            }
                .catch { _state.value = UiState.Error(it) }
                .collect { _state.value = UiState.Success(it) }
        }
    }

    companion object {
        val Factory: ViewModelProvider.Factory = adminFactory { AdminHomeViewModel(it) }
    }
}
