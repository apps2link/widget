package com.factorycharge.admin.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.factorycharge.admin.AdminApp
import com.factorycharge.admin.data.CustomerResult
import com.factorycharge.admin.data.CustomerWithBalances
import com.factorycharge.admin.data.FinancialRepository
import com.factorycharge.admin.data.LedgerEntryEntity
import com.factorycharge.admin.data.OperationOutcome
import com.factorycharge.core.design.UiState
import com.factorycharge.core.ledger.AccountState
import com.factorycharge.core.ledger.CustomerError
import com.factorycharge.core.ledger.LedgerRules
import com.factorycharge.core.ledger.OperationRejection
import com.factorycharge.core.ledger.PlanResult
import com.factorycharge.core.util.Money
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

inline fun <reified T : ViewModel> adminFactory(
    crossinline create: (FinancialRepository) -> T,
): ViewModelProvider.Factory = viewModelFactory {
    initializer { create((this[APPLICATION_KEY] as AdminApp).repository) }
}

private fun <T> Flow<T>.asUiState(): Flow<UiState<T>> =
    map<T, UiState<T>> { UiState.Success(it) }.catch { emit(UiState.Error(it)) }

// ------------------------------------------------------------------ قائمة العملاء

@OptIn(ExperimentalCoroutinesApi::class)
class CustomerListViewModel(private val repository: FinancialRepository) : ViewModel() {
    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()
    private val retryTick = MutableStateFlow(0)

    val state: StateFlow<UiState<List<CustomerWithBalances>>> =
        combine(_query, retryTick) { q, _ -> q }
            .flatMapLatest { q -> repository.observeCustomers(q).asUiState() }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), UiState.Loading)

    fun setQuery(value: String) {
        _query.value = value
    }

    fun retry() {
        retryTick.update { it + 1 }
    }

    companion object {
        val Factory: ViewModelProvider.Factory = adminFactory { CustomerListViewModel(it) }
    }
}

// ------------------------------------------------------------------ إضافة / تعديل عميل

data class CustomerEditState(
    val loading: Boolean = false,
    val notFound: Boolean = false,
    val name: String = "",
    val phone: String = "",
    val limitText: String = "",
    val limitInvalid: Boolean = false,
    val error: CustomerError? = null,
    val saving: Boolean = false,
    val savedId: String? = null,
)

class CustomerEditViewModel(
    private val repository: FinancialRepository,
    private val customerId: String?,
) : ViewModel() {
    private val _state = MutableStateFlow(CustomerEditState(loading = customerId != null))
    val state: StateFlow<CustomerEditState> = _state.asStateFlow()

    val isEdit: Boolean get() = customerId != null

    init {
        if (customerId != null) {
            viewModelScope.launch {
                val c = repository.getCustomer(customerId)
                _state.update {
                    if (c == null) it.copy(loading = false, notFound = true)
                    else it.copy(loading = false, name = c.displayName, phone = c.phone)
                }
            }
        }
    }

    fun onName(v: String) = _state.update { it.copy(name = v, error = null) }
    fun onPhone(v: String) = _state.update { it.copy(phone = v, error = null) }
    fun onLimit(v: String) = _state.update { it.copy(limitText = v, limitInvalid = false) }

    fun save() {
        val s = _state.value
        if (s.saving) return
        var limit = 0L
        if (customerId == null && s.limitText.isNotBlank()) {
            limit = Money.parseToMinor(s.limitText) ?: run {
                _state.update { it.copy(limitInvalid = true) }
                return
            }
        }
        _state.update { it.copy(saving = true, error = null) }
        viewModelScope.launch {
            val result = if (customerId == null) {
                repository.addCustomer(s.name, s.phone, limit)
            } else {
                repository.updateCustomer(customerId, s.name, s.phone)
            }
            _state.update {
                when (result) {
                    is CustomerResult.Saved -> it.copy(saving = false, savedId = result.customerId)
                    is CustomerResult.Failed -> it.copy(saving = false, error = result.error)
                }
            }
        }
    }
}

// ------------------------------------------------------------------ تفاصيل العميل

@OptIn(ExperimentalCoroutinesApi::class)
class CustomerDetailsViewModel(
    private val repository: FinancialRepository,
    private val customerId: String,
) : ViewModel() {
    private val retryTick = MutableStateFlow(0)

    val state: StateFlow<UiState<CustomerWithBalances?>> =
        retryTick
            .flatMapLatest { repository.observeCustomer(customerId).asUiState() }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), UiState.Loading)

    fun retry() {
        retryTick.update { it + 1 }
    }

    fun setActive(active: Boolean) {
        viewModelScope.launch { repository.setCustomerActive(customerId, active) }
    }
}

// ------------------------------------------------------------------ الإيداع / السحب

enum class CashKind { DEPOSIT, WITHDRAWAL }

data class CashFormState(
    val customer: CustomerWithBalances? = null,
    val loaded: Boolean = false,
    val amountText: String = "",
    val description: String = "",
    val amountMinor: Long? = null,
    val amountInvalid: Boolean = false,
    val preview: PlanResult? = null,
    val submitting: Boolean = false,
    val rejection: OperationRejection? = null,
    val unexpectedError: Boolean = false,
    val receipt: OperationOutcome.Recorded? = null,
    val operationId: String = "",
)

class CashOperationViewModel(
    private val repository: FinancialRepository,
    private val customerId: String,
    private val kind: CashKind,
) : ViewModel() {
    // يُنشأ مرة واحدة لكل نموذج: الضغط المزدوج أو إعادة الإرسال لا يكرر العملية.
    private val _state = MutableStateFlow(CashFormState(operationId = UUID.randomUUID().toString()))
    val state: StateFlow<CashFormState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            repository.observeCustomer(customerId).collect { c ->
                _state.update { recompute(it.copy(customer = c, loaded = true)) }
            }
        }
    }

    fun onAmount(text: String) = _state.update { recompute(it.copy(amountText = text, rejection = null, unexpectedError = false)) }
    fun onDescription(text: String) = _state.update { it.copy(description = text) }

    private fun recompute(s: CashFormState): CashFormState {
        val parsed = Money.parseToMinor(s.amountText)
        val invalid = s.amountText.isNotBlank() && parsed == null
        val c = s.customer
        val preview = if (parsed != null && c != null) {
            val account = AccountState(c.balanceMinor, c.debtMinor, c.customer.creditLimitMinor)
            when (kind) {
                CashKind.DEPOSIT -> LedgerRules.planDeposit(account, parsed)
                CashKind.WITHDRAWAL -> LedgerRules.planWithdrawal(account, parsed)
            }
        } else {
            null
        }
        return s.copy(amountMinor = parsed, amountInvalid = invalid, preview = preview)
    }

    fun submit() {
        val s = _state.value
        val amount = s.amountMinor ?: return
        if (s.submitting || s.receipt != null) return
        _state.update { it.copy(submitting = true, rejection = null, unexpectedError = false) }
        viewModelScope.launch {
            try {
                val outcome = when (kind) {
                    CashKind.DEPOSIT -> repository.deposit(customerId, amount, s.operationId, s.description)
                    CashKind.WITHDRAWAL -> repository.withdraw(customerId, amount, s.operationId, s.description)
                }
                _state.update {
                    when (outcome) {
                        is OperationOutcome.Recorded -> it.copy(submitting = false, receipt = outcome)
                        is OperationOutcome.Rejected -> it.copy(submitting = false, rejection = outcome.reason)
                    }
                }
            } catch (e: Exception) {
                if (e is CancellationException) throw e
                _state.update { it.copy(submitting = false, unexpectedError = true) }
            }
        }
    }
}

// ------------------------------------------------------------------ كشف الحساب

data class StatementData(
    val customer: CustomerWithBalances?,
    val entries: List<LedgerEntryEntity>,
)

@OptIn(ExperimentalCoroutinesApi::class)
class StatementViewModel(
    repository: FinancialRepository,
    customerId: String,
) : ViewModel() {
    private val retryTick = MutableStateFlow(0)

    val state: StateFlow<UiState<StatementData>> =
        retryTick
            .flatMapLatest {
                combine(repository.observeCustomer(customerId), repository.observeStatement(customerId)) { c, e ->
                    StatementData(c, e)
                }.asUiState()
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), UiState.Loading)

    fun retry() {
        retryTick.update { it + 1 }
    }
}

// ------------------------------------------------------------------ الحد الائتماني

data class CreditLimitState(
    val customer: CustomerWithBalances? = null,
    val loaded: Boolean = false,
    val limitText: String = "",
    val invalid: Boolean = false,
    val error: CustomerError? = null,
    val saving: Boolean = false,
    val saved: Boolean = false,
)

class CreditLimitViewModel(
    private val repository: FinancialRepository,
    private val customerId: String,
) : ViewModel() {
    private val _state = MutableStateFlow(CreditLimitState())
    val state: StateFlow<CreditLimitState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            repository.observeCustomer(customerId).collect { c ->
                _state.update {
                    // نملأ الحقل بالقيمة الحالية مرة واحدة فقط (أول قراءة) ولا نكتب فوق ما يكتبه المستخدم.
                    val prefill = if (!it.loaded && c != null) Money.plain(c.customer.creditLimitMinor) else it.limitText
                    it.copy(customer = c, loaded = true, limitText = prefill)
                }
            }
        }
    }

    fun onLimit(v: String) = _state.update { it.copy(limitText = v, invalid = false, error = null) }

    fun save() {
        val s = _state.value
        if (s.saving) return
        val limit = Money.parseToMinor(s.limitText)
        if (limit == null) {
            _state.update { it.copy(invalid = true) }
            return
        }
        _state.update { it.copy(saving = true, error = null) }
        viewModelScope.launch {
            val result = repository.setCreditLimit(customerId, limit)
            _state.update {
                when (result) {
                    is CustomerResult.Saved -> it.copy(saving = false, saved = true)
                    is CustomerResult.Failed -> it.copy(saving = false, error = result.error)
                }
            }
        }
    }
}
