package com.factorycharge.admin.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.factorycharge.admin.R
import com.factorycharge.core.design.EmptyState
import com.factorycharge.core.design.LoadingState
import com.factorycharge.core.design.moneyLabel

@Composable
fun CreditLimitScreen(
    customerId: String,
    onBack: () -> Unit,
    viewModel: CreditLimitViewModel = viewModel(factory = adminFactory { CreditLimitViewModel(it, customerId) }),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    LaunchedEffect(state.saved) {
        if (state.saved) onBack()
    }

    AppScaffold(title = stringResource(R.string.limit_title), onBack = onBack) { padding ->
        val customer = state.customer
        when {
            !state.loaded -> LoadingState(Modifier.padding(padding))
            customer == null -> EmptyState(
                icon = Icons.Default.Person,
                title = stringResource(R.string.customer_not_found_title),
                message = stringResource(R.string.customer_not_found_message),
                modifier = Modifier.padding(padding),
            )
            else -> Column(
                modifier = Modifier
                    .padding(padding)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                Text(customer.customer.displayName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(
                    text = stringResource(R.string.limit_current_debt) + ": " + moneyLabel(customer.debtMinor),
                    style = MaterialTheme.typography.bodyLarge,
                )
                Text(
                    text = stringResource(R.string.limit_help),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                AmountField(
                    value = state.limitText,
                    onValueChange = viewModel::onLimit,
                    label = stringResource(R.string.tile_limit),
                    isError = state.invalid || state.error != null,
                    supportingText = when {
                        state.invalid -> stringResource(R.string.error_invalid_amount)
                        state.error != null -> stringResource(state.error!!.labelRes)
                        else -> null
                    },
                )
                Button(
                    onClick = viewModel::save,
                    enabled = !state.saving && state.limitText.isNotBlank(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                ) {
                    Text(stringResource(R.string.limit_save), style = MaterialTheme.typography.titleMedium)
                }
            }
        }
    }
}
