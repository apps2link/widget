package com.factorycharge.admin.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBox
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.factorycharge.admin.R
import com.factorycharge.admin.data.CustomerWithBalances
import com.factorycharge.core.design.EmptyState
import com.factorycharge.core.design.ErrorState
import com.factorycharge.core.design.LoadingState
import com.factorycharge.core.design.UiState

@Composable
fun CustomerDetailsScreen(
    customerId: String,
    onBack: () -> Unit,
    onEdit: () -> Unit,
    onDeposit: () -> Unit,
    onWithdraw: () -> Unit,
    onStatement: () -> Unit,
    onCreditLimit: () -> Unit,
    viewModel: CustomerDetailsViewModel = viewModel(factory = adminFactory { CustomerDetailsViewModel(it, customerId) }),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    AppScaffold(title = stringResource(R.string.details_title), onBack = onBack) { padding ->
        Box(modifier = Modifier.padding(padding).fillMaxSize()) {
            when (val s = state) {
                UiState.Loading -> LoadingState()
                is UiState.Error -> ErrorState(onRetry = viewModel::retry)
                is UiState.Success -> {
                    val item = s.data
                    if (item == null) {
                        EmptyState(
                            icon = Icons.Default.Person,
                            title = stringResource(R.string.customer_not_found_title),
                            message = stringResource(R.string.customer_not_found_message),
                        )
                    } else {
                        DetailsContent(
                            item = item,
                            onActiveChange = viewModel::setActive,
                            onEdit = onEdit,
                            onDeposit = onDeposit,
                            onWithdraw = onWithdraw,
                            onStatement = onStatement,
                            onCreditLimit = onCreditLimit,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailsContent(
    item: CustomerWithBalances,
    onActiveChange: (Boolean) -> Unit,
    onEdit: () -> Unit,
    onDeposit: () -> Unit,
    onWithdraw: () -> Unit,
    onStatement: () -> Unit,
    onCreditLimit: () -> Unit,
) {
    val customer = item.customer
    val availableCredit = (customer.creditLimitMinor - item.debtMinor).coerceAtLeast(0)
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(customer.displayName, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(customer.phone, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = stringResource(R.string.details_status_active),
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.weight(1f),
                    )
                    Switch(checked = customer.isActive, onCheckedChange = onActiveChange)
                }
            }
        }

        FinanceTile(
            label = stringResource(R.string.tile_wallet),
            amountMinor = item.balanceMinor,
            icon = Icons.Default.AccountBox,
            container = MaterialTheme.colorScheme.primaryContainer,
            content = MaterialTheme.colorScheme.onPrimaryContainer,
            modifier = Modifier.fillMaxWidth(),
        )
        FinanceTile(
            label = stringResource(R.string.tile_debt),
            amountMinor = item.debtMinor,
            icon = Icons.Default.Warning,
            container = MaterialTheme.colorScheme.errorContainer,
            content = MaterialTheme.colorScheme.onErrorContainer,
            modifier = Modifier.fillMaxWidth(),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            FinanceTile(
                label = stringResource(R.string.tile_limit),
                amountMinor = customer.creditLimitMinor,
                icon = Icons.Default.Info,
                modifier = Modifier.weight(1f),
            )
            FinanceTile(
                label = stringResource(R.string.tile_available_credit),
                amountMinor = availableCredit,
                icon = Icons.Default.CheckCircle,
                modifier = Modifier.weight(1f),
            )
        }

        if (!customer.isActive) {
            Text(
                text = stringResource(R.string.details_inactive_note),
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodyMedium,
            )
        }

        Button(
            onClick = onDeposit,
            enabled = customer.isActive,
            modifier = Modifier.fillMaxWidth().height(52.dp),
        ) { Text(stringResource(R.string.action_deposit), style = MaterialTheme.typography.titleMedium) }
        FilledTonalButton(
            onClick = onWithdraw,
            enabled = customer.isActive,
            modifier = Modifier.fillMaxWidth().height(52.dp),
        ) { Text(stringResource(R.string.action_withdraw), style = MaterialTheme.typography.titleMedium) }
        OutlinedButton(
            onClick = onStatement,
            modifier = Modifier.fillMaxWidth().height(52.dp),
        ) { Text(stringResource(R.string.action_statement)) }
        OutlinedButton(
            onClick = onCreditLimit,
            modifier = Modifier.fillMaxWidth().height(52.dp),
        ) { Text(stringResource(R.string.action_credit_limit)) }
        TextButton(onClick = onEdit, modifier = Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.action_edit))
        }
    }
}
