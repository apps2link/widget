package com.factorycharge.admin.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.factorycharge.admin.R
import com.factorycharge.core.design.EmptyState
import com.factorycharge.core.design.LoadingState
import com.factorycharge.core.ledger.CustomerError

/** [customerId] = null يعني إضافة عميل جديد. */
@Composable
fun CustomerEditScreen(
    customerId: String?,
    onBack: () -> Unit,
    onSaved: (String) -> Unit,
    viewModel: CustomerEditViewModel = viewModel(factory = adminFactory { CustomerEditViewModel(it, customerId) }),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    LaunchedEffect(state.savedId) {
        state.savedId?.let(onSaved)
    }

    AppScaffold(
        title = stringResource(if (viewModel.isEdit) R.string.customer_form_edit_title else R.string.customer_form_add_title),
        onBack = onBack,
    ) { padding ->
        when {
            state.loading -> LoadingState(Modifier.padding(padding))
            state.notFound -> EmptyState(
                icon = Icons.Default.Person,
                title = stringResource(R.string.customer_not_found_title),
                message = stringResource(R.string.customer_not_found_message),
                modifier = Modifier.padding(padding),
            )
            else -> Column(
                modifier = Modifier
                    .padding(padding)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                OutlinedTextField(
                    value = state.name,
                    onValueChange = viewModel::onName,
                    label = { Text(stringResource(R.string.field_name)) },
                    singleLine = true,
                    isError = state.error == CustomerError.INVALID_NAME,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = state.phone,
                    onValueChange = viewModel::onPhone,
                    label = { Text(stringResource(R.string.field_phone)) },
                    singleLine = true,
                    isError = state.error == CustomerError.INVALID_PHONE || state.error == CustomerError.DUPLICATE_PHONE,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth(),
                )
                if (!viewModel.isEdit) {
                    AmountField(
                        value = state.limitText,
                        onValueChange = viewModel::onLimit,
                        label = stringResource(R.string.field_initial_limit),
                        isError = state.limitInvalid,
                        supportingText = if (state.limitInvalid) stringResource(R.string.error_invalid_amount) else null,
                    )
                }
                state.error?.let {
                    Text(
                        text = stringResource(it.labelRes),
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
                Button(
                    onClick = viewModel::save,
                    enabled = !state.saving && state.name.isNotBlank() && state.phone.isNotBlank(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                ) {
                    Text(stringResource(R.string.action_save), style = MaterialTheme.typography.titleMedium)
                }
            }
        }
    }
}
