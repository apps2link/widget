package com.factorycharge.admin.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.factorycharge.admin.R
import com.factorycharge.admin.data.LedgerEntryEntity
import com.factorycharge.core.design.EmptyState
import com.factorycharge.core.design.ErrorState
import com.factorycharge.core.design.LoadingState
import com.factorycharge.core.design.UiState
import com.factorycharge.core.design.moneyLabel

@Composable
fun StatementScreen(
    customerId: String,
    onBack: () -> Unit,
    viewModel: StatementViewModel = viewModel(factory = adminFactory { StatementViewModel(it, customerId) }),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    AppScaffold(title = stringResource(R.string.statement_title), onBack = onBack) { padding ->
        Box(modifier = Modifier.padding(padding).fillMaxSize()) {
            when (val s = state) {
                UiState.Loading -> LoadingState()
                is UiState.Error -> ErrorState(onRetry = viewModel::retry)
                is UiState.Success -> {
                    val data = s.data
                    if (data.entries.isEmpty()) {
                        EmptyState(
                            icon = Icons.AutoMirrored.Filled.List,
                            title = stringResource(R.string.statement_empty_title),
                            message = stringResource(R.string.statement_empty_message),
                        )
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                        ) {
                            data.customer?.let { c ->
                                item(key = "summary") {
                                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                        FinanceTile(
                                            label = stringResource(R.string.tile_wallet),
                                            amountMinor = c.balanceMinor,
                                            icon = Icons.AutoMirrored.Filled.List,
                                            container = MaterialTheme.colorScheme.primaryContainer,
                                            content = MaterialTheme.colorScheme.onPrimaryContainer,
                                            modifier = Modifier.weight(1f),
                                        )
                                        FinanceTile(
                                            label = stringResource(R.string.tile_debt),
                                            amountMinor = c.debtMinor,
                                            icon = Icons.AutoMirrored.Filled.List,
                                            container = MaterialTheme.colorScheme.errorContainer,
                                            content = MaterialTheme.colorScheme.onErrorContainer,
                                            modifier = Modifier.weight(1f),
                                        )
                                    }
                                }
                            }
                            items(data.entries, key = { it.id }) { entry -> EntryCard(entry) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EntryCard(entry: LedgerEntryEntity) {
    val affectsBalance = entry.balanceDeltaMinor != 0L
    val delta = if (affectsBalance) entry.balanceDeltaMinor else entry.debtDeltaMinor
    // زيادة الرصيد أو نقص المديونية = في صالح العميل (لون أساسي)؛ العكس = لون الخطأ.
    val favorable = if (affectsBalance) delta > 0 else delta < 0
    val amountColor: Color = if (favorable) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
    val sign = if (delta > 0) "+" else ""

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(stringResource(entry.type.labelRes), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    Text(
                        text = stringResource(if (affectsBalance) R.string.statement_target_balance else R.string.statement_target_debt),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Text(
                    text = sign + moneyLabel(delta),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = amountColor,
                )
            }
            Text(
                text = stringResource(R.string.statement_balance_after) + ": " + moneyLabel(entry.balanceAfterMinor) +
                    "  •  " + stringResource(R.string.statement_debt_after) + ": " + moneyLabel(entry.debtAfterMinor),
                style = MaterialTheme.typography.bodySmall,
            )
            entry.description?.let { Text(it, style = MaterialTheme.typography.bodyMedium) }
            if (entry.reversesEntryId != null) {
                Text(stringResource(R.string.statement_reverses), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.tertiary)
            }
            Text(
                text = formatDateTime(entry.createdAtMillis) + "  •  " + stringResource(R.string.statement_ref) + " #" + entry.operationId.takeLast(8),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
