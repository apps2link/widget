package com.factorycharge.admin

import com.factorycharge.admin.data.Converters
import com.factorycharge.core.ledger.LedgerEntryType
import com.factorycharge.core.ledger.OperationKind
import com.factorycharge.core.model.NetworkProvider
import com.factorycharge.core.model.RequestStatus
import com.factorycharge.core.model.ServiceType
import org.junit.Assert.assertEquals
import org.junit.Test

class ConvertersTest {
    private val c = Converters()

    @Test
    fun enumsRoundTrip() {
        NetworkProvider.entries.forEach { assertEquals(it, c.stringToProvider(c.providerToString(it))) }
        ServiceType.entries.forEach { assertEquals(it, c.stringToService(c.serviceToString(it))) }
        RequestStatus.entries.forEach { assertEquals(it, c.stringToStatus(c.statusToString(it))) }
        LedgerEntryType.entries.forEach { assertEquals(it, c.stringToEntryType(c.entryTypeToString(it))) }
        OperationKind.entries.forEach { assertEquals(it, c.stringToOperationKind(c.operationKindToString(it))) }
    }

    /** الاستعلام في ChargeRequestDao وTriggers الدفتر يستخدمان هذه الأسماء كنصوص ثابتة. */
    @Test
    fun namesUsedInRawSqlMatchEnums() {
        assertEquals("SUBMITTED", RequestStatus.SUBMITTED.name)
        assertEquals("UNDER_REVIEW", RequestStatus.UNDER_REVIEW.name)
        assertEquals("DEBT_CREATED", LedgerEntryType.DEBT_CREATED.name)
    }
}
