package com.factorycharge.admin

import android.database.sqlite.SQLiteException
import androidx.room.Room
import androidx.room.withTransaction
import com.factorycharge.admin.data.AdminDatabase
import com.factorycharge.admin.data.CustomerResult
import com.factorycharge.admin.data.FinancialRepository
import com.factorycharge.admin.data.LedgerEntryEntity
import com.factorycharge.admin.data.LedgerTriggers
import com.factorycharge.admin.data.OperationOutcome
import com.factorycharge.core.ledger.CustomerError
import com.factorycharge.core.ledger.LedgerEntryType
import com.factorycharge.core.ledger.OperationKind
import com.factorycharge.core.ledger.OperationRejection
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

/**
 * اختبارات حقيقية على SQLite (عبر Robolectric) بنفس Triggers الإنتاج. لا بيانات تجريبية:
 * كل اختبار يعمل على قاعدة في الذاكرة تُحذف بعده.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class FinancialRepositoryTest {

    private lateinit var db: AdminDatabase
    private lateinit var repo: FinancialRepository
    private var clock = 1_000L
    private var ids = 0
    private var phones = 0

    @Before
    fun setUp() {
        db = Room.inMemoryDatabaseBuilder(RuntimeEnvironment.getApplication(), AdminDatabase::class.java)
            .allowMainThreadQueries()
            .addCallback(LedgerTriggers.callback)
            .build()
        repo = newRepo()
    }

    @After
    fun tearDown() {
        db.close()
    }

    private fun newRepo(hook: (Int) -> Unit = {}) = FinancialRepository(
        db = db,
        nowMillis = { clock++ },
        newId = { "id-${ids++}" },
        afterEntryInserted = hook,
    )

    private fun inTest(block: suspend CoroutineScope.() -> Unit) {
        runBlocking(block = block)
    }

    private suspend fun newCustomer(limitMinor: Long = 0): String {
        val phone = "0100000" + (phones++).toString().padStart(4, '0')
        return (repo.addCustomer("عميل اختبار", phone, limitMinor) as CustomerResult.Saved).customerId
    }

    private suspend fun account(customerId: String) = db.customerDao().observeWithBalancesById(customerId).first()!!

    private suspend fun assertAccount(customerId: String, balance: Long, debt: Long) {
        val a = account(customerId)
        assertEquals("balance", balance, a.balanceMinor)
        assertEquals("debt", debt, a.debtMinor)
    }

    private fun recorded(o: OperationOutcome): OperationOutcome.Recorded = o as OperationOutcome.Recorded

    private fun rejection(o: OperationOutcome): OperationRejection = (o as OperationOutcome.Rejected).reason

    // ---- 1) إيداع بدون مديونية
    @Test
    fun depositWithoutDebtCreditsWallet() = inTest {
        val c = newCustomer()
        val r = recorded(repo.deposit(c, 10_000, "op-1"))
        assertEquals(1, r.entries.size)
        assertEquals(LedgerEntryType.WALLET_CREDIT, r.entries[0].type)
        assertEquals(OperationKind.CASH_DEPOSIT, r.entries[0].operationKind)
        assertEquals(10_000L, r.entries[0].balanceAfterMinor)
        assertAccount(c, 10_000, 0)
    }

    // ---- 2) إيداع مع مديونية أكبر من المدفوع
    @Test
    fun depositSmallerThanDebtOnlyReducesDebt() = inTest {
        val c = newCustomer(limitMinor = 50_000)
        recorded(repo.recordConsumption(c, 10_000, "debt-1"))
        assertAccount(c, 0, 10_000)
        val r = recorded(repo.deposit(c, 4_000, "dep-1"))
        assertEquals(listOf(LedgerEntryType.DEBT_SETTLEMENT), r.entries.map { it.type })
        assertAccount(c, 0, 6_000)
    }

    // ---- 3) إيداع مع مديونية أقل من المدفوع (دين 100 ودفع 150 => تسوية 100 + 50 للمحفظة)
    @Test
    fun depositLargerThanDebtSettlesThenCreditsRemainder() = inTest {
        val c = newCustomer(limitMinor = 50_000)
        recorded(repo.recordConsumption(c, 10_000, "debt-1"))
        val r = recorded(repo.deposit(c, 15_000, "dep-1"))
        assertEquals(listOf(LedgerEntryType.DEBT_SETTLEMENT, LedgerEntryType.WALLET_CREDIT), r.entries.map { it.type })
        assertEquals(listOf(10_000L, 5_000L), r.entries.map { it.amountMinor })
        assertEquals(listOf(0, 1), r.entries.map { it.lineNo })
        assertEquals(5_000L, r.entries.last().balanceAfterMinor)
        assertEquals(0L, r.entries.last().debtAfterMinor)
        assertAccount(c, 5_000, 0)
    }

    // ---- 4) سحب مساوٍ للرصيد
    @Test
    fun withdrawalEqualToBalanceLeavesZero() = inTest {
        val c = newCustomer()
        repo.deposit(c, 7_000, "dep")
        val r = recorded(repo.withdraw(c, 7_000, "wd"))
        assertEquals(LedgerEntryType.CASH_WITHDRAWAL, r.entries.single().type)
        assertAccount(c, 0, 0)
    }

    // ---- 5) رفض السحب الأكبر من الرصيد (ولا يُكتب شيء)
    @Test
    fun withdrawalGreaterThanBalanceIsRejectedAndNothingIsWritten() = inTest {
        val c = newCustomer()
        repo.deposit(c, 7_000, "dep")
        val before = db.ledgerDao().count()
        assertEquals(OperationRejection.INSUFFICIENT_BALANCE, rejection(repo.withdraw(c, 7_001, "wd")))
        assertEquals(before, db.ledgerDao().count())
        assertEquals(0, db.ledgerDao().countByOperation("wd"))
        assertAccount(c, 7_000, 0)
    }

    // ---- 6) رفض المبالغ الصفرية والسالبة
    @Test
    fun zeroAndNegativeAmountsAreRejected() = inTest {
        val c = newCustomer(limitMinor = 10_000)
        listOf(0L, -1L, -5_000L).forEachIndexed { i, amount ->
            assertEquals(OperationRejection.INVALID_AMOUNT, rejection(repo.deposit(c, amount, "d$i")))
            assertEquals(OperationRejection.INVALID_AMOUNT, rejection(repo.withdraw(c, amount, "w$i")))
            assertEquals(OperationRejection.INVALID_AMOUNT, rejection(repo.recordConsumption(c, amount, "c$i")))
        }
        assertEquals(0, db.ledgerDao().count())
    }

    // ---- 7) رفض تكرار نفس العملية
    @Test
    fun duplicateOperationIdIsRejectedAndNotAppliedTwice() = inTest {
        val c = newCustomer()
        recorded(repo.deposit(c, 5_000, "same-op"))
        assertEquals(OperationRejection.DUPLICATE_OPERATION, rejection(repo.deposit(c, 5_000, "same-op")))
        // حتى مع اختلاف النوع أو المبلغ: المعرّف مستهلك
        assertEquals(OperationRejection.DUPLICATE_OPERATION, rejection(repo.withdraw(c, 1, "same-op")))
        assertEquals(1, db.ledgerDao().count())
        assertAccount(c, 5_000, 0)
    }

    @Test
    fun blankOperationIdIsRejected() = inTest {
        val c = newCustomer()
        assertEquals(OperationRejection.INVALID_OPERATION_ID, rejection(repo.deposit(c, 100, "  ")))
    }

    @Test
    fun databaseItselfRejectsDuplicateOperationLine() = inTest {
        val c = newCustomer()
        recorded(repo.deposit(c, 5_000, "op"))
        val first = db.ledgerDao().listForCustomer(c).single()
        // قيد ثانٍ بنفس (operationId, lineNo) مع باقي الحقول صحيحة => يرفضه الفهرس الفريد
        val dup = first.copy(id = "other", sequence = 2, balanceAfterMinor = 10_000)
        assertThrows(SQLiteException::class.java) { runBlocking { db.ledgerDao().insert(dup) } }
        assertEquals(1, db.ledgerDao().count())
    }

    // ---- 8) الذرية: فشل في منتصف العملية يتراجع عن كل شيء
    @Test
    fun failureAfterFirstEntryRollsBackWholeOperation() = inTest {
        val c = newCustomer(limitMinor = 50_000)
        recorded(repo.recordConsumption(c, 10_000, "debt"))
        val before = db.ledgerDao().listForCustomer(c)

        val failing = newRepo { index -> if (index == 0) throw IllegalStateException("boom") }
        assertThrows(IllegalStateException::class.java) { runBlocking { failing.deposit(c, 15_000, "dep") } }

        assertEquals(before, db.ledgerDao().listForCustomer(c))
        assertEquals(0, db.ledgerDao().countByOperation("dep"))
        assertAccount(c, 0, 10_000)

        // لأن المعاملة تراجعت لم يُستهلك المعرّف: إعادة المحاولة بنفس المعرّف تنجح مرة واحدة
        recorded(repo.deposit(c, 15_000, "dep"))
        assertAccount(c, 5_000, 0)
    }

    @Test
    fun databaseTransactionRollsBackWhenSecondInsertViolatesConstraints() = inTest {
        val c = newCustomer()
        fun entry(id: String, seq: Long, line: Int, balanceAfter: Long) = LedgerEntryEntity(
            id = id, operationId = "manual", lineNo = line, customerId = c,
            type = LedgerEntryType.WALLET_CREDIT, operationKind = OperationKind.CASH_DEPOSIT,
            amountMinor = 100, balanceDeltaMinor = 100, debtDeltaMinor = 0,
            balanceAfterMinor = balanceAfter, debtAfterMinor = 0,
            sequence = seq, createdAtMillis = 1, description = null, reversesEntryId = null,
        )
        assertThrows(SQLiteException::class.java) {
            runBlocking {
                db.withTransaction {
                    db.ledgerDao().insert(entry("e1", 1, 0, 100))
                    db.ledgerDao().insert(entry("e2", 5, 1, 200)) // sequence مفقود => يرفضه Trigger
                }
            }
        }
        assertEquals(0, db.ledgerDao().count())
    }

    // ---- 9) القيود القديمة لا تُعدَّل ولا تُحذف
    @Test
    fun ledgerEntriesCannotBeUpdatedOrDeleted() = inTest {
        val c = newCustomer()
        repo.deposit(c, 10_000, "dep")
        repo.withdraw(c, 2_000, "wd")
        val before = db.ledgerDao().listForCustomer(c)
        val sqlite = db.openHelper.writableDatabase

        assertThrows(SQLiteException::class.java) { sqlite.execSQL("UPDATE ledger_entries SET amountMinor = 1") }
        assertThrows(SQLiteException::class.java) { sqlite.execSQL("UPDATE ledger_entries SET balanceAfterMinor = 999999 WHERE sequence = 1") }
        assertThrows(SQLiteException::class.java) { sqlite.execSQL("DELETE FROM ledger_entries WHERE sequence = 1") }
        assertThrows(SQLiteException::class.java) { sqlite.execSQL("DELETE FROM ledger_entries") }

        assertEquals(before, db.ledgerDao().listForCustomer(c))
        assertAccount(c, 8_000, 0)
    }

    @Test
    fun customerWithLedgerHistoryCannotBeDeleted() = inTest {
        val c = newCustomer()
        repo.deposit(c, 1_000, "dep")
        assertThrows(SQLiteException::class.java) {
            db.openHelper.writableDatabase.execSQL("DELETE FROM customers WHERE id = '$c'")
        }
    }

    @Test
    fun databaseRejectsForgedEntries() = inTest {
        val c = newCustomer()
        recorded(repo.deposit(c, 5_000, "dep"))
        val base = db.ledgerDao().listForCustomer(c).single()
        fun forged(block: (LedgerEntryEntity) -> LedgerEntryEntity) {
            val e = block(base.copy(id = "forged-${ids++}", operationId = "forged-op-${ids++}", sequence = 2))
            assertThrows(SQLiteException::class.java) { runBlocking { db.ledgerDao().insert(e) } }
        }
        forged { it.copy(balanceAfterMinor = 9_999_999) }                       // رصيد لا يطابق الدفتر
        forged { it.copy(amountMinor = 0, balanceDeltaMinor = 0, balanceAfterMinor = 5_000) } // مبلغ صفري
        forged { it.copy(sequence = 3) }                                          // ثغرة في الترتيب
        forged { it.copy(balanceDeltaMinor = -9_999, balanceAfterMinor = -4_999) } // رصيد سالب
        assertEquals(1, db.ledgerDao().count())
    }

    @Test
    fun databaseEnforcesCreditLimitOnDebtCreation() = inTest {
        val c = newCustomer(limitMinor = 1_000)
        val tooMuch = LedgerEntryEntity(
            id = "x", operationId = "x-op", lineNo = 0, customerId = c,
            type = LedgerEntryType.DEBT_CREATED, operationKind = OperationKind.CONSUMPTION,
            amountMinor = 2_000, balanceDeltaMinor = 0, debtDeltaMinor = 2_000,
            balanceAfterMinor = 0, debtAfterMinor = 2_000,
            sequence = 1, createdAtMillis = 1, description = null, reversesEntryId = null,
        )
        assertThrows(SQLiteException::class.java) { runBlocking { db.ledgerDao().insert(tooMuch) } }
        assertEquals(0, db.ledgerDao().count())
    }

    // ---- 10) سلسلة عمليات متتابعة: الحسابات والتسلسل والأرصدة اللحظية
    @Test
    fun longSequenceOfOperationsKeepsLedgerConsistent() = inTest {
        val c = newCustomer(limitMinor = 50_000)
        recorded(repo.deposit(c, 10_000, "1"))            // رصيد 100
        recorded(repo.withdraw(c, 3_000, "2"))            // رصيد 70
        recorded(repo.recordConsumption(c, 20_000, "3"))  // خصم 70 + دين 130
        assertAccount(c, 0, 13_000)
        recorded(repo.deposit(c, 10_000, "4"))            // دين 30
        recorded(repo.deposit(c, 5_000, "5"))             // دين 0 + رصيد 20
        recorded(repo.withdraw(c, 2_000, "6"))            // رصيد 0
        assertEquals(OperationRejection.INSUFFICIENT_BALANCE, rejection(repo.withdraw(c, 1, "7")))
        assertAccount(c, 0, 0)

        val entries = db.ledgerDao().listForCustomer(c)
        // التسلسل عالمي متصل بلا ثغرات
        assertEquals((1L..entries.size).toList(), entries.map { it.sequence })
        // الرصيد/الدين بعد كل قيد = التراكم الفعلي لأثر القيود
        var bal = 0L
        var debt = 0L
        entries.forEach {
            bal += it.balanceDeltaMinor
            debt += it.debtDeltaMinor
            assertEquals(bal, it.balanceAfterMinor)
            assertEquals(debt, it.debtAfterMinor)
            assertTrue(it.balanceAfterMinor >= 0 && it.debtAfterMinor >= 0)
            assertTrue(it.amountMinor > 0)
        }
        // مبالغ القيود تطابق أثرها
        entries.forEach { assertEquals(it.amountMinor, kotlin.math.abs(it.balanceDeltaMinor + it.debtDeltaMinor)) }
        // معادلة الحفظ: نقد دخل - نقد خرج - استهلاك = رصيد - دين
        assertEquals(25_000L - 5_000L - 20_000L, bal - debt)
    }

    @Test
    fun globalSequenceIsSharedAcrossCustomersAndTotalsMatch() = inTest {
        val a = newCustomer()
        val b = newCustomer()
        repo.deposit(a, 1_000, "a1")
        repo.deposit(b, 2_000, "b1")
        repo.deposit(a, 500, "a2")
        assertEquals(listOf(1L, 3L), db.ledgerDao().listForCustomer(a).map { it.sequence })
        assertEquals(listOf(2L), db.ledgerDao().listForCustomer(b).map { it.sequence })
        val totals = repo.observeTotals().first()
        assertEquals(3_500L, totals.totalBalanceMinor)
        assertEquals(0L, totals.totalDebtMinor)
        // كشف الحساب الأحدث أولاً
        assertEquals(listOf(3L, 1L), repo.observeStatement(a).first().map { it.sequence })
    }

    // ---- سياسة partial وسقف الائتمان على مستوى المستودع
    @Test
    fun partialConsumptionRecordsAllPartsOrNothing() = inTest {
        val c = newCustomer(limitMinor = 5_000)
        repo.deposit(c, 3_000, "dep")
        // 80 = 30 من الرصيد + 50 دين (يساوي الحد تماماً) => مسموح
        val ok = recorded(repo.recordConsumption(c, 8_000, "use-1"))
        assertEquals(listOf(LedgerEntryType.WALLET_DEBIT, LedgerEntryType.DEBT_CREATED), ok.entries.map { it.type })
        assertAccount(c, 0, 5_000)
        // أي دين إضافي يتجاوز الحد => رفض كامل
        val before = db.ledgerDao().count()
        assertEquals(OperationRejection.CREDIT_LIMIT_EXCEEDED, rejection(repo.recordConsumption(c, 1, "use-2")))
        assertEquals(before, db.ledgerDao().count())
    }

    // ---- القيد العكسي
    @Test
    fun reversalAddsCompensatingEntryWithoutTouchingOriginal() = inTest {
        val c = newCustomer()
        val dep = recorded(repo.deposit(c, 4_000, "dep"))
        val original = dep.entries.single()
        val r = recorded(repo.reverseEntry(original.id, "rev-1", "تصحيح خطأ إدخال"))
        val reversal = r.entries.single()
        assertEquals(LedgerEntryType.REVERSAL, reversal.type)
        assertEquals(OperationKind.REVERSAL, reversal.operationKind)
        assertEquals(original.id, reversal.reversesEntryId)
        assertEquals(-4_000L, reversal.balanceDeltaMinor)
        assertEquals(original, db.ledgerDao().getById(original.id)) // الأصل كما هو
        assertAccount(c, 0, 0)
        // لا يُعكس القيد مرتين، ولا يُعكس قيد عكسي
        assertEquals(OperationRejection.ENTRY_ALREADY_REVERSED, rejection(repo.reverseEntry(original.id, "rev-2")))
        assertEquals(OperationRejection.CANNOT_REVERSE_A_REVERSAL, rejection(repo.reverseEntry(reversal.id, "rev-3")))
        assertEquals(OperationRejection.ENTRY_NOT_FOUND, rejection(repo.reverseEntry("nope", "rev-4")))
    }

    @Test
    fun reversalIsRejectedWhenItWouldMakeBalanceNegative() = inTest {
        val c = newCustomer()
        val dep = recorded(repo.deposit(c, 4_000, "dep"))
        repo.withdraw(c, 3_000, "wd")
        assertEquals(OperationRejection.REVERSAL_NEGATIVE_BALANCE, rejection(repo.reverseEntry(dep.entries.single().id, "rev")))
        assertAccount(c, 1_000, 0)
    }

    // ---- إدارة العملاء والحالة
    @Test
    fun inactiveCustomerCannotReceiveNewOperations() = inTest {
        val c = newCustomer()
        repo.deposit(c, 1_000, "dep")
        repo.setCustomerActive(c, false)
        assertEquals(OperationRejection.CUSTOMER_INACTIVE, rejection(repo.deposit(c, 100, "d2")))
        assertEquals(OperationRejection.CUSTOMER_INACTIVE, rejection(repo.withdraw(c, 100, "w2")))
        repo.setCustomerActive(c, true)
        recorded(repo.withdraw(c, 100, "w3"))
    }

    @Test
    fun unknownCustomerIsRejected() = inTest {
        assertEquals(OperationRejection.CUSTOMER_NOT_FOUND, rejection(repo.deposit("missing", 100, "op")))
    }

    @Test
    fun customerValidationAndUniquePhone() = inTest {
        assertEquals(CustomerError.INVALID_NAME, (repo.addCustomer("  ", "01001234567") as CustomerResult.Failed).error)
        assertEquals(CustomerError.INVALID_PHONE, (repo.addCustomer("أحمد", "123") as CustomerResult.Failed).error)
        assertEquals(CustomerError.NEGATIVE_LIMIT, (repo.addCustomer("أحمد", "01001234567", -1) as CustomerResult.Failed).error)
        val first = repo.addCustomer("أحمد", "0100 123 4567") as CustomerResult.Saved
        assertEquals(CustomerError.DUPLICATE_PHONE, (repo.addCustomer("آخر", "٠١٠٠١٢٣٤٥٦٧") as CustomerResult.Failed).error)
        val other = repo.addCustomer("محمود", "01009999999") as CustomerResult.Saved
        assertEquals(CustomerError.DUPLICATE_PHONE, (repo.updateCustomer(other.customerId, "محمود", "01001234567") as CustomerResult.Failed).error)
        repo.updateCustomer(first.customerId, "أحمد علي", "01005550000")
        val saved = repo.getCustomer(first.customerId)
        assertNotNull(saved)
        assertEquals("أحمد علي", saved!!.displayName)
        assertEquals(first.customerId, saved.id) // المعرّف ثابت
    }

    @Test
    fun creditLimitCannotBeBelowCurrentDebt() = inTest {
        val c = newCustomer(limitMinor = 10_000)
        repo.recordConsumption(c, 6_000, "debt")
        assertEquals(CustomerError.LIMIT_BELOW_DEBT, (repo.setCreditLimit(c, 5_999) as CustomerResult.Failed).error)
        assertEquals(CustomerError.NEGATIVE_LIMIT, (repo.setCreditLimit(c, -1) as CustomerResult.Failed).error)
        assertTrue(repo.setCreditLimit(c, 6_000) is CustomerResult.Saved)
        assertEquals(6_000L, repo.getCustomer(c)!!.creditLimitMinor)
    }

    @Test
    fun searchByNameOrPhoneTreatsWildcardsLiterally() = inTest {
        repo.addCustomer("أحمد حسن", "01011111111")
        repo.addCustomer("محمود", "01022222222")
        assertEquals(1, repo.observeCustomers("أحمد").first().size)
        assertEquals(1, repo.observeCustomers("0102222").first().size)
        assertEquals(2, repo.observeCustomers("").first().size)
        assertEquals(0, repo.observeCustomers("%").first().size)
        assertEquals(0, repo.observeCustomers("_").first().size)
    }
}
