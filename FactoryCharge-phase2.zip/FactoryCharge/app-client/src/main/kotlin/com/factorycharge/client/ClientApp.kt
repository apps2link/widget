package com.factorycharge.client

import android.app.Application
import com.factorycharge.client.data.ClientDatabase

class ClientApp : Application() {
    val database: ClientDatabase by lazy { ClientDatabase.build(this) }
}
