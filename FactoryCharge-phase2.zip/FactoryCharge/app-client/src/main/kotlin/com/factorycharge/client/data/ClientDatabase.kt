package com.factorycharge.client.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters

/**
 * قاعدة بيانات العميل: طلبات معلقة + نسخة عرض فقط من الحساب. لا قيود مالية هنا.
 * نفس سياسة الإصدارات: بعد تجميد schema 1 يلزم Migration صريحة، وممنوع destructive migration.
 * (إن ثبّتَّ APK تجريبياً سابقاً فلا تأثير لأن مخطط العميل لم يتغير، لكن الأفضل إعادة التثبيت.)
 */
@Database(
    entities = [PendingRequestEntity::class, WalletSnapshotEntity::class],
    version = 1,
    exportSchema = true,
)
@TypeConverters(Converters::class)
abstract class ClientDatabase : RoomDatabase() {
    abstract fun pendingRequestDao(): PendingRequestDao
    abstract fun walletSnapshotDao(): WalletSnapshotDao

    companion object {
        fun build(context: Context): ClientDatabase =
            Room.databaseBuilder(context.applicationContext, ClientDatabase::class.java, "factorycharge_client.db")
                .build()
    }
}
