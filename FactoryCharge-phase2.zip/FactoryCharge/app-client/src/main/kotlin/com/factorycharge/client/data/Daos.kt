package com.factorycharge.client.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface PendingRequestDao {
    /** الاسم هنا يجب أن يطابق RequestStatus.PENDING_LOCAL. */
    @Query("SELECT COUNT(*) FROM pending_requests WHERE status = 'PENDING_LOCAL'")
    fun observePendingCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(request: PendingRequestEntity)
}

@Dao
interface WalletSnapshotDao {
    @Query("SELECT * FROM wallet_snapshot ORDER BY issuedAtMillis DESC LIMIT 1")
    fun observeLatest(): Flow<WalletSnapshotEntity?>

    /**
     * للاستخدام من طبقة الاستلام فقط (تُبنى في مرحلة لاحقة بعد تصميم آلية التحقق).
     * يجب ألا تستدعيها أي شاشة مباشرة.
     */
    @Upsert
    suspend fun replaceFromAdmin(snapshot: WalletSnapshotEntity)
}
