package com.factorycharge.client.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.factorycharge.core.model.NetworkProvider
import com.factorycharge.core.model.RequestStatus
import com.factorycharge.core.model.ServiceType

/** طلب أنشأه العميل محلياً. ليس قيداً مالياً ولا يغيّر أي رصيد. */
@Entity(tableName = "pending_requests", indices = [Index("status")])
data class PendingRequestEntity(
    @PrimaryKey val id: String,
    val customerId: String,
    val provider: NetworkProvider,
    val serviceType: ServiceType,
    val targetPhone: String,
    val amountMinor: Long,
    val status: RequestStatus,
    val createdAtMillis: Long,
    val updatedAtMillis: Long,
    val note: String?,
)

/**
 * نسخة للعرض فقط من حساب العميل كما أصدرها المسؤول.
 * لا يوجد في هذا التطبيق جدول للقيود المالية المعتمدة عمداً.
 * هذه النسخة مجرد كاش غير موثَّق في المرحلة 1: لا توقيع ولا تحقق من مصدرها بعد،
 * ويمكن تعديلها من أي شخص يتحكم بالهاتف. لا تُبنى عليها أي عملية مالية.
 */
@Entity(tableName = "wallet_snapshot")
data class WalletSnapshotEntity(
    @PrimaryKey val customerId: String,
    val balanceMinor: Long,
    val debtMinor: Long,
    val currencyCode: String,
    val sequence: Long,
    val issuedAtMillis: Long,
)
