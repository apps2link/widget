package com.factorycharge.client.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Button
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.factorycharge.client.R
import com.factorycharge.client.data.WalletSnapshotEntity
import com.factorycharge.core.design.EmptyState
import com.factorycharge.core.design.ErrorState
import com.factorycharge.core.design.InfoBanner
import com.factorycharge.core.design.LoadingState
import com.factorycharge.core.design.StatCard
import com.factorycharge.core.design.UiState
import com.factorycharge.core.util.Money

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClientHomeScreen(
    viewModel: ClientHomeViewModel = viewModel(factory = ClientHomeViewModel.Factory),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(title = { Text(stringResource(R.string.home_title)) })
        },
    ) { padding ->
        Box(modifier = Modifier.padding(padding).fillMaxSize()) {
            when (val s = state) {
                UiState.Loading -> LoadingState()
                is UiState.Error -> ErrorState(onRetry = viewModel::load)
                is UiState.Success -> ClientHomeContent(s.data)
            }
        }
    }
}

@Composable
private fun ClientHomeContent(data: ClientHomeData) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        InfoBanner(
            text = stringResource(R.string.home_readonly_banner),
            icon = Icons.Default.Info,
        )
        val wallet = data.wallet
        if (wallet == null) {
            EmptyState(
                icon = Icons.Default.Person,
                title = stringResource(R.string.wallet_empty_title),
                message = stringResource(R.string.wallet_empty_message),
            )
        } else {
            WalletCard(wallet)
        }
        StatCard(
            label = stringResource(R.string.stat_pending_requests),
            value = data.pendingRequests.toString(),
            icon = Icons.Default.Notifications,
            modifier = Modifier.fillMaxWidth(),
        )
        // مُعطَّل عمداً في المرحلة الأولى: إنشاء الطلبات يُبنى في مرحلة لاحقة.
        Button(
            onClick = {},
            enabled = false,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
        ) {
            Text(stringResource(R.string.action_new_request_soon))
        }
    }
}

@Composable
private fun WalletCard(wallet: WalletSnapshotEntity) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            WalletValue(
                label = stringResource(R.string.wallet_balance),
                value = Money.format(wallet.balanceMinor, wallet.currencyCode),
                modifier = Modifier.weight(1f),
            )
            WalletValue(
                label = stringResource(R.string.wallet_debt),
                value = Money.format(wallet.debtMinor, wallet.currencyCode),
                modifier = Modifier.weight(1f),
            )
        }
    }
}

@Composable
private fun WalletValue(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(
            text = value,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
        )
    }
}
