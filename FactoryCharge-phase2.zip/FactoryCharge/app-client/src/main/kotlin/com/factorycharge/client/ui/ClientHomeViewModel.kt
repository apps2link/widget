package com.factorycharge.client.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.factorycharge.client.ClientApp
import com.factorycharge.client.data.ClientDatabase
import com.factorycharge.client.data.WalletSnapshotEntity
import com.factorycharge.core.design.UiState
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

data class ClientHomeData(
    val wallet: WalletSnapshotEntity?,
    val pendingRequests: Int,
)

class ClientHomeViewModel(private val database: ClientDatabase) : ViewModel() {

    private val _state = MutableStateFlow<UiState<ClientHomeData>>(UiState.Loading)
    val state: StateFlow<UiState<ClientHomeData>> = _state.asStateFlow()

    private var loadJob: Job? = null

    init {
        load()
    }

    fun load() {
        loadJob?.cancel()
        _state.value = UiState.Loading
        loadJob = viewModelScope.launch {
            combine(
                database.walletSnapshotDao().observeLatest(),
                database.pendingRequestDao().observePendingCount(),
            ) { wallet, pending ->
                ClientHomeData(wallet, pending)
            }
                .catch { _state.value = UiState.Error(it) }
                .collect { _state.value = UiState.Success(it) }
        }
    }

    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                ClientHomeViewModel((this[APPLICATION_KEY] as ClientApp).database)
            }
        }
    }
}
