package com.factorycharge.core.ledger

import kotlin.math.abs

/**
 * حالة حساب عميل مشتقة من الدفتر. كل المبالغ بالقروش (Long).
 * الرصيد والمديونية غير سالبين دائماً.
 */
data class AccountState(
    val balanceMinor: Long,
    val debtMinor: Long,
    val creditLimitMinor: Long,
) {
    init {
        require(balanceMinor >= 0) { "balance must not be negative" }
        require(debtMinor >= 0) { "debt must not be negative" }
        require(creditLimitMinor >= 0) { "credit limit must not be negative" }
    }

    val availableCreditMinor: Long get() = (creditLimitMinor - debtMinor).coerceAtLeast(0)
}

/** قيد مخطَّط: يغيّر الرصيد أو المديونية (واحداً فقط، والآخر صفر). */
data class Posting(
    val type: LedgerEntryType,
    val balanceDeltaMinor: Long,
    val debtDeltaMinor: Long,
) {
    init {
        require((balanceDeltaMinor == 0L) != (debtDeltaMinor == 0L)) {
            "a posting must change exactly one of balance or debt"
        }
    }

    val amountMinor: Long
        get() = if (balanceDeltaMinor != 0L) abs(balanceDeltaMinor) else abs(debtDeltaMinor)
}

sealed interface PlanResult {
    data class Ok(val postings: List<Posting>, val resulting: AccountState) : PlanResult
    data class Rejected(val reason: OperationRejection) : PlanResult
}

/**
 * قواعد مالية نقية (بدون قاعدة بيانات ولا Android). هي المكان الوحيد الذي يقرر كيف
 * يُوزَّع المبلغ، ويُختبر بالكامل على JVM. القاعدة تقرر فقط؛ التسجيل الذري يتم في المستودع.
 */
object LedgerRules {

    /** إيداع نقدي: تُسوّى المديونية أولاً ثم يُضاف الباقي للمحفظة. */
    fun planDeposit(state: AccountState, amountMinor: Long): PlanResult {
        if (amountMinor <= 0) return reject(OperationRejection.INVALID_AMOUNT)
        val settle = minOf(amountMinor, state.debtMinor)
        val credit = amountMinor - settle
        val newBalance = addOrNull(state.balanceMinor, credit) ?: return reject(OperationRejection.AMOUNT_OVERFLOW)
        val postings = buildList {
            if (settle > 0) add(Posting(LedgerEntryType.DEBT_SETTLEMENT, 0L, -settle))
            if (credit > 0) add(Posting(LedgerEntryType.WALLET_CREDIT, credit, 0L))
        }
        return PlanResult.Ok(postings, state.copy(balanceMinor = newBalance, debtMinor = state.debtMinor - settle))
    }

    /** سحب نقدي: لا يتجاوز الرصيد المتاح (الرصيد بعد استبعاد ما سُوّي به دين) ولا يجعله سالباً. */
    fun planWithdrawal(state: AccountState, amountMinor: Long): PlanResult {
        if (amountMinor <= 0) return reject(OperationRejection.INVALID_AMOUNT)
        if (amountMinor > state.balanceMinor) return reject(OperationRejection.INSUFFICIENT_BALANCE)
        return PlanResult.Ok(
            listOf(Posting(LedgerEntryType.CASH_WITHDRAWAL, -amountMinor, 0L)),
            state.copy(balanceMinor = state.balanceMinor - amountMinor),
        )
    }

    /**
     * سياسة partial لعملية مستقبلية: يُستخدم الرصيد المتاح أولاً، والفرق يصبح مديونية بشرط
     * ألا تتجاوز إجمالي المديونية الحد الائتماني. إن لم يُسمح بذلك تُرفض العملية كلها.
     * (لا ينفّذ شحناً؛ هو قاعدة جاهزة لتستدعيها مرحلة الشحن لاحقاً.)
     */
    fun planPartialConsumption(state: AccountState, amountMinor: Long): PlanResult {
        if (amountMinor <= 0) return reject(OperationRejection.INVALID_AMOUNT)
        val fromBalance = minOf(state.balanceMinor, amountMinor)
        val shortfall = amountMinor - fromBalance
        val newDebt = addOrNull(state.debtMinor, shortfall) ?: return reject(OperationRejection.AMOUNT_OVERFLOW)
        if (shortfall > 0 && newDebt > state.creditLimitMinor) {
            return reject(OperationRejection.CREDIT_LIMIT_EXCEEDED)
        }
        val postings = buildList {
            if (fromBalance > 0) add(Posting(LedgerEntryType.WALLET_DEBIT, -fromBalance, 0L))
            if (shortfall > 0) add(Posting(LedgerEntryType.DEBT_CREATED, 0L, shortfall))
        }
        return PlanResult.Ok(postings, state.copy(balanceMinor = state.balanceMinor - fromBalance, debtMinor = newDebt))
    }

    /**
     * قيد عكسي لقيد سابق: نفس الأثر بإشارة معاكسة. لا يجعل الرصيد أو المديونية سالبة.
     * لا يُطبَّق الحد الائتماني على العكس (تصحيح لما حدث فعلاً).
     */
    fun planReversal(state: AccountState, original: Posting): PlanResult {
        if (original.type == LedgerEntryType.REVERSAL) return reject(OperationRejection.CANNOT_REVERSE_A_REVERSAL)
        val newBalance = addOrNull(state.balanceMinor, -original.balanceDeltaMinor)
            ?: return reject(OperationRejection.AMOUNT_OVERFLOW)
        val newDebt = addOrNull(state.debtMinor, -original.debtDeltaMinor)
            ?: return reject(OperationRejection.AMOUNT_OVERFLOW)
        if (newBalance < 0) return reject(OperationRejection.REVERSAL_NEGATIVE_BALANCE)
        if (newDebt < 0) return reject(OperationRejection.REVERSAL_NEGATIVE_DEBT)
        return PlanResult.Ok(
            listOf(Posting(LedgerEntryType.REVERSAL, -original.balanceDeltaMinor, -original.debtDeltaMinor)),
            state.copy(balanceMinor = newBalance, debtMinor = newDebt),
        )
    }

    /** يطبّق قيداً على حالة (تفترض أن الخطة سبق التحقق منها). */
    fun apply(state: AccountState, posting: Posting): AccountState = state.copy(
        balanceMinor = state.balanceMinor + posting.balanceDeltaMinor,
        debtMinor = state.debtMinor + posting.debtDeltaMinor,
    )

    private fun reject(reason: OperationRejection) = PlanResult.Rejected(reason)

    /** جمع Long مع كشف الفيض بدون استثناءات؛ يعيد null عند الفيض. */
    private fun addOrNull(a: Long, b: Long): Long? {
        val r = a + b
        return if (((a xor r) and (b xor r)) < 0) null else r
    }
}
