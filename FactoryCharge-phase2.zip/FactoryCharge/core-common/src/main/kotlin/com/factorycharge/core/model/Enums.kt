package com.factorycharge.core.model

import androidx.annotation.StringRes
import com.factorycharge.core.R

/**
 * الدور المُعلَن للجهاز. **هذا تحقق برمجي (Programming contract) وليس نظام صلاحيات أمنياً.**
 * أي جهاز معدَّل أو رسالة مصنوعة يدوياً تستطيع ادعاء أي دور. الحماية الفعلية تأتي لاحقاً من
 * تحقق جهاز المسؤول من كل ما يصله (هوية الجهاز، التوقيع، منع إعادة الإرسال)، ولا يُقبل أي
 * `DeviceRole` يأتي من الشبكة كدليل على الصلاحية.
 */
enum class DeviceRole { ADMIN, CLIENT }

/** مزودو الشبكة. القائمة أولية وقابلة للتعديل في مرحلة لاحقة. */
enum class NetworkProvider(@StringRes val labelRes: Int) {
    VODAFONE(R.string.provider_vodafone),
    ORANGE(R.string.provider_orange),
    ETISALAT(R.string.provider_etisalat),
    WE(R.string.provider_we),
    OTHER(R.string.provider_other),
}

/** أنواع الخدمات. القائمة أولية وقابلة للتعديل في مرحلة لاحقة. */
enum class ServiceType(@StringRes val labelRes: Int) {
    BALANCE_TOPUP(R.string.service_balance_topup),
    DATA_PACKAGE(R.string.service_data_package),
    MINUTES_PACKAGE(R.string.service_minutes_package),
    OTHER(R.string.service_other),
}

/**
 * حالة الطلب. القاعدة المقصودة: المسؤول وحده ينقل الطلب إلى المراجعة/الموافقة/الرفض/التنفيذ،
 * والعميل يستطيع فقط الإرسال والإلغاء.
 *
 * تنبيه: [canTransitionTo] يفحص دوراً **مُعلَناً** ([DeviceRole]) وليس هوية موثَّقة؛ فهو يمنع
 * أخطاء البرمجة الصادقة فقط ولا يمنع التزوير. حالة الطلب المعتمدة هي ما يسجله جهاز المسؤول
 * محلياً؛ أي حالة تصل من العميل تُعامَل كطلب/اقتراح لا كحقيقة.
 */
enum class RequestStatus(@StringRes val labelRes: Int) {
    PENDING_LOCAL(R.string.status_pending_local),
    SUBMITTED(R.string.status_submitted),
    UNDER_REVIEW(R.string.status_under_review),
    APPROVED(R.string.status_approved),
    REJECTED(R.string.status_rejected),
    EXECUTED(R.string.status_executed),
    CANCELLED(R.string.status_cancelled);

    fun nextStatuses(): Set<RequestStatus> = when (this) {
        PENDING_LOCAL -> setOf(SUBMITTED, CANCELLED)
        SUBMITTED -> setOf(UNDER_REVIEW, APPROVED, REJECTED, CANCELLED)
        UNDER_REVIEW -> setOf(APPROVED, REJECTED)
        APPROVED -> setOf(EXECUTED)
        REJECTED, EXECUTED, CANCELLED -> emptySet()
    }

    val isTerminal: Boolean get() = nextStatuses().isEmpty()

    fun canTransitionTo(next: RequestStatus, actor: DeviceRole): Boolean {
        if (next !in nextStatuses()) return false
        return when (actor) {
            DeviceRole.ADMIN -> true
            DeviceRole.CLIENT -> next == SUBMITTED || next == CANCELLED
        }
    }
}
