package com.factorycharge.core.model

/*
 * ملاحظة عن المبالغ: كل المبالغ تُخزَّن كأعداد صحيحة بأصغر وحدة للعملة (Long)،
 * وليس Double، لتجنب أخطاء الكسور العشرية في الحسابات المالية.
 */

data class Customer(
    val id: String,
    val displayName: String,
    val phone: String,
    val createdAtMillis: Long,
    val isActive: Boolean = true,
) {
    init {
        require(id.isNotBlank()) { "id must not be blank" }
        require(displayName.isNotBlank()) { "displayName must not be blank" }
    }
}

data class ChargeRequest(
    val id: String,
    val customerId: String,
    val provider: NetworkProvider,
    val serviceType: ServiceType,
    val targetPhone: String,
    val amountMinor: Long,
    val status: RequestStatus,
    val createdAtMillis: Long,
    val updatedAtMillis: Long,
    val note: String? = null,
) {
    init {
        require(id.isNotBlank()) { "id must not be blank" }
        require(customerId.isNotBlank()) { "customerId must not be blank" }
        require(targetPhone.isNotBlank()) { "targetPhone must not be blank" }
        require(amountMinor > 0) { "amountMinor must be positive" }
        require(updatedAtMillis >= createdAtMillis) { "updatedAt must not precede createdAt" }
    }
}

/**
 * نسخة للقراءة فقط من حساب العميل، يصدرها المسؤول.
 * [sequence] رقم تصاعدي يحدده المسؤول ليعرف العميل أيّ نسخة هي الأحدث.
 * دلالته الدقيقة (مثلاً آخر sequence عالمي في الدفتر دخل في اللقطة) لم تُحسم بعد وتُثبَّت في
 * التصميم المالي. اللقطة نسخة عرض غير موثَّقة حالياً.
 */
data class WalletSnapshot(
    val customerId: String,
    val balanceMinor: Long,
    val debtMinor: Long,
    val currencyCode: String,
    val sequence: Long,
    val issuedAtMillis: Long,
) {
    init {
        require(customerId.isNotBlank()) { "customerId must not be blank" }
        require(debtMinor >= 0) { "debtMinor must not be negative" }
        require(sequence >= 0) { "sequence must not be negative" }
        require(currencyCode.isNotBlank()) { "currencyCode must not be blank" }
    }
}
