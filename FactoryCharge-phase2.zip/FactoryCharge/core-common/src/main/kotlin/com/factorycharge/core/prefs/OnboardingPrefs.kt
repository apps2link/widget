package com.factorycharge.core.prefs

import android.content.Context

/** يحفظ محلياً فقط هل شاهد المستخدم الشاشة التعريفية. */
class OnboardingPrefs(context: Context, fileName: String) {
    private val prefs = context.getSharedPreferences(fileName, Context.MODE_PRIVATE)

    val isDone: Boolean get() = prefs.getBoolean(KEY_DONE, false)

    fun markDone() {
        prefs.edit().putBoolean(KEY_DONE, true).apply()
    }

    private companion object {
        const val KEY_DONE = "onboarding_done"
    }
}
