package com.factorycharge.core.transport

/*
 * عقد الاتصال بين الأجهزة (واجهات فقط).
 *
 * لا يوجد أي تنفيذ في المرحلة الأولى عمداً. لا يجوز استخدام هذا العقد لنقل بيانات
 * مالية قبل تصميم آلية آمنة تشمل: توثيق الأجهزة، توقيع الرسائل، منع إعادة الإرسال
 * (replay)، وترتيب الرسائل. أي قناة (اتصال مباشر، ترحيل عبر أجهزة وسيطة...)
 * ستُنفَّذ لاحقاً كـ DeviceTransport منفصل دون تغيير بقية النظام.
 */

enum class EnvelopeType { CHARGE_REQUEST, REQUEST_DECISION, WALLET_SNAPSHOT }

class TransportEnvelope(
    val messageId: String,
    val type: EnvelopeType,
    val senderDeviceId: String,
    val recipientDeviceId: String,
    val createdAtMillis: Long,
    val payload: ByteArray,
)

sealed interface TransportResult {
    data object Delivered : TransportResult
    data class Failed(val reason: String) : TransportResult
}

interface DeviceTransport {
    /** اسم القناة لأغراض العرض والسجلات. */
    val name: String

    suspend fun isAvailable(): Boolean

    suspend fun send(envelope: TransportEnvelope): TransportResult
}
