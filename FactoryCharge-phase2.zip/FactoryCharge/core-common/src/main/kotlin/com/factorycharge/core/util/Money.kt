package com.factorycharge.core.util

import java.math.BigDecimal

object Money {
    /** رمز العملة المعتمد في التطبيق (الجنيه المصري). */
    const val DEFAULT_CURRENCY_CODE = "EGP"

    /**
     * يعرض المبلغ المخزَّن بأصغر وحدة. يفترض منزلتين عشريتين (قرش لكل 100).
     * إن احتجنا عملة بعدد منازل مختلف نوسّع هذه الدالة لاحقاً.
     */
    fun format(amountMinor: Long, currencyCode: String): String =
        "${BigDecimal.valueOf(amountMinor, 2).toPlainString()} $currencyCode"

    /** نص عشري بسيط بدون فواصل آلاف (لتعبئة حقول الإدخال)، مثل 100.00 */
    fun plain(amountMinor: Long): String = BigDecimal.valueOf(amountMinor, 2).toPlainString()

    /** عرض مقروء بفواصل آلاف ومنزلتين عشريتين، مثل 1,234.50 أو -2.50 (بدون Double). */
    fun formatGrouped(amountMinor: Long): String {
        val plain = BigDecimal.valueOf(amountMinor, 2).abs().toPlainString()
        val intPart = plain.substringBefore('.')
        val frac = plain.substringAfter('.', "00")
        val grouped = intPart.reversed().chunked(3).joinToString(",").reversed()
        return (if (amountMinor < 0) "-" else "") + grouped + "." + frac
    }

    /**
     * يحوّل نصاً أدخله المستخدم إلى قروش. يقبل الأرقام العربية، والفاصلة العشرية . أو , أو ٫،
     * وحتى منزلتين عشريتين. يعيد null لأي شيء آخر (سالب، حروف، 3 منازل، فيض...).
     * لا يستخدم Double إطلاقاً. الصفر يُرجَع كـ 0 وترفضه قواعد الدفتر.
     */
    fun parseToMinor(input: String): Long? {
        val cleaned = toAsciiDigits(input.trim())
            .replace('٫', '.')
            .replace(",", ".")
            .filterNot { it.isWhitespace() || it == '٬' }
        if (!Regex("^\\d+(\\.\\d{1,2})?$").matches(cleaned)) return null
        return try {
            BigDecimal(cleaned).movePointRight(2).longValueExact()
        } catch (e: ArithmeticException) {
            null
        }
    }

    /** يحوّل الأرقام العربية-الهندية والفارسية إلى 0-9. */
    fun toAsciiDigits(text: String): String = buildString(text.length) {
        for (ch in text) {
            append(
                when (ch) {
                    in '\u0660'..'\u0669' -> '0' + (ch - '\u0660')
                    in '\u06F0'..'\u06F9' -> '0' + (ch - '\u06F0')
                    else -> ch
                },
            )
        }
    }
}
