package com.factorycharge.core.util

object PhoneNumber {
    /**
     * يوحّد شكل الرقم: يحوّل الأرقام العربية/الفارسية إلى لاتينية، ويحذف المسافات والشرطات والأقواس،
     * ويحتفظ بعلامة + الأولى إن وُجدت. يعيد null إن لم يكن الرقم من 7 إلى 15 خانة.
     * ملاحظة: "+2010..." و"010..." يُعدّان رقمين مختلفين (لا نخمّن مفتاح الدولة).
     */
    fun normalize(raw: String): String? {
        val mapped = Money.toAsciiDigits(raw.trim())
        val plus = mapped.startsWith("+")
        val body = mapped.removePrefix("+").filterNot { it.isWhitespace() || it == '-' || it == '(' || it == ')' }
        if (body.length !in 7..15 || !body.all { it in '0'..'9' }) return null
        return if (plus) "+$body" else body
    }
}
