package com.factorycharge.core

import com.factorycharge.core.ledger.AccountState
import com.factorycharge.core.ledger.LedgerEntryType
import com.factorycharge.core.ledger.LedgerRules
import com.factorycharge.core.ledger.OperationRejection
import com.factorycharge.core.ledger.PlanResult
import com.factorycharge.core.ledger.Posting
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test

class LedgerRulesTest {

    private fun state(balance: Long = 0, debt: Long = 0, limit: Long = 0) = AccountState(balance, debt, limit)

    private fun ok(r: PlanResult): PlanResult.Ok = r as PlanResult.Ok

    private fun rejected(r: PlanResult): OperationRejection = (r as PlanResult.Rejected).reason

    // ---- 1) إيداع بدون مديونية
    @Test
    fun depositWithoutDebtGoesFullyToWallet() {
        val plan = ok(LedgerRules.planDeposit(state(balance = 500), 15_000))
        assertEquals(listOf(Posting(LedgerEntryType.WALLET_CREDIT, 15_000, 0)), plan.postings)
        assertEquals(15_500L, plan.resulting.balanceMinor)
        assertEquals(0L, plan.resulting.debtMinor)
    }

    // ---- 2) مديونية أكبر من المدفوع
    @Test
    fun depositSmallerThanDebtOnlySettlesDebt() {
        val plan = ok(LedgerRules.planDeposit(state(debt = 10_000), 4_000))
        assertEquals(listOf(Posting(LedgerEntryType.DEBT_SETTLEMENT, 0, -4_000)), plan.postings)
        assertEquals(0L, plan.resulting.balanceMinor)
        assertEquals(6_000L, plan.resulting.debtMinor)
    }

    // ---- 3) مديونية أقل من المدفوع (مثال المواصفات: دين 100 ودفع 150)
    @Test
    fun depositLargerThanDebtSettlesThenCreditsRemainder() {
        val plan = ok(LedgerRules.planDeposit(state(debt = 10_000), 15_000))
        assertEquals(
            listOf(
                Posting(LedgerEntryType.DEBT_SETTLEMENT, 0, -10_000),
                Posting(LedgerEntryType.WALLET_CREDIT, 5_000, 0),
            ),
            plan.postings,
        )
        assertEquals(5_000L, plan.resulting.balanceMinor)
        assertEquals(0L, plan.resulting.debtMinor)
    }

    @Test
    fun depositEqualToDebtLeavesNoWalletCredit() {
        val plan = ok(LedgerRules.planDeposit(state(debt = 10_000), 10_000))
        assertEquals(1, plan.postings.size)
        assertEquals(LedgerEntryType.DEBT_SETTLEMENT, plan.postings[0].type)
        assertEquals(0L, plan.resulting.balanceMinor)
        assertEquals(0L, plan.resulting.debtMinor)
    }

    // ---- 4) سحب مساوٍ للرصيد
    @Test
    fun withdrawalEqualToBalanceIsAllowedAndLeavesZero() {
        val plan = ok(LedgerRules.planWithdrawal(state(balance = 7_000), 7_000))
        assertEquals(listOf(Posting(LedgerEntryType.CASH_WITHDRAWAL, -7_000, 0)), plan.postings)
        assertEquals(0L, plan.resulting.balanceMinor)
    }

    // ---- 5) رفض السحب الأكبر من الرصيد
    @Test
    fun withdrawalGreaterThanBalanceIsRejected() {
        assertEquals(OperationRejection.INSUFFICIENT_BALANCE, rejected(LedgerRules.planWithdrawal(state(balance = 7_000), 7_001)))
        assertEquals(OperationRejection.INSUFFICIENT_BALANCE, rejected(LedgerRules.planWithdrawal(state(), 1)))
    }

    // ---- 6) رفض المبالغ الصفرية والسالبة
    @Test
    fun zeroAndNegativeAmountsAreRejectedEverywhere() {
        val s = state(balance = 1_000, debt = 500, limit = 5_000)
        listOf(0L, -1L, -10_000L, Long.MIN_VALUE).forEach { amount ->
            assertEquals(OperationRejection.INVALID_AMOUNT, rejected(LedgerRules.planDeposit(s, amount)))
            assertEquals(OperationRejection.INVALID_AMOUNT, rejected(LedgerRules.planWithdrawal(s, amount)))
            assertEquals(OperationRejection.INVALID_AMOUNT, rejected(LedgerRules.planPartialConsumption(s, amount)))
        }
    }

    @Test
    fun depositOverflowIsRejectedInsteadOfWrapping() {
        assertEquals(OperationRejection.AMOUNT_OVERFLOW, rejected(LedgerRules.planDeposit(state(balance = Long.MAX_VALUE), 1)))
    }

    // ---- سياسة partial
    @Test
    fun partialConsumptionUsesBalanceFirstThenCreatesDebt() {
        val plan = ok(LedgerRules.planPartialConsumption(state(balance = 3_000, limit = 10_000), 8_000))
        assertEquals(
            listOf(
                Posting(LedgerEntryType.WALLET_DEBIT, -3_000, 0),
                Posting(LedgerEntryType.DEBT_CREATED, 0, 5_000),
            ),
            plan.postings,
        )
        assertEquals(0L, plan.resulting.balanceMinor)
        assertEquals(5_000L, plan.resulting.debtMinor)
    }

    @Test
    fun partialConsumptionCoveredByBalanceCreatesNoDebt() {
        val plan = ok(LedgerRules.planPartialConsumption(state(balance = 9_000), 9_000))
        assertEquals(listOf(Posting(LedgerEntryType.WALLET_DEBIT, -9_000, 0)), plan.postings)
        assertEquals(0L, plan.resulting.debtMinor)
    }

    @Test
    fun partialConsumptionBeyondCreditLimitIsRejectedEntirely() {
        // الرصيد 30 + الحد 50 لا يكفيان لعملية 100 (يتبقى 70 > 50)
        assertEquals(
            OperationRejection.CREDIT_LIMIT_EXCEEDED,
            rejected(LedgerRules.planPartialConsumption(state(balance = 3_000, limit = 5_000), 10_000)),
        )
        // الدين الحالي يُحتسب ضمن الحد
        assertEquals(
            OperationRejection.CREDIT_LIMIT_EXCEEDED,
            rejected(LedgerRules.planPartialConsumption(state(debt = 4_500, limit = 5_000), 1_000)),
        )
    }

    @Test
    fun partialConsumptionExactlyAtLimitIsAllowed() {
        val plan = ok(LedgerRules.planPartialConsumption(state(limit = 5_000), 5_000))
        assertEquals(5_000L, plan.resulting.debtMinor)
    }

    // ---- القيد العكسي
    @Test
    fun reversalRestoresPreviousState() {
        val before = state(balance = 2_000)
        val deposit = ok(LedgerRules.planDeposit(before, 3_000))
        val credit = deposit.postings.single()
        val reversal = ok(LedgerRules.planReversal(deposit.resulting, credit))
        assertEquals(before.balanceMinor, reversal.resulting.balanceMinor)
        assertEquals(LedgerEntryType.REVERSAL, reversal.postings.single().type)
        assertEquals(-3_000L, reversal.postings.single().balanceDeltaMinor)
    }

    @Test
    fun reversalThatWouldGoNegativeIsRejected() {
        val credit = Posting(LedgerEntryType.WALLET_CREDIT, 3_000, 0)
        assertEquals(OperationRejection.REVERSAL_NEGATIVE_BALANCE, rejected(LedgerRules.planReversal(state(balance = 1_000), credit)))
        val settle = Posting(LedgerEntryType.DEBT_SETTLEMENT, 0, -3_000)
        // عكس التسوية يعيد الدين (لا يصبح سالباً) فهو مسموح
        assertEquals(3_000L, ok(LedgerRules.planReversal(state(), settle)).resulting.debtMinor)
        val created = Posting(LedgerEntryType.DEBT_CREATED, 0, 3_000)
        assertEquals(OperationRejection.REVERSAL_NEGATIVE_DEBT, rejected(LedgerRules.planReversal(state(debt = 1_000), created)))
    }

    @Test
    fun reversalOfReversalIsRejected() {
        val reversal = Posting(LedgerEntryType.REVERSAL, 100, 0)
        assertEquals(OperationRejection.CANNOT_REVERSE_A_REVERSAL, rejected(LedgerRules.planReversal(state(balance = 500), reversal)))
    }

    @Test
    fun postingMustChangeExactlyOneSide() {
        assertThrows(IllegalArgumentException::class.java) { Posting(LedgerEntryType.WALLET_CREDIT, 0, 0) }
        assertThrows(IllegalArgumentException::class.java) { Posting(LedgerEntryType.WALLET_CREDIT, 1, 1) }
    }

    @Test
    fun accountStateRejectsNegativeValues() {
        assertThrows(IllegalArgumentException::class.java) { AccountState(-1, 0, 0) }
        assertThrows(IllegalArgumentException::class.java) { AccountState(0, -1, 0) }
        assertThrows(IllegalArgumentException::class.java) { AccountState(0, 0, -1) }
    }

    // ---- 10) سلسلة عمليات متتابعة: لا يتغير المجموع بطريقة غير متوقعة ولا يظهر رصيد/دين سالب
    @Test
    fun longSequenceKeepsInvariantsAndExpectedTotals() {
        var s = state(limit = 50_000)
        val steps: List<(AccountState) -> PlanResult> = listOf(
            { LedgerRules.planDeposit(it, 10_000) },            // رصيد 100
            { LedgerRules.planWithdrawal(it, 3_000) },          // رصيد 70
            { LedgerRules.planPartialConsumption(it, 20_000) }, // رصيد 0، دين 130
            { LedgerRules.planDeposit(it, 10_000) },            // دين 30
            { LedgerRules.planDeposit(it, 5_000) },             // دين 0، رصيد 20
            { LedgerRules.planWithdrawal(it, 2_000) },          // رصيد 0
            { LedgerRules.planWithdrawal(it, 1) },              // مرفوض
        )
        steps.forEachIndexed { i, step ->
            when (val r = step(s)) {
                is PlanResult.Ok -> {
                    r.postings.forEach { s = LedgerRules.apply(s, it) }
                    assertEquals("state after step $i", r.resulting, s)
                    assertTrue(s.balanceMinor >= 0 && s.debtMinor >= 0)
                }
                is PlanResult.Rejected -> assertEquals(6, i)
            }
        }
        val cashIn = 10_000L + 10_000L + 5_000L
        val cashOut = 3_000L + 2_000L
        assertEquals(0L, s.balanceMinor)
        assertEquals(0L, s.debtMinor)
        // الاستهلاك 200 = 70 من الرصيد + 130 دين؛ الدين سُدِّد بالكامل
        assertEquals(cashIn - cashOut - 20_000L, s.balanceMinor - s.debtMinor)
    }
}
