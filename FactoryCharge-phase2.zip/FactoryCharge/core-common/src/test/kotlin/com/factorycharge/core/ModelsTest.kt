package com.factorycharge.core

import com.factorycharge.core.model.ChargeRequest
import com.factorycharge.core.model.DeviceRole
import com.factorycharge.core.model.NetworkProvider
import com.factorycharge.core.model.RequestStatus
import com.factorycharge.core.model.ServiceType
import com.factorycharge.core.model.WalletSnapshot
import com.factorycharge.core.util.Money
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * اختبارات للحراس البرمجية (invariants) داخل كودنا. ليست اختبارات أمنية:
 * لا تثبت أن عميلاً معدَّلاً لا يستطيع التزوير.
 */
class ModelsTest {

    @Test
    fun declaredClientRoleCanOnlySubmitOrCancel() {
        assertTrue(RequestStatus.PENDING_LOCAL.canTransitionTo(RequestStatus.SUBMITTED, DeviceRole.CLIENT))
        assertTrue(RequestStatus.SUBMITTED.canTransitionTo(RequestStatus.CANCELLED, DeviceRole.CLIENT))
        assertFalse(RequestStatus.SUBMITTED.canTransitionTo(RequestStatus.APPROVED, DeviceRole.CLIENT))
        assertFalse(RequestStatus.APPROVED.canTransitionTo(RequestStatus.EXECUTED, DeviceRole.CLIENT))
    }

    @Test
    fun declaredAdminRoleCanApproveAndExecute() {
        assertTrue(RequestStatus.SUBMITTED.canTransitionTo(RequestStatus.APPROVED, DeviceRole.ADMIN))
        assertTrue(RequestStatus.APPROVED.canTransitionTo(RequestStatus.EXECUTED, DeviceRole.ADMIN))
    }

    @Test
    fun terminalStatusesHaveNoTransitions() {
        listOf(RequestStatus.REJECTED, RequestStatus.EXECUTED, RequestStatus.CANCELLED).forEach {
            assertTrue(it.isTerminal)
        }
        assertFalse(RequestStatus.REJECTED.canTransitionTo(RequestStatus.APPROVED, DeviceRole.ADMIN))
    }

    @Test
    fun chargeRequestRejectsNonPositiveAmount() {
        assertThrows(IllegalArgumentException::class.java) {
            ChargeRequest(
                id = "r1", customerId = "c1", provider = NetworkProvider.VODAFONE,
                serviceType = ServiceType.BALANCE_TOPUP, targetPhone = "0100", amountMinor = 0,
                status = RequestStatus.PENDING_LOCAL, createdAtMillis = 1, updatedAtMillis = 1,
            )
        }
    }

    @Test
    fun walletSnapshotRejectsNegativeDebt() {
        assertThrows(IllegalArgumentException::class.java) {
            WalletSnapshot("c1", 0, -1, "EGP", 0, 1)
        }
    }

    @Test
    fun moneyFormatsMinorUnits() {
        assertEquals("123.45 EGP", Money.format(12345, "EGP"))
        assertEquals("0.05 EGP", Money.format(5, "EGP"))
        assertEquals("-2.50 EGP", Money.format(-250, "EGP"))
    }
}
