package com.factorycharge.core

import com.factorycharge.core.util.Money
import com.factorycharge.core.util.PhoneNumber
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class MoneyTest {
    @Test
    fun formatGroupedAddsThousandsSeparators() {
        assertEquals("0.00", Money.formatGrouped(0))
        assertEquals("0.05", Money.formatGrouped(5))
        assertEquals("1,234.50", Money.formatGrouped(123_450))
        assertEquals("1,234,567.89", Money.formatGrouped(123_456_789))
        assertEquals("-2.50", Money.formatGrouped(-250))
        assertEquals("100.00", Money.formatGrouped(10_000))
    }

    @Test
    fun parseAcceptsCommonForms() {
        assertEquals(15_000L, Money.parseToMinor("150"))
        assertEquals(15_050L, Money.parseToMinor("150.5"))
        assertEquals(15_050L, Money.parseToMinor("150.50"))
        assertEquals(15_050L, Money.parseToMinor("150,50"))
        assertEquals(15_050L, Money.parseToMinor("١٥٠٫٥٠"))
        assertEquals(15_000L, Money.parseToMinor(" ١٥٠ "))
        assertEquals(5L, Money.parseToMinor("0.05"))
        assertEquals(0L, Money.parseToMinor("0"))
    }

    @Test
    fun parseRejectsInvalidInput() {
        listOf("", " ", "-5", "1.234", "1,234.5", "abc", "1.2.3", "5-", "+5", ".5", "99999999999999999999").forEach {
            assertNull("should reject '$it'", Money.parseToMinor(it))
        }
    }

    @Test
    fun phoneNormalization() {
        assertEquals("01001234567", PhoneNumber.normalize("0100 123-4567"))
        assertEquals("01001234567", PhoneNumber.normalize("٠١٠٠١٢٣٤٥٦٧"))
        assertEquals("+201001234567", PhoneNumber.normalize("+20 100 123 4567"))
        assertNull(PhoneNumber.normalize("12345"))
        assertNull(PhoneNumber.normalize("01001234abc"))
        assertNull(PhoneNumber.normalize(""))
    }
}
