package com.glowwidgets.app

import android.Manifest
import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import android.app.DatePickerDialog
import android.os.Handler
import android.os.Looper
import java.util.Calendar
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    private val previews = mutableListOf<Pair<ImageView, BaseProvider>>()
    private val ui = Handler(Looper.getMainLooper())
    private val frame = object : Runnable {
        override fun run() {
            val d = resources.displayMetrics.density
            for ((iv, p) in previews) {
                var wp = p.defW * d; var hp = p.defH * d
                val sc = min(1f, 440f / max(wp, hp)); wp *= sc; hp *= sc
                try { iv.setImageBitmap(p.draw(this@MainActivity, wp.toInt(), hp.toInt())) } catch (_: Throwable) {}
            }
            ui.postDelayed(this, 120)
        }
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun btn(label: String, bg: Int, onClick: () -> Unit) = Button(this).apply {
        text = label; setTextColor(Color.WHITE); isAllCaps = false; textSize = 14f
        background = GradientDrawable().apply { cornerRadius = dp(22).toFloat(); setColor(bg) }
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8) }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.statusBarColor = 0xFF0A0A0A.toInt(); window.navigationBarColor = 0xFF0A0A0A.toInt()
        val sv = ScrollView(this); sv.setBackgroundColor(0xFF0A0A0A.toInt())
        val root = LinearLayout(this); root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(18), dp(36), dp(18), dp(36)); root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        sv.addView(root)

        root.addView(TextView(this).apply { text = "ويدجتس الوهج"; setTextColor(Color.WHITE); textSize = 28f; typeface = Typeface.DEFAULT_BOLD })
        root.addView(TextView(this).apply {
            text = "ساعة • موسيقى • منبه • قبلة • بوصلة • بطارية • إشعارات"
            setTextColor(0xFF9AA0A6.toInt()); textSize = 13f; setPadding(0, dp(4), 0, dp(10))
        })
        root.addView(btn("١) تشغيل الخدمة والأذونات (موقع + إشعارات)", 0xFFFF5A12.toInt()) { askPerms() })
        root.addView(btn("٢) السماح بالوصول للإشعارات والموسيقى", 0xFF8A3DFF.toInt()) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })

        root.addView(TextView(this).apply {
            text = "قوة الأنيميشن في الويدجتس"; setTextColor(Color.WHITE); textSize = 15f
            setPadding(0, dp(16), 0, dp(2))
        })
        val sp = getSharedPreferences("cfg", 0)
        val modes = LinearLayout(this); modes.orientation = LinearLayout.HORIZONTAL
        val labels = listOf("إيقاف", "اقتصادي", "كامل")
        labels.forEachIndexed { idx, lb ->
            modes.addView(Button(this).apply {
                text = lb; isAllCaps = false; setTextColor(Color.WHITE)
                background = GradientDrawable().apply { cornerRadius = dp(20).toFloat(); setColor(if (sp.getInt("anim", 2) == idx) 0xFFFF5A12.toInt() else 0xFF2A2A2C.toInt()) }
                layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(6) }
                setOnClickListener {
                    sp.edit().putInt("anim", idx).apply()
                    for (j in 0 until modes.childCount)
                        (modes.getChildAt(j).background as GradientDrawable).setColor(if (j == idx) 0xFFFF5A12.toInt() else 0xFF2A2A2C.toInt())
                    Bus.all(this@MainActivity)
                }
            })
        }
        root.addView(modes)

        root.addView(TextView(this).apply {
            text = "العدّاد التنازلي: اسم المناسبة وتاريخها"; setTextColor(Color.WHITE); textSize = 15f
            setPadding(0, dp(16), 0, dp(2))
        })
        val et = EditText(this).apply {
            setText(sp.getString("cd_name", "رأس السنة")); setTextColor(Color.WHITE); setHintTextColor(0xFF777777.toInt())
            hint = "اسم المناسبة"
        }
        root.addView(et)
        root.addView(btn("اختيار التاريخ وحفظ", 0xFF22A05A.toInt()) {
            val cal = Calendar.getInstance()
            DatePickerDialog(this, { _, y, m, d ->
                val t = Calendar.getInstance().apply { set(y, m, d, 0, 0, 0) }
                sp.edit().putString("cd_name", et.text.toString().ifBlank { "المناسبة" }).putLong("cd_ts", t.timeInMillis).apply()
                Bus.all(this)
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        })

        for (e in ALL_WIDGETS) {
            root.addView(TextView(this).apply {
                text = e.name; setTextColor(Color.WHITE); textSize = 17f; typeface = Typeface.DEFAULT_BOLD
                setPadding(0, dp(22), 0, dp(8))
            })
            val d = resources.displayMetrics.density
            var wp = e.provider.defW * d; var hp = e.provider.defH * d
            val sc = min(1f, 440f / max(wp, hp)); wp *= sc; hp *= sc
            val bmp = try { e.provider.draw(this, wp.toInt(), hp.toInt()) } catch (_: Throwable) { null }
            val iv = ImageView(this).apply {
                if (bmp != null) setImageBitmap(bmp)
                adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER
                layoutParams = LinearLayout.LayoutParams(-2, -2).apply { gravity = Gravity.CENTER_HORIZONTAL }
                maxWidth = dp(e.provider.defW)
            }
            root.addView(iv)
            previews.add(iv to e.provider)
            root.addView(btn("إضافة إلى الشاشة الرئيسية", 0xFF2A2A2C.toInt()) { pin(e.provider) })
        }
        setContentView(sv)
    }

    private fun pin(p: BaseProvider) {
        val mgr = AppWidgetManager.getInstance(this)
        if (Build.VERSION.SDK_INT >= 26 && mgr.isRequestPinAppWidgetSupported)
            mgr.requestPinAppWidget(ComponentName(this, p.javaClass), null, null)
        else Toast.makeText(this, "اضغط مطولاً على الشاشة الرئيسية ← الأدوات ← ويدجتس الوهج", Toast.LENGTH_LONG).show()
    }

    private fun askPerms() {
        val l = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(l.toTypedArray(), 7)
        Live.start(this)
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r)
        Sys.loc(this); Live.start(this); Bus.all(this)
    }

    override fun onResume() { super.onResume(); Sys.loc(this); Live.start(this); Bus.all(this); ui.post(frame) }
    override fun onPause() { ui.removeCallbacks(frame); super.onPause() }
}
