package com.glowwidgets.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import android.provider.AlarmClock
import android.provider.Settings
import android.widget.RemoteViews
import kotlin.math.max
import kotlin.math.min

object Ix {
    private fun flags() = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    fun act(ctx: Context, i: Intent, rc: Int): PendingIntent {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return PendingIntent.getActivity(ctx, rc, i, flags())
    }
    fun app(ctx: Context) = act(ctx, Intent(ctx, MainActivity::class.java), 1)
    fun action(ctx: Context, a: String, rc: Int) = act(ctx, Intent(a), rc)
    fun media(ctx: Context, k: String, rc: Int): PendingIntent {
        val i = Intent(ctx, MediaActionReceiver::class.java).putExtra("k", k)
        return PendingIntent.getBroadcast(ctx, rc, i, flags())
    }
}

abstract class BaseProvider(val defW: Int, val defH: Int, private val layout: Int) : AppWidgetProvider() {
    abstract fun draw(ctx: Context, w: Int, h: Int): Bitmap
    open fun bind(ctx: Context, rv: RemoteViews) {
        rv.setOnClickPendingIntent(R.id.root, Ix.app(ctx))
    }

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) { ids.forEach { push(ctx, mgr, it) } }
    override fun onAppWidgetOptionsChanged(ctx: Context, mgr: AppWidgetManager, id: Int, o: android.os.Bundle) { push(ctx, mgr, id) }
    override fun onEnabled(ctx: Context) { Live.start(ctx) }

    fun refresh(ctx: Context) {
        val mgr = AppWidgetManager.getInstance(ctx)
        mgr.getAppWidgetIds(ComponentName(ctx, this.javaClass)).forEach { push(ctx, mgr, it) }
    }

    private fun push(ctx: Context, mgr: AppWidgetManager, id: Int) {
        val o = mgr.getAppWidgetOptions(id)
        val d = ctx.resources.displayMetrics.density
        var wd = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0); if (wd <= 0) wd = defW
        var hd = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0); if (hd <= 0) hd = defH
        var wp = wd * d; var hp = hd * d
        val sc = min(1f, 440f / max(wp, hp)); wp *= sc; hp *= sc
        val bmp = try { draw(ctx, max(60, wp.toInt()), max(30, hp.toInt())) } catch (e: Throwable) { return }
        val rv = RemoteViews(ctx.packageName, layout)
        rv.setImageViewBitmap(R.id.img, bmp)
        bind(ctx, rv)
        mgr.updateAppWidget(id, rv)
    }
}

class ClockProvider : BaseProvider(180, 180, R.layout.widget_simple) {
    override fun draw(ctx: Context, w: Int, h: Int) = Art.clock(ctx, w, h)
    override fun bind(ctx: Context, rv: RemoteViews) {
        rv.setOnClickPendingIntent(R.id.root, Ix.action(ctx, AlarmClock.ACTION_SHOW_ALARMS, 10))
    }
}

class MusicProvider : BaseProvider(180, 180, R.layout.widget_music) {
    override fun draw(ctx: Context, w: Int, h: Int) = Art.music(ctx, w, h)
    override fun bind(ctx: Context, rv: RemoteViews) {
        super.bind(ctx, rv)
        rv.setOnClickPendingIntent(R.id.b_prev, Ix.media(ctx, "prev", 21))
        rv.setOnClickPendingIntent(R.id.b_play, Ix.media(ctx, "play", 22))
        rv.setOnClickPendingIntent(R.id.b_next, Ix.media(ctx, "next", 23))
    }
}

class AlarmProvider : BaseProvider(250, 110, R.layout.widget_alarm) {
    override fun draw(ctx: Context, w: Int, h: Int) = Art.alarm(ctx, w, h)
    override fun bind(ctx: Context, rv: RemoteViews) {
        val show = Ix.action(ctx, AlarmClock.ACTION_SHOW_ALARMS, 30)
        rv.setOnClickPendingIntent(R.id.root, show)
        rv.setOnClickPendingIntent(R.id.b_left, show)
        rv.setOnClickPendingIntent(R.id.b_mid, Sys.nextAlarm(ctx)?.showIntent ?: show)
        rv.setOnClickPendingIntent(R.id.b_right, Ix.action(ctx, AlarmClock.ACTION_SET_ALARM, 31))
    }
}

class QiblaProvider : BaseProvider(250, 250, R.layout.widget_simple) {
    override fun draw(ctx: Context, w: Int, h: Int) = Art.qibla(ctx, w, h)
}

class CompassProvider : BaseProvider(180, 180, R.layout.widget_simple) {
    override fun draw(ctx: Context, w: Int, h: Int) = Art.compass(ctx, w, h)
}

class BatteryProvider : BaseProvider(250, 250, R.layout.widget_battery) {
    override fun draw(ctx: Context, w: Int, h: Int) = Art.battery(ctx, w, h)
    override fun bind(ctx: Context, rv: RemoteViews) {
        val usage = Ix.action(ctx, Intent.ACTION_POWER_USAGE_SUMMARY, 40)
        rv.setOnClickPendingIntent(R.id.root, usage)
        rv.setOnClickPendingIntent(R.id.b_pill, Ix.action(ctx, Settings.ACTION_BATTERY_SAVER_SETTINGS, 41))
        rv.setOnClickPendingIntent(R.id.b_left, usage)
        rv.setOnClickPendingIntent(R.id.b_mid, usage)
        rv.setOnClickPendingIntent(R.id.b_right, Ix.action(ctx, Settings.ACTION_SETTINGS, 42))
    }
}

class BatteryPillProvider : BaseProvider(250, 40, R.layout.widget_simple) {
    override fun draw(ctx: Context, w: Int, h: Int) = Art.pill(ctx, w, h)
    override fun bind(ctx: Context, rv: RemoteViews) {
        rv.setOnClickPendingIntent(R.id.root, Ix.action(ctx, Intent.ACTION_POWER_USAGE_SUMMARY, 50))
    }
}

class CountdownProvider : BaseProvider(180, 250, R.layout.widget_simple) {
    override fun draw(ctx: Context, w: Int, h: Int) = Art.countdown(ctx, w, h)
}

class GlowChartProvider : BaseProvider(180, 250, R.layout.widget_simple) {
    override fun draw(ctx: Context, w: Int, h: Int) = Art.glowChart(ctx, w, h)
}

class NotifProvider : BaseProvider(250, 250, R.layout.widget_notif) {
    override fun draw(ctx: Context, w: Int, h: Int) = Art.notif(ctx, w, h)
    override fun bind(ctx: Context, rv: RemoteViews) {
        val listener = Ix.action(ctx, Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS, 60)
        rv.setOnClickPendingIntent(R.id.root, if (State.listenerOn) Ix.app(ctx) else listener)
        rv.setOnClickPendingIntent(R.id.b_set, listener)
    }
}

object Bus {
    fun clock(c: Context) = ClockProvider().refresh(c)
    fun music(c: Context) = MusicProvider().refresh(c)
    fun alarm(c: Context) = AlarmProvider().refresh(c)
    fun qibla(c: Context) = QiblaProvider().refresh(c)
    fun compass(c: Context) = CompassProvider().refresh(c)
    fun battery(c: Context) { BatteryProvider().refresh(c); BatteryPillProvider().refresh(c) }
    fun notif(c: Context) = NotifProvider().refresh(c)
    fun extra(c: Context) { CountdownProvider().refresh(c); GlowChartProvider().refresh(c) }
    fun all(c: Context) { clock(c); music(c); alarm(c); qibla(c); compass(c); battery(c); notif(c); extra(c) }
    fun animated(c: Context) = all(c)
}

class Entry(val name: String, val provider: BaseProvider)
val ALL_WIDGETS: List<Entry> by lazy {
    listOf(
        Entry("ساعة الوهج", ClockProvider()),
        Entry("مشغل الموسيقى", MusicProvider()),
        Entry("المنبه", AlarmProvider()),
        Entry("القبلة", QiblaProvider()),
        Entry("البوصلة", CompassProvider()),
        Entry("البطارية", BatteryProvider()),
        Entry("شريط البطارية", BatteryPillProvider()),
        Entry("الإشعارات", NotifProvider()),
        Entry("العدّاد التنازلي", CountdownProvider()),
        Entry("منحنى التوهج", GlowChartProvider())
    )
}
