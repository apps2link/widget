package com.glowwidgets.app

import android.Manifest
import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.*
import android.location.LocationManager
import android.media.session.MediaController
import android.os.BatteryManager
import android.os.Build
import android.os.SystemClock
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*

/** Canvas + dimensions helper. u = 1% of the smaller side. */
class Cv(wi: Int, hi: Int) {
    val b: Bitmap = Bitmap.createBitmap(wi, hi, Bitmap.Config.ARGB_8888)
    val c = Canvas(b)
    val w = wi.toFloat()
    val h = hi.toFloat()
    val u = min(w, h) / 100f
}

/** Shared live state (filled by services / sensors). */
object State {
    @Volatile var azimuth = 0f
    @Volatile var lat = 30.0444
    @Volatile var lon = 31.2357
    @Volatile var hasLoc = false

    @Volatile var title = ""
    @Volatile var artist = ""
    @Volatile var playing = false
    @Volatile var posMs = 0L
    @Volatile var posStamp = 0L
    @Volatile var durMs = 0L
    @Volatile var controller: MediaController? = null

    @Volatile var activeNotifs = 0
    @Volatile var appsCount = 0
    @Volatile var listenerOn = false

    fun elapsedNow(): Long {
        val e = if (playing) posMs + (SystemClock.elapsedRealtime() - posStamp) else posMs
        return if (durMs > 0) min(e, durMs) else max(0L, e)
    }

    private fun key(daysAgo: Int): String {
        val c = Calendar.getInstance(); c.add(Calendar.DAY_OF_YEAR, -daysAgo)
        return "d" + SimpleDateFormat("yyyyMMdd", Locale.US).format(c.time)
    }
    fun bump(ctx: Context) {
        val sp = ctx.getSharedPreferences("notif_hist", 0); val k = key(0)
        sp.edit().putInt(k, sp.getInt(k, 0) + 1).apply()
    }
    /** index 0 = 6 days ago ... index 6 = today */
    fun hist(ctx: Context): IntArray {
        val sp = ctx.getSharedPreferences("notif_hist", 0)
        return IntArray(7) { i -> sp.getInt(key(6 - i), 0) }
    }
}

data class Batt(val pct: Int, val charging: Boolean, val tempC: Float, val remainMs: Long)

object Sys {
    fun batt(ctx: Context): Batt {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val temp = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        val pct = if (scale > 0) (level * 100f / scale).roundToInt() else level
        var rem = -1L
        if (charging && Build.VERSION.SDK_INT >= 28) {
            val bm = ctx.getSystemService(BatteryManager::class.java)
            rem = bm.computeChargeTimeRemaining()
        }
        return Batt(pct, charging, temp, rem)
    }

    fun nextAlarm(ctx: Context): AlarmManager.AlarmClockInfo? =
        ctx.getSystemService(AlarmManager::class.java).nextAlarmClock

    fun loc(ctx: Context) {
        val ok = ctx.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!ok) return
        try {
            val lm = ctx.getSystemService(LocationManager::class.java)
            var best: android.location.Location? = null
            for (p in lm.getProviders(true)) {
                val l = lm.getLastKnownLocation(p) ?: continue
                if (best == null || l.time > best.time) best = l
            }
            if (best != null) { State.lat = best.latitude; State.lon = best.longitude; State.hasLoc = true }
        } catch (_: Exception) {}
    }

    fun qiblaBearing(lat: Double, lon: Double): Double {
        val k1 = Math.toRadians(21.4225); val k2 = Math.toRadians(39.8262)
        val p1 = Math.toRadians(lat); val l = k2 - Math.toRadians(lon)
        val y = sin(l) * cos(k1)
        val x = cos(p1) * sin(k1) - sin(p1) * cos(k1) * cos(l)
        return (Math.toDegrees(atan2(y, x)) + 360.0) % 360.0
    }
    fun distKm(lat: Double, lon: Double): Double {
        val r = 6371.0
        val p1 = Math.toRadians(lat); val p2 = Math.toRadians(21.4225)
        val dp = p2 - p1; val dl = Math.toRadians(39.8262 - lon)
        val a = sin(dp / 2).pow(2) + cos(p1) * cos(p2) * sin(dl / 2).pow(2)
        return 2 * r * asin(sqrt(a))
    }
}

/** Low level drawing helpers. */
object G {
    fun al(col: Int, a: Int): Int = (col and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)
    fun d2(x: Int): String = String.format(Locale.US, "%02d", x)

    fun p(color: Int = Color.WHITE, style: Paint.Style = Paint.Style.FILL, sw: Float = 0f): Paint =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color; this.style = style; strokeWidth = sw
            strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        }

    fun glowPaint(color: Int, sw: Float, blur: Float, alpha: Int): Paint {
        val g = p(color, Paint.Style.STROKE, sw)
        g.maskFilter = BlurMaskFilter(max(1f, blur), BlurMaskFilter.Blur.NORMAL)
        g.alpha = alpha
        return g
    }

    fun pt(cx: Float, cy: Float, r: Float, deg: Double): PointF {
        val a = Math.toRadians(deg)
        return PointF(cx + (cos(a) * r).toFloat(), cy + (sin(a) * r).toFloat())
    }

    fun squircle(l: Float, t: Float, r: Float, b: Float, n: Float = 4.2f): Path {
        val path = Path()
        val cx = (l + r) / 2; val cy = (t + b) / 2
        val a = (r - l) / 2; val bb = (b - t) / 2
        val steps = 180
        for (i in 0..steps) {
            val th = 2.0 * PI * i / steps
            val cs = cos(th); val sn = sin(th)
            val x = cx + a * sign(cs) * abs(cs).pow(2.0 / n)
            val y = cy + bb * sign(sn) * abs(sn).pow(2.0 / n)
            if (i == 0) path.moveTo(x.toFloat(), y.toFloat()) else path.lineTo(x.toFloat(), y.toFloat())
        }
        path.close()
        return path
    }

    /** Dark squircle card with outer glow + glowing bottom edge (images 1, 11). */
    fun glowCard(c: Canvas, w: Float, h: Float, pad: Float, glow: Int, glow2: Int = glow,
                 n: Float = 4.2f, base: Int = 0xFF060606.toInt(), bottom: Boolean = true, glowAlpha: Int = 120): Path {
        val path = squircle(pad, pad, w - pad, h - pad, n)
        c.drawPath(path, glowPaint(glow, pad * 0.7f, pad * 0.9f, glowAlpha))
        c.save(); c.clipPath(path)
        c.drawPath(path, p(base))
        if (bottom) {
            val q = Paint(Paint.ANTI_ALIAS_FLAG)
            q.shader = LinearGradient(0f, h - pad, 0f, h * 0.42f,
                intArrayOf(glow2, al(glow, 170), al(glow, 0)), floatArrayOf(0f, 0.3f, 1f), Shader.TileMode.CLAMP)
            q.maskFilter = BlurMaskFilter(pad * 0.8f, BlurMaskFilter.Blur.NORMAL)
            c.drawRect(0f, h * 0.4f, w, h, q)
        }
        c.restore()
        c.drawPath(path, p(al(Color.WHITE, 85), Paint.Style.STROKE, max(1.5f, pad * 0.07f)))
        return path
    }

    /** Frosted glass rounded rect (images 6, 14). */
    fun glass(c: Canvas, rf: RectF, rad: Float, c1: Int, c2: Int, rim: Int = 100) {
        val f = Paint(Paint.ANTI_ALIAS_FLAG)
        f.shader = LinearGradient(rf.left, rf.top, rf.right, rf.bottom, c1, c2, Shader.TileMode.CLAMP)
        c.drawRoundRect(rf, rad, rad, f)
        val hl = Paint(Paint.ANTI_ALIAS_FLAG)
        hl.shader = LinearGradient(0f, rf.top, 0f, rf.top + rf.height() * 0.5f,
            al(Color.WHITE, 55), al(Color.WHITE, 0), Shader.TileMode.CLAMP)
        c.drawRoundRect(rf, rad, rad, hl)
        c.drawRoundRect(rf, rad, rad, p(al(Color.WHITE, rim), Paint.Style.STROKE, 1.4f))
    }

    fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int = Color.WHITE,
             align: Paint.Align = Paint.Align.CENTER, font: String = "sans-serif-medium",
             shader: Shader? = null, glow: Int = 0, glowR: Float = 0f) {
        val q = Paint(Paint.ANTI_ALIAS_FLAG)
        q.textSize = size; q.color = color; q.textAlign = align
        q.typeface = Typeface.create(font, Typeface.NORMAL)
        if (shader != null) q.shader = shader
        if (glowR > 0f) q.setShadowLayer(glowR, 0f, 0f, glow)
        c.drawText(s, x, y, q)
    }

    fun measure(s: String, size: Float, font: String = "sans-serif-medium"): Float {
        val q = Paint(Paint.ANTI_ALIAS_FLAG); q.textSize = size; q.typeface = Typeface.create(font, Typeface.NORMAL)
        return q.measureText(s)
    }

    fun fit(s: String, size: Float, maxW: Float, font: String = "sans-serif-medium"): Float {
        val wd = measure(s, size, font)
        return if (wd > maxW && wd > 0f) size * maxW / wd else size
    }

    /** Draw mixed-size parts centered on cx (e.g. big digits + small units). */
    fun mixed(c: Canvas, parts: List<Pair<String, Float>>, cx: Float, y: Float, color: Int, font: String = "sans-serif-medium") {
        var total = 0f
        for ((s, sz) in parts) total += measure(s, sz, font)
        var x = cx - total / 2
        for ((s, sz) in parts) {
            text(c, s, x, y, sz, color, Paint.Align.LEFT, font)
            x += measure(s, sz, font)
        }
    }

    // ----- icons -----
    fun bolt(c: Canvas, cx: Float, cy: Float, s: Float, color: Int) {
        val pa = Path()
        pa.moveTo(cx + 0.20f * s, cy - s); pa.lineTo(cx - 0.50f * s, cy + 0.10f * s)
        pa.lineTo(cx - 0.05f * s, cy + 0.10f * s); pa.lineTo(cx - 0.20f * s, cy + s)
        pa.lineTo(cx + 0.50f * s, cy - 0.15f * s); pa.lineTo(cx + 0.05f * s, cy - 0.15f * s)
        pa.close()
        c.drawPath(pa, p(color))
    }

    /** dir = +1 right, -1 left */
    fun tri(c: Canvas, cx: Float, cy: Float, s: Float, dir: Int, color: Int) {
        val pa = Path()
        pa.moveTo(cx + dir * s * 0.8f, cy); pa.lineTo(cx - dir * s * 0.6f, cy - s * 0.85f); pa.lineTo(cx - dir * s * 0.6f, cy + s * 0.85f)
        pa.close()
        c.drawPath(pa, p(color))
    }

    fun pauseIcon(c: Canvas, cx: Float, cy: Float, s: Float, color: Int) {
        val pa = p(color)
        c.drawRoundRect(RectF(cx - s * 0.75f, cy - s * 0.9f, cx - s * 0.2f, cy + s * 0.9f), s * 0.15f, s * 0.15f, pa)
        c.drawRoundRect(RectF(cx + s * 0.2f, cy - s * 0.9f, cx + s * 0.75f, cy + s * 0.9f), s * 0.15f, s * 0.15f, pa)
    }

    fun bell(c: Canvas, cx: Float, cy: Float, s: Float, color: Int) {
        val pa = p(color)
        c.drawArc(RectF(cx - s * 0.75f, cy - s, cx + s * 0.75f, cy + s * 0.5f), 180f, 180f, true, pa)
        c.drawRect(cx - s * 0.75f, cy - s * 0.25f, cx + s * 0.75f, cy + s * 0.25f, pa)
        c.drawRoundRect(RectF(cx - s, cy + s * 0.25f, cx + s, cy + s * 0.6f), s * 0.2f, s * 0.2f, pa)
        c.drawCircle(cx, cy + s * 0.95f, s * 0.28f, pa)
    }

    fun plus(c: Canvas, cx: Float, cy: Float, s: Float, color: Int, sw: Float) {
        val pa = p(color, Paint.Style.STROKE, sw)
        c.drawLine(cx - s, cy, cx + s, cy, pa); c.drawLine(cx, cy - s, cx, cy + s, pa)
    }

    fun clockIcon(c: Canvas, cx: Float, cy: Float, s: Float, color: Int, sw: Float) {
        val pa = p(color, Paint.Style.STROKE, sw)
        c.drawCircle(cx, cy, s, pa)
        c.drawLine(cx, cy, cx, cy - s * 0.6f, pa); c.drawLine(cx, cy, cx + s * 0.45f, cy + s * 0.2f, pa)
    }

    fun snowflake(c: Canvas, cx: Float, cy: Float, s: Float, color: Int, sw: Float) {
        val pa = p(color, Paint.Style.STROKE, sw)
        for (i in 0 until 6) {
            val a = i * 60.0
            val e = pt(cx, cy, s, a); c.drawLine(cx, cy, e.x, e.y, pa)
            val m = pt(cx, cy, s * 0.62f, a)
            val b1 = pt(m.x, m.y, s * 0.35f, a + 50); val b2 = pt(m.x, m.y, s * 0.35f, a - 50)
            c.drawLine(m.x, m.y, b1.x, b1.y, pa); c.drawLine(m.x, m.y, b2.x, b2.y, pa)
        }
    }

    fun rocket(c: Canvas, cx: Float, cy: Float, s: Float, color: Int, sw: Float) {
        val pa = p(color, Paint.Style.STROKE, sw)
        c.save(); c.translate(cx, cy); c.rotate(45f)
        c.drawOval(RectF(-s * 0.4f, -s, s * 0.4f, s * 0.65f), pa)
        c.drawCircle(0f, -s * 0.25f, s * 0.16f, pa)
        c.drawLine(-s * 0.4f, s * 0.2f, -s * 0.75f, s * 0.7f, pa); c.drawLine(s * 0.4f, s * 0.2f, s * 0.75f, s * 0.7f, pa)
        c.drawLine(0f, s * 0.8f, 0f, s * 1.15f, pa)
        c.restore()
    }

    fun arrowUR(c: Canvas, cx: Float, cy: Float, s: Float, color: Int, sw: Float) {
        val pa = p(color, Paint.Style.STROKE, sw)
        c.drawLine(cx - s, cy + s, cx + s, cy - s, pa)
        c.drawLine(cx - s * 0.2f, cy - s, cx + s, cy - s, pa); c.drawLine(cx + s, cy - s, cx + s, cy + s * 0.2f, pa)
    }
}

/** Animation helpers: everything is a function of wall-clock time. */
object Fx {
    fun t(): Long = System.currentTimeMillis()
    /** 0..1 smooth breathing */
    fun pulse(periodMs: Long, min: Float = 0f): Float =
        min + (1f - min) * (0.5f + 0.5f * sin(2.0 * PI * (t() % periodMs) / periodMs).toFloat())
    /** 0..1 sawtooth */
    fun phase(periodMs: Long): Float = (t() % periodMs).toFloat() / periodMs
    /** 0 = off, 1 = eco, 2 = full */
    fun mode(ctx: Context): Int = ctx.getSharedPreferences("cfg", 0).getInt("anim", 2)

    /** Animated perimeter light with two travelling highlights. Designed for bitmap widgets. */
    fun edgeGlow(c: Canvas, w: Float, h: Float, color: Int, periodMs: Long = 4200L) {
        val side = min(w, h)
        val inset = side * 0.025f
        val radius = side * 0.12f
        val rect = RectF(inset, inset, w - inset, h - inset)
        val path = Path().apply { addRoundRect(rect, radius, radius, Path.Direction.CW) }
        val alpha = (34 + 42 * pulse(periodMs / 2)).toInt()
        c.drawPath(path, G.glowPaint(color, side * 0.006f, side * 0.018f, alpha))
        c.drawPath(path, G.p(G.al(color, 48), Paint.Style.STROKE, max(1f, side * 0.0015f)))
        val measure = PathMeasure(path, false)
        val point = FloatArray(2)
        val tangent = FloatArray(2)
        val phase = phase(periodMs)
        for (i in 0..1) {
            val distance = measure.length * ((phase + i * 0.5f) % 1f)
            if (measure.getPosTan(distance, point, tangent)) {
                val r = side * if (i == 0) 0.012f else 0.008f
                c.drawCircle(point[0], point[1], r * 2.8f, G.glowPaint(color, r * 2f, r * 2f, 145).apply { this.style = Paint.Style.FILL })
                c.drawCircle(point[0], point[1], r, G.p(Color.WHITE))
            }
        }
    }

    /** Floating glowing particles rising from yBase. */
    fun sparkles(c: Canvas, x0: Float, x1: Float, yBase: Float, rise: Float, r: Float, color: Int, n: Int = 8, periodMs: Long = 4200) {
        for (j in 0 until n) {
            val ph = (phase(periodMs + j * 530L) + j * 0.137f) % 1f
            val x = x0 + (x1 - x0) * ((j * 0.618034f) % 1f) + sin(ph * 12.5f + j) * r * 3f
            val y = yBase - ph * rise
            val a = (sin(ph * PI).toFloat() * 210f).toInt()
            val rr = r * (0.6f + 0.6f * ((j * 37) % 10) / 10f)
            c.drawCircle(x, y, rr * 2.2f, G.p(G.al(color, a / 4)))
            c.drawCircle(x, y, rr, G.p(G.al(Color.WHITE, a)))
        }
    }
}
