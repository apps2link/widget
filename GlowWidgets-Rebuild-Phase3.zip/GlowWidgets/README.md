# ويدجتس الوهج (GlowWidgets)

تطبيق أندرويد يضم 10 ويدجات للشاشة الرئيسية: ساعة، مشغل موسيقى، منبه، قبلة، بوصلة، بطارية، شريط بطارية، إشعارات، عداد تنازلي، ومنحنى توهج.

## المرحلة الثانية
واجهة معرض جديدة بتصميم داكن مضيء، تصفية حسب الفئات، معاينات حية داخل التطبيق، نافذة معاينة أكبر، وإضافة مباشرة للويدجت إلى الشاشة الرئيسية. تم الحفاظ على مزايا المشروع الأصلية دون إضافة اعتماديات خارجية.

## البناء
- Android Studio حديث
- JDK 17
- Gradle 8.7
- Android SDK 34
- minSdk 26

افتح مجلد المشروع في Android Studio ثم نفّذ Gradle Sync وبعدها Build APK.

## ملاحظة مهمة عن الأنيميشن
معاينات التطبيق تتحدث داخل التطبيق. أما ويدجات الشاشة الرئيسية فتستخدم RemoteViews وBitmap، ومعدل عرضها النهائي يخضع لقيود أندرويد واللانشر. وضع الحركة الكامل لا يعني ضمان 60FPS على الشاشة الرئيسية.

راجع `PHASE2_NOTES_AR.md` لتفاصيل التغييرات والقيود والاختبارات المطلوبة.

## Phase 3

The shared `Fx.edgeGlow` renderer adds a subtle animated perimeter and travelling highlights to all ten widget bitmaps. See `PHASE3_NOTES_AR.md` for scope and Android launcher limitations.
