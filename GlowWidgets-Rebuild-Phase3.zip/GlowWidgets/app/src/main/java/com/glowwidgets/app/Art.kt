package com.glowwidgets.app

import android.content.Context
import android.graphics.*
import android.text.format.DateFormat
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*

object Art {

    // ===================== 1) CLOCK (image 1) =====================
    fun clock(ctx: Context, wi: Int, hi: Int): Bitmap {
        val k = Cv(wi, hi); val c = k.c; val w = k.w; val h = k.h; val u = k.u
        val orange = 0xFFFF5A12.toInt(); val amber = 0xFFFFA23A.toInt()
        val pad = u * 7f
        G.glowCard(c, w, h, pad, orange, amber, glowAlpha = (60 + 130 * Fx.pulse(3200)).toInt())

        val cal = Calendar.getInstance()
        val is24 = DateFormat.is24HourFormat(ctx)
        var hr = cal.get(Calendar.HOUR_OF_DAY); val mn = cal.get(Calendar.MINUTE)
        val pm = hr >= 12
        if (!is24) { hr %= 12; if (hr == 0) hr = 12 }
        val hs = if (is24) G.d2(hr) else hr.toString()
        val ms = G.d2(mn)
        val cx = w / 2; val cy = h * 0.60f; val R = u * 34f

        G.text(c, SimpleDateFormat("EEEE", Locale("ar")).format(cal.time), cx, h * 0.27f, u * 9.5f)

        // tick arc (150° -> 390°), lit up to the current minute
        for (i in 0..59) {
            val deg = 150.0 + 240.0 * i / 59.0
            val big = i % 5 == 0
            val len = if (big) u * 4.2f else u * 2.6f
            val a = G.pt(cx, cy, R, deg); val b = G.pt(cx, cy, R - len, deg)
            c.drawLine(a.x, a.y, b.x, b.y, G.p(G.al(Color.WHITE, if (i <= mn) 225 else 70), Paint.Style.STROKE, u * 0.7f))
        }
        // needle at current minute
        val nd = 150.0 + 240.0 * mn / 59.0
        val n1 = G.pt(cx, cy, R * 0.52f, nd); val n2 = G.pt(cx, cy, R + u * 1.5f, nd)
        c.drawLine(n1.x, n1.y, n2.x, n2.y, G.p(G.al(Color.WHITE, 235), Paint.Style.STROKE, u * 0.6f))

        // light sweeping along the ticks + live seconds dot
        val sw = Fx.phase(2400)
        for (i in 0..59) {
            val d = abs(i / 59f - sw); val gk = max(0f, 1f - d * 11f)
            if (gk > 0f) {
                val deg = 150.0 + 240.0 * i / 59.0
                val a = G.pt(cx, cy, R, deg); val b = G.pt(cx, cy, R - u * 5f, deg)
                c.drawLine(a.x, a.y, b.x, b.y, G.p(G.al(0xFFFFC27A.toInt(), (255 * gk).toInt()), Paint.Style.STROKE, u * 1.1f))
            }
        }
        val sf = cal.get(Calendar.SECOND) + cal.get(Calendar.MILLISECOND) / 1000f
        val sd = G.pt(cx, cy, R + u * 3.2f, 150.0 + 240.0 * sf / 60.0)
        c.drawCircle(sd.x, sd.y, u * 2.4f, G.p(G.al(orange, (90 + 120 * Fx.pulse(1000)).toInt())))
        c.drawCircle(sd.x, sd.y, u * 1.2f, G.p(Color.WHITE))
        // big overlapped digits with fade
        val sh = LinearGradient(0f, h * 0.58f, 0f, h * 0.84f, Color.WHITE, G.al(0xFFFF7A4A.toInt(), 150), Shader.TileMode.CLAMP)
        val sz = u * 27f
        G.text(c, hs, cx - u * 14f, h * 0.80f, sz, shader = sh)
        G.text(c, ms, cx + u * 14f, h * 0.80f, sz, shader = sh)
        if (is24) {
            c.drawCircle(cx + u * 32f, h * 0.58f, u * 1.8f, G.p(G.al(Color.WHITE, 220), Paint.Style.STROKE, u * 0.8f))
        } else {
            G.text(c, if (pm) "PM" else "AM", cx + u * 32f, h * 0.585f, u * 4.6f, G.al(Color.WHITE, 220))
        }
        Fx.sparkles(c, pad + u * 12f, w - pad - u * 12f, h * 0.88f, h * 0.38f, u * 0.9f, orange)
        Fx.edgeGlow(c, w, h, 0xFFFF6A24.toInt(), 4285L)
        return k.b
    }

    // ===================== 2) MUSIC (image 5) =====================
    fun music(ctx: Context, wi: Int, hi: Int): Bitmap {
        val k = Cv(wi, hi); val c = k.c; val w = k.w; val h = k.h; val u = k.u
        val amber = 0xFFFFB020.toInt(); val yellow = 0xFFFFD21F.toInt()
        val pad = u * 6f
        val path = G.squircle(pad, pad, w - pad, h - pad, 4.6f)
        c.drawPath(path, G.glowPaint(amber, pad * 0.5f, pad * 0.8f, (40 + 100 * Fx.pulse(2600)).toInt()))
        c.save(); c.clipPath(path)
        val bg = Paint(Paint.ANTI_ALIAS_FLAG)
        bg.shader = RadialGradient(w / 2, h * 0.45f, u * 60f,
            intArrayOf(G.al(0xFFB86A00.toInt(), 205), G.al(0xFF3A2000.toInt(), 220), G.al(0xFF120A00.toInt(), 238)),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        c.drawPath(path, bg)
        c.restore()
        c.drawPath(path, G.p(G.al(amber, 100), Paint.Style.STROKE, 1.5f))

        val cx = w / 2; val cy = h * 0.52f; val R = u * 30f
        val now = Date()
        G.text(c, SimpleDateFormat("d MMM", Locale("ar")).format(now), pad + u * 8f, h * 0.15f, u * 4.6f, G.al(Color.WHITE, 150), Paint.Align.LEFT)
        G.text(c, DateFormat.format(if (DateFormat.is24HourFormat(ctx)) "HH:mm" else "h:mm a", now).toString(),
            w - pad - u * 8f, h * 0.15f, u * 4.6f, G.al(Color.WHITE, 150), Paint.Align.RIGHT)

        val rect = RectF(cx - R, cy - R, cx + R, cy + R)
        val track = G.p(G.al(Color.WHITE, 45), Paint.Style.STROKE, u * 3.6f)
        c.drawArc(rect, 150f, 240f, false, track)
        val has = State.title.isNotEmpty() || State.durMs > 0
        val el = State.elapsedNow()
        val frac = if (State.durMs > 0) (el.toFloat() / State.durMs).coerceIn(0f, 1f) else if (has) 0.35f else 0f
        if (frac > 0.005f) {
            c.drawArc(rect, 150f, 240f * frac, false, G.glowPaint(yellow, u * 3.6f, u * 3f, 200))
            c.drawArc(rect, 150f, 240f * frac, false, G.p(yellow, Paint.Style.STROKE, u * 3.6f))
            val hd = G.pt(cx, cy, R, 150.0 + 240.0 * frac)
            c.drawCircle(hd.x, hd.y, u * 2.6f, G.glowPaint(yellow, u * 3f, u * 3f, 255).apply { style = Paint.Style.FILL })
            c.drawCircle(hd.x, hd.y, u * 1.7f, G.p(Color.WHITE))
        }
        val dph = Fx.phase(1600) * 6.2832f
        val amp = if (State.playing) 1f else 0.35f
        for (i in 0..14) {
            val pnt = G.pt(cx, cy, R * 0.8f, 160.0 + 220.0 * i / 14.0)
            val wv = (0.5f + 0.5f * sin(dph - i * 0.55f)) * amp
            c.drawCircle(pnt.x, pnt.y, u * (0.7f + 1.2f * wv), G.p(G.al(amber, (90 + 165 * wv).toInt())))
        }

        val label = if (State.title.isNotEmpty()) State.title else "لا توجد موسيقى"
        G.text(c, label, cx, h * 0.405f, G.fit(label, u * 5.6f, u * 40f), G.al(Color.WHITE, 205))
        val tm = if (has) { val s = el / 1000; String.format(Locale.US, "%d:%02d", s / 60, s % 60) } else "--:--"
        G.text(c, tm, cx, h * 0.575f, G.fit(tm, u * 16f, u * 40f), 0xFFFFE08A.toInt(), glow = amber, glowR = u * 4f)
        if (State.artist.isNotEmpty())
            G.text(c, State.artist, cx, h * 0.64f, G.fit(State.artist, u * 4.6f, u * 40f), G.al(Color.WHITE, 150))

        val by = h * 0.80f
        val gray = G.p(G.al(Color.WHITE, 40))
        c.drawCircle(cx - u * 26f, by, u * 8.5f, gray); c.drawCircle(cx + u * 26f, by, u * 8.5f, gray)
        G.tri(c, cx - u * 25f, by, u * 3.2f, -1, Color.WHITE)
        c.drawRoundRect(RectF(cx - u * 29.8f, by - u * 3f, cx - u * 28.6f, by + u * 3f), 2f, 2f, G.p(Color.WHITE))
        G.tri(c, cx + u * 27f, by, u * 3.2f, 1, Color.WHITE)
        c.drawRoundRect(RectF(cx + u * 29.6f, by - u * 3f, cx + u * 30.8f, by + u * 3f), 2f, 2f, G.p(Color.WHITE))
        // play / pause
        c.drawCircle(cx, by, u * 12f, G.glowPaint(0xFFFF9A00.toInt(), u * 5f, u * 5f, (110 + 130 * Fx.pulse(if (State.playing) 700 else 2000)).toInt()).apply { style = Paint.Style.FILL })
        val pp = Paint(Paint.ANTI_ALIAS_FLAG)
        pp.shader = RadialGradient(cx - u * 3f, by - u * 4f, u * 14f, 0xFFFFD84A.toInt(), 0xFFFF8A00.toInt(), Shader.TileMode.CLAMP)
        c.drawCircle(cx, by, u * 11.5f, pp)
        if (State.playing) G.pauseIcon(c, cx, by, u * 4.2f, 0xFF3A1D00.toInt())
        else G.tri(c, cx + u * 0.8f, by, u * 4.6f, 1, Color.WHITE)
        Fx.sparkles(c, pad + u * 10f, w - pad - u * 10f, h * 0.9f, h * 0.55f, u * 0.9f, amber, 7, 3800)
        Fx.edgeGlow(c, w, h, 0xFFFFB020.toInt(), 4285L)
        return k.b
    }

    // ===================== 3) ALARM (image 13) =====================
    fun alarm(ctx: Context, wi: Int, hi: Int): Bitmap {
        val k = Cv(wi, hi); val c = k.c; val w = k.w; val h = k.h; val u = h / 40f
        val orange = 0xFFFF9F0A.toInt()
        val pad = u * 1.2f
        val rad = h * 0.30f
        val body = RectF(pad, pad, w - pad, h - pad)
        c.drawRoundRect(body, rad, rad, G.p(0xFF000000.toInt()))
        c.drawRoundRect(body, rad, rad, G.p(G.al(Color.WHITE, 40), Paint.Style.STROKE, 1.2f))

        val info = Sys.nextAlarm(ctx)
        val now = System.currentTimeMillis()
        val remain = if (info != null) max(0L, info.triggerTime - now) else -1L
        val win = 12L * 3600_000L
        val frac = if (remain >= 0) (1f - min(remain, win).toFloat() / win).coerceIn(0.02f, 1f) else 0f

        // orange border progress starting at top-center, clockwise
        val ins = u * 2.6f
        val l = pad + ins; val t = pad + ins; val r = w - pad - ins; val b = h - pad - ins
        val rr = rad - ins
        val cxm = (l + r) / 2
        val bp = Path()
        bp.moveTo(cxm, t); bp.lineTo(r - rr, t); bp.arcTo(RectF(r - 2 * rr, t, r, t + 2 * rr), -90f, 90f)
        bp.lineTo(r, b - rr); bp.arcTo(RectF(r - 2 * rr, b - 2 * rr, r, b), 0f, 90f)
        bp.lineTo(l + rr, b); bp.arcTo(RectF(l, b - 2 * rr, l + 2 * rr, b), 90f, 90f)
        bp.lineTo(l, t + rr); bp.arcTo(RectF(l, t, l + 2 * rr, t + 2 * rr), 180f, 90f)
        bp.lineTo(cxm, t)
        c.drawPath(bp, G.p(G.al(Color.WHITE, 45), Paint.Style.STROKE, u * 2.2f))
        if (frac > 0f) {
            val pm = PathMeasure(bp, false); val seg = Path()
            pm.getSegment(0f, pm.length * frac, seg, true)
            c.drawPath(seg, G.glowPaint(orange, u * 2.4f, u * 2.5f, 170))
            c.drawPath(seg, G.p(orange, Paint.Style.STROKE, u * 2.4f))
        }
        run {
            val pm2 = PathMeasure(bp, false); val len = pm2.length
            val p0 = Fx.phase(2600) * len
            val seg2 = Path(); pm2.getSegment(p0, min(len, p0 + len * 0.07f), seg2, true)
            c.drawPath(seg2, G.glowPaint(Color.WHITE, u * 2.4f, u * 2.5f, 230))
            c.drawPath(seg2, G.p(Color.WHITE, Paint.Style.STROKE, u * 1.3f))
        }

        val cy = h / 2
        // side buttons
        c.drawCircle(w * 0.16f, cy, h * 0.27f, G.p(0xFF2A2A2C.toInt()))
        G.clockIcon(c, w * 0.16f, cy, h * 0.11f, Color.WHITE, u * 1.5f)
        c.drawCircle(w * 0.84f, cy, h * 0.27f, G.p(0xFF4A1210.toInt()))
        G.plus(c, w * 0.84f, cy, h * 0.10f, 0xFFFF4D3F.toInt(), u * 2.2f)

        // center texts
        val cx = w / 2
        val top: String; val big: String; val sub: String
        if (info != null) {
            val cal = Calendar.getInstance(); cal.timeInMillis = info.triggerTime
            big = DateFormat.format(if (DateFormat.is24HourFormat(ctx)) "HH:mm" else "h:mm", cal.time).toString()
            val mins = (remain / 60000).toInt()
            top = when {
                mins >= 1440 -> "بعد ${mins / 1440}ي ${(mins % 1440) / 60}س"
                mins >= 60 -> "بعد ${mins / 60}س ${mins % 60}د"
                else -> "بعد ${mins}د"
            }
            sub = "المنبه التالي"
        } else { big = "--:--"; top = "لا يوجد منبه"; sub = "اضغط لإضافة منبه" }
        val bph = Fx.phase(3000); val wig = if (bph < 0.25f) sin(bph * 90f) * 16f else 0f
        val bx = cx - G.measure(top, h * 0.115f) / 2 - h * 0.09f
        c.save(); c.rotate(wig, bx, h * 0.26f)
        G.bell(c, bx, h * 0.285f, h * 0.045f, G.al(Color.WHITE, 160))
        c.restore()
        G.text(c, top, cx, h * 0.32f, h * 0.115f, G.al(Color.WHITE, 140))
        G.text(c, big, cx, h * 0.665f, min(h * 0.30f, G.fit(big, h * 0.30f, w * 0.36f)), Color.WHITE)
        G.text(c, sub, cx, h * 0.86f, h * 0.105f, G.al(Color.WHITE, 140))
        Fx.edgeGlow(c, w, h, 0xFFFF9F0A.toInt(), 4285L)
        return k.b
    }

    // ===================== 4) QIBLA (image 6) =====================
    fun qibla(ctx: Context, wi: Int, hi: Int): Bitmap {
        val k = Cv(wi, hi); val c = k.c; val w = k.w; val h = k.h; val u = k.u
        val pad = u * 5f
        val card = RectF(pad, pad, w - pad, h - pad)
        c.drawRoundRect(card, u * 16f, u * 16f, G.p(G.al(0xFF101820.toInt(), 70)))
        G.glass(c, card, u * 16f, G.al(Color.WHITE, 85), G.al(Color.WHITE, 28), 120)

        val q = Sys.qiblaBearing(State.lat, State.lon)
        val dist = Sys.distKm(State.lat, State.lon)
        var delta = ((q - State.azimuth + 540.0) % 360.0) - 180.0
        val aligned = abs(delta) < 4.0
        val accent = if (aligned) 0xFF5BFF9A.toInt() else 0xFFFFE27A.toInt()

        val cx = w / 2
        G.text(c, "القبلة", w - pad - u * 7f, h * 0.17f, u * 8f, Color.WHITE, Paint.Align.RIGHT)
        G.text(c, if (State.hasLoc) "اتجه نحو الكعبة المشرفة" else "الموقع تقريبي • فعّل إذن الموقع",
            w - pad - u * 7f, h * 0.225f, u * 3.8f, G.al(Color.WHITE, 170), Paint.Align.RIGHT)

        // status toggle (on when aligned)
        val tg = RectF(pad + u * 7f, h * 0.115f, pad + u * 21f, h * 0.115f + u * 7.5f)
        c.drawRoundRect(tg, u * 4f, u * 4f, G.p(G.al(Color.WHITE, if (aligned) 120 else 60)))
        val kx = if (aligned) tg.right - u * 3.6f else tg.left + u * 3.6f
        c.drawCircle(kx, tg.centerY(), u * 3f, G.p(Color.WHITE))

        // semicircle gauge
        val acy = h * 0.67f; val R = u * 28f
        val rect = RectF(cx - R, acy - R, cx + R, acy + R)
        c.drawArc(rect, 180f, 180f, false, G.p(G.al(Color.WHITE, 60), Paint.Style.STROKE, u * 2.2f))
        for (i in 0..12) {
            val pnt = G.pt(cx, acy, R + u * 5.5f, 180.0 + 180.0 * i / 12.0)
            c.drawCircle(pnt.x, pnt.y, u * 0.6f, G.p(G.al(Color.WHITE, 130)))
        }
        delta = delta.coerceIn(-90.0, 90.0)
        val hAng = 270.0 + delta
        val sweep = (hAng - 180.0).toFloat()
        val pr = Paint(Paint.ANTI_ALIAS_FLAG); pr.style = Paint.Style.STROKE; pr.strokeWidth = u * 2.6f; pr.strokeCap = Paint.Cap.ROUND
        pr.shader = LinearGradient(cx - R, acy, cx + R, acy, intArrayOf(Color.WHITE, Color.WHITE, accent), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        c.drawArc(rect, 180f, max(1f, sweep), false, pr)
        val hd = G.pt(cx, acy, R, hAng)
        c.drawCircle(hd.x, hd.y, u * 3.4f, G.glowPaint(accent, u * 3f, u * 3f, (130 + 120 * Fx.pulse(900)).toInt()).apply { style = Paint.Style.FILL })
        c.drawCircle(hd.x, hd.y, u * 3.2f, G.p(Color.WHITE, Paint.Style.STROKE, u * 0.9f))

        for (j in 0..2) {
            val ph = (Fx.phase(3000) + j / 3f) % 1f
            val rr = u * 12f + ph * u * 22f
            c.drawCircle(cx, acy - u * 5f, rr, G.p(G.al(accent, (160 * (1 - ph) * (if (aligned) 1f else 0.5f)).toInt()), Paint.Style.STROKE, u * 0.9f))
        }
        // center disc with bearing
        val ccy = acy - u * 5f
        val disc = Paint(Paint.ANTI_ALIAS_FLAG)
        disc.shader = RadialGradient(cx, ccy, u * 12f, G.al(Color.WHITE, 150), G.al(Color.WHITE, 60), Shader.TileMode.CLAMP)
        c.drawCircle(cx, ccy, u * 12f, disc)
        c.drawCircle(cx, ccy, u * 12f, G.p(G.al(Color.WHITE, 110), Paint.Style.STROKE, 1.2f))
        G.mixed(c, listOf("${q.roundToInt() % 360}" to u * 8.6f, "°" to u * 4.4f), cx, ccy + u * 3f, Color.WHITE)

        // tilted pills
        val py = h * 0.835f; val ph = u * 12.5f; val pw = u * 36f
        fun pill(pcx: Float, rot: Float, txt: String, icon: Int) {
            c.save(); c.rotate(rot, pcx, py)
            val rf = RectF(pcx - pw / 2, py - ph / 2, pcx + pw / 2, py + ph / 2)
            G.glass(c, rf, ph / 2, G.al(Color.WHITE, 90), G.al(Color.WHITE, 35), 130)
            c.drawCircle(rf.left + ph / 2, py, ph * 0.38f, G.p(Color.WHITE))
            when (icon) {
                0 -> { c.drawCircle(rf.left + ph / 2, py, ph * 0.13f, G.p(0xFF222222.toInt(), Paint.Style.STROKE, 1.6f)); G.tri(c, rf.left + ph / 2, py - ph * 0.02f, ph * 0.1f, 1, 0xFF222222.toInt()) }
                else -> G.arrowUR(c, rf.left + ph / 2, py, ph * 0.15f, 0xFF222222.toInt(), 1.8f)
            }
            G.text(c, txt, rf.left + ph * 1.0f + (pw - ph * 1.0f) / 2, py + u * 1.5f, G.fit(txt, u * 4.6f, pw - ph * 1.5f), Color.WHITE)
            c.restore()
        }
        val distTxt = String.format(Locale.US, "%,d كم", dist.roundToInt())
        pill(cx - u * 21f, -4f, distTxt, 0)
        val dev = (((q - State.azimuth + 540.0) % 360.0) - 180.0).roundToInt()
        pill(cx + u * 21f, 4f, if (aligned) "متجه للقبلة ✓" else "انحراف ${abs(dev)}°", 1)
        Fx.edgeGlow(c, w, h, 0xFF5BFF9A.toInt(), 4285L)
        return k.b
    }

    // ===================== 5) COMPASS (image 11) =====================
    fun compass(ctx: Context, wi: Int, hi: Int): Bitmap {
        val k = Cv(wi, hi); val c = k.c; val w = k.w; val h = k.h; val u = k.u
        val pink = 0xFFFF2D95.toInt(); val purple = 0xFF8A3DFF.toInt()
        val pad = u * 7f
        G.glowCard(c, w, h, pad, purple, pink, 4.4f, 0xFF07040C.toInt(), glowAlpha = (60 + 130 * Fx.pulse(3000)).toInt())
        val cx = w / 2; val cy = h * 0.47f; val R = u * 35f
        val az = ((State.azimuth % 360f) + 360f) % 360f

        for (i in 0..71) {
            val deg = 150.0 + 240.0 * i / 71.0
            val big = i % 6 == 0
            val a = G.pt(cx, cy, R, deg); val b = G.pt(cx, cy, R - if (big) u * 3.8f else u * 2.4f, deg)
            val lit = (i / 71f) <= az / 360f
            val col = if (lit) G.al(0xFFB26BFF.toInt(), 150) else G.al(Color.WHITE, 45)
            c.drawLine(a.x, a.y, b.x, b.y, G.p(col, Paint.Style.STROKE, u * 0.55f))
        }
        val ar = R * 0.86f
        val rect = RectF(cx - ar, cy - ar, cx + ar, cy + ar)
        val sw = u * 3f
        val frac = max(0.004f, az / 360f)
        val ap = Paint(Paint.ANTI_ALIAS_FLAG); ap.style = Paint.Style.STROKE; ap.strokeWidth = sw; ap.strokeCap = Paint.Cap.ROUND
        ap.shader = SweepGradient(cx, cy, intArrayOf(purple, purple, pink, purple), floatArrayOf(0f, 0.0833f, 0.4167f, 1f))
        c.drawArc(rect, 150f, 240f * frac, false, ap)
        val end = G.pt(cx, cy, ar, 150.0 + 240.0 * frac)
        c.drawCircle(end.x, end.y, u * 2.6f, G.glowPaint(purple, u * 3f, u * 3f, 220).apply { style = Paint.Style.FILL })
        c.drawCircle(end.x, end.y, u * 2.1f, G.p(0xFF9B5CFF.toInt()))

        val swA = 360.0 * Fx.phase(3500)
        for (kk in 0..14) {
            val aa = swA - kk * 2.4
            val p1 = G.pt(cx, cy, R * 0.5f, aa); val p2 = G.pt(cx, cy, R * 0.84f, aa)
            c.drawLine(p1.x, p1.y, p2.x, p2.y, G.p(G.al(0xFFC79BFF.toInt(), (130 * (1 - kk / 15f)).toInt()), Paint.Style.STROKE, u * 0.8f))
        }
        // north marker (moves opposite to heading)
        val np = G.pt(cx, cy, R * 0.5f, -90.0 - az)
        val blob = Paint(Paint.ANTI_ALIAS_FLAG); val bR = u * (5f + 2.2f * Fx.pulse(1400))
        blob.shader = RadialGradient(np.x, np.y, bR, G.al(0xFFB78BFF.toInt(), 235), G.al(purple, 0), Shader.TileMode.CLAMP)
        c.drawCircle(np.x, np.y, bR, blob)
        G.text(c, "N", np.x, np.y + u * 1.8f, u * 5f, Color.WHITE, font = "sans-serif-medium")

        // direction pill
        val names = arrayOf("شمال", "شمال شرق", "شرق", "جنوب شرق", "جنوب", "جنوب غرب", "غرب", "شمال غرب")
        val dn = names[((az + 22.5f) / 45f).toInt() % 8]
        val pw = u * 30f; val ph = u * 9f; val py = h * 0.545f
        val pr = RectF(cx - pw / 2, py - ph / 2, cx + pw / 2, py + ph / 2)
        c.drawRoundRect(pr, ph / 2, ph / 2, G.p(G.al(0xFF2A2433.toInt(), 235)))
        c.drawRoundRect(pr, ph / 2, ph / 2, G.p(G.al(Color.WHITE, 40), Paint.Style.STROKE, 1.2f))
        G.text(c, dn, cx, py + u * 2.1f, u * 6.2f)

        // big degrees with fade
        val sh = LinearGradient(0f, h * 0.60f, 0f, h * 0.87f, Color.WHITE, G.al(0xFFFF8AD0.toInt(), 120), Shader.TileMode.CLAMP)
        val ds = "${az.roundToInt() % 360}"
        val size = u * 34f
        val tw = G.measure(ds, size)
        G.text(c, ds, cx - u * 4f, h * 0.835f, size, shader = sh)
        G.text(c, "°", cx - u * 4f + tw / 2 + u * 3f, h * 0.665f, u * 12f, Color.WHITE)
        Fx.edgeGlow(c, w, h, 0xFFFF2D95.toInt(), 4559L)
        return k.b
    }

    // ===================== 6) BATTERY big (images 3 & 4) =====================
    fun battery(ctx: Context, wi: Int, hi: Int): Bitmap {
        val k = Cv(wi, hi); val c = k.c; val w = k.w; val h = k.h; val u = k.u
        val bt = Sys.batt(ctx)
        val col = when { bt.charging -> 0xFF39E36B.toInt(); bt.pct <= 15 -> 0xFFFF2B2B.toInt(); else -> 0xFFFF4A0A.toInt() }
        val pad = u * 4f
        val bg = G.squircle(pad, pad, w - pad, h - pad, 5f)
        c.save(); c.clipPath(bg)
        c.drawPath(bg, G.p(0xFF121513.toInt()))
        val halo = Paint(Paint.ANTI_ALIAS_FLAG)
        val cx = w / 2; val cy = h * 0.43f
        halo.shader = RadialGradient(cx, cy, u * 47f, G.al(col, 70), G.al(col, 0), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, u * 47f, halo)
        c.restore()
        c.drawPath(bg, G.p(G.al(Color.WHITE, 28), Paint.Style.STROKE, 1.4f))

        // top pill
        val pw = u * 52f; val ph = u * 12f; val py = h * 0.095f
        val pr = RectF(cx - pw / 2, py - ph / 2, cx + pw / 2, py + ph / 2)
        c.drawRoundRect(pr, ph / 2, ph / 2, G.p(G.al(col, 85)))
        c.drawRoundRect(pr, ph / 2, ph / 2, G.p(G.al(col, 170), Paint.Style.STROKE, 1.3f))
        G.bolt(c, pr.left + ph * 0.8f, py, ph * 0.32f, 0xFF4CFF7A.toInt())
        val pl = if (bt.charging) "تسريع الشحن" else "توفير الطاقة"
        G.text(c, pl, cx + ph * 0.35f, py + u * 1.7f, G.fit(pl, u * 5.2f, pw - ph * 1.6f))

        // rings
        val r1 = u * 31f; val r2 = u * 28f; val r3 = u * 26f
        c.drawCircle(cx, cy, r1, G.p(0xFF0D0F0E.toInt()))
        c.drawCircle(cx, cy, r1, G.p(0xFF2A2F2C.toInt(), Paint.Style.STROKE, u * 1.2f))
        c.drawCircle(cx, cy, r2, G.glowPaint(col, u * 1.8f, u * 2.5f, (100 + 130 * Fx.pulse(if (bt.charging) 900 else 2200)).toInt()))
        if (bt.charging) {
            val o = G.pt(cx, cy, r2, 360.0 * Fx.phase(2200) - 90)
            c.drawCircle(o.x, o.y, u * 3f, G.glowPaint(col, u * 3f, u * 3f, 230).apply { style = Paint.Style.FILL })
            c.drawCircle(o.x, o.y, u * 1.3f, G.p(Color.WHITE))
        }
        c.drawCircle(cx, cy, r2, G.p(col, Paint.Style.STROKE, u * 1.7f))
        c.drawCircle(cx, cy, r3, G.p(0xFF090A0A.toInt()))

        // waves (animated by time)
        val phase = (System.currentTimeMillis() / 600.0) % (2 * PI)
        val level = (bt.pct / 100f) * 0.8f + 0.1f
        val top = cy + r3 - 2 * r3 * level
        c.save()
        val cp = Path(); cp.addCircle(cx, cy, r3, Path.Direction.CW); c.clipPath(cp)
        for (layer in 0..1) {
            val wp = Path()
            wp.moveTo(cx - r3, cy + r3 + 2)
            var x = cx - r3
            while (x <= cx + r3 + 2) {
                val y = top + sin((x - cx) / (r3 * (0.5 + 0.25 * layer)) * PI + phase * (1 + layer * 0.6) + layer).toFloat() * u * (1.7f - layer * 0.4f)
                wp.lineTo(x, y); x += 2f
            }
            wp.lineTo(cx + r3 + 2, cy + r3 + 2); wp.close()
            c.drawPath(wp, G.p(if (layer == 0) G.al(col, 120) else G.al(col, 235)))
        }
        c.restore()

        c.save(); c.clipPath(cp)
        for (j in 0..5) {
            val ph = (Fx.phase(2600 + j * 400L) + j * 0.19f) % 1f
            val bx = cx + (j - 2.5f) * u * 7f + sin(ph * 9f + j) * u * 1.2f
            val by = cy + r3 - ph * (cy + r3 - top)
            if (by > top + u) c.drawCircle(bx, by, u * (0.7f + 0.5f * (j % 3)), G.p(G.al(Color.WHITE, (130 * (1 - ph)).toInt()), Paint.Style.STROKE, u * 0.4f))
        }
        c.restore()
        G.bolt(c, cx, cy - u * 17.5f, u * 2.6f, G.al(Color.WHITE, if (bt.charging) (110 + 145 * Fx.pulse(800)).toInt() else 255))
        G.text(c, "${bt.pct}", cx, cy + u * 7f, u * 22f, Color.WHITE, font = "sans-serif")
        G.text(c, "%", cx, cy + u * 16f, u * 6f, Color.WHITE)

        // beam + icons
        val beam = Path()
        beam.moveTo(cx - u * 9f, cy + r1); beam.lineTo(cx + u * 9f, cy + r1)
        beam.lineTo(cx + u * 17f, h * 0.73f); beam.lineTo(cx - u * 17f, h * 0.73f); beam.close()
        val bp = Paint(Paint.ANTI_ALIAS_FLAG)
        bp.shader = LinearGradient(0f, cy + r1, 0f, h * 0.73f, G.al(col, 0), G.al(col, (90 + 100 * Fx.pulse(1300)).toInt()), Shader.TileMode.CLAMP)
        c.drawPath(beam, bp)
        val iy = h * 0.645f
        val body = RectF(cx - u * 3.8f, iy - u * 5.6f, cx + u * 3.8f, iy + u * 5.6f)
        c.drawRoundRect(body, u * 1.2f, u * 1.2f, G.p(Color.WHITE, Paint.Style.STROKE, u * 0.9f))
        c.drawRect(cx - u * 1.4f, iy - u * 7f, cx + u * 1.4f, iy - u * 5.6f, G.p(Color.WHITE))
        G.bolt(c, cx, iy, u * 3f, Color.WHITE)
        G.snowflake(c, cx - u * 26f, h * 0.635f, u * 4.6f, col, u * 0.9f)
        G.rocket(c, cx + u * 26f, h * 0.635f, u * 4.4f, col, u * 0.9f)

        // bottom info
        val gray = 0xFF8C928E.toInt()
        val cal = Calendar.getInstance()
        val tm = DateFormat.format(if (DateFormat.is24HourFormat(ctx)) "HH:mm" else "h:mm", cal.time).toString()
        G.text(c, tm, cx - u * 24f, h * 0.865f, u * 9f, Color.WHITE)
        G.text(c, SimpleDateFormat("M/d EEEE", Locale("ar")).format(cal.time), cx - u * 24f, h * 0.925f, u * 4f, gray)
        c.drawLine(cx - u * 1f, h * 0.81f, cx - u * 1f, h * 0.93f, G.p(G.al(Color.WHITE, 70), Paint.Style.STROKE, 1.4f))
        if (bt.charging && bt.remainMs > 0) {
            val m = (bt.remainMs / 60000).toInt()
            G.mixed(c, listOf("${m / 60}" to u * 9f, "س " to u * 4.4f, "${m % 60}" to u * 9f, "د" to u * 4.4f), cx + u * 25f, h * 0.865f, Color.WHITE)
            G.text(c, "الشحن الكامل خلال", cx + u * 25f, h * 0.925f, u * 4f, gray)
        } else {
            G.mixed(c, listOf(String.format(Locale.US, "%.0f", bt.tempC) to u * 9f, "°C" to u * 4.4f), cx + u * 25f, h * 0.865f, Color.WHITE)
            G.text(c, "حرارة البطارية", cx + u * 25f, h * 0.925f, u * 4f, gray)
        }
        Fx.edgeGlow(c, w, h, 0xFF39E36B.toInt(), 4559L)
        return k.b
    }

    // ===================== 7) BATTERY pill (image 8) =====================
    fun pill(ctx: Context, wi: Int, hi: Int): Bitmap {
        val k = Cv(wi, hi); val c = k.c; val w = k.w; val h = k.h
        val bt = Sys.batt(ctx)
        val col = when { bt.charging -> 0xFF39E36B.toInt(); bt.pct <= 20 -> 0xFFFF3B30.toInt(); else -> 0xFFFF9F0A.toInt() }
        val body = RectF(1f, 1f, w - 1f, h - 1f)
        c.drawRoundRect(body, h / 2, h / 2, G.p(0xFF000000.toInt()))
        c.drawRoundRect(body, h / 2, h / 2, G.p(G.al(Color.WHITE, 35), Paint.Style.STROKE, 1.2f))
        val cy = h / 2
        val x0 = h * 0.55f; val x1 = w - h * 1.75f
        val tw = h * 0.13f
        c.drawLine(x0, cy, x1, cy, G.p(G.al(Color.WHITE, 60), Paint.Style.STROKE, tw))
        val kw = h * 1.12f; val kh = h * 0.52f
        val kx = (x0 + (x1 - x0) * bt.pct / 100f).coerceIn(x0 + kw / 2, x1)
        if (kx > x0) {
            c.drawLine(x0, cy, kx, cy, G.glowPaint(col, tw, h * 0.2f, 200))
            c.drawLine(x0, cy, kx, cy, G.p(col, Paint.Style.STROKE, tw))
            val sx = x0 + (kx - x0) * Fx.phase(1700)
            c.drawLine(max(x0, sx - h * 0.25f), cy, min(kx, sx + h * 0.25f), cy, G.p(G.al(Color.WHITE, 200), Paint.Style.STROKE, tw))
        }
        c.drawCircle(kx, cy, h * 0.5f, G.glowPaint(col, h * 0.5f, h * 0.35f, (80 + 120 * Fx.pulse(1200)).toInt()).apply { style = Paint.Style.FILL })
        val kr = RectF(kx - kw / 2, cy - kh / 2, kx + kw / 2, cy + kh / 2)
        c.drawRoundRect(kr, kh / 2, kh / 2, G.p(col))
        G.bolt(c, kr.left + kh * 0.55f, cy, kh * 0.3f, Color.WHITE)
        G.text(c, "${bt.pct}", kr.left + kh * 0.9f + (kw - kh * 0.9f) / 2, cy + kh * 0.27f, kh * 0.78f, Color.WHITE, font = "sans-serif")
        val right = if (bt.charging && bt.remainMs > 0) {
            val m = (bt.remainMs / 60000).toInt()
            if (m >= 60) "~${m / 60}س" else "~${m}د"
        } else String.format(Locale.US, "%.0f°", bt.tempC)
        G.text(c, right, w - h * 0.45f, cy + h * 0.17f, h * 0.44f, col, Paint.Align.RIGHT)
        Fx.edgeGlow(c, w, h, 0xFFFF9F0A.toInt(), 4148L)
        return k.b
    }

    // ===================== 8) NOTIFICATIONS (image 14) =====================
    fun notif(ctx: Context, wi: Int, hi: Int): Bitmap {
        val k = Cv(wi, hi); val c = k.c; val w = k.w; val h = k.h; val u = k.u
        val orange = 0xFFFF7A2F.toInt()
        val pad = u * 3f
        // dim backdrop so the glass reads on any wallpaper
        c.drawRoundRect(RectF(0f, 0f, w, h), u * 16f, u * 16f, G.p(G.al(0xFF0A0706.toInt(), 150)))

        val top = RectF(pad, pad, w - pad, h * 0.565f)
        G.glass(c, top, u * 11f, G.al(0xFF3A302B.toInt(), 215), G.al(0xFF7A431F.toInt(), 200), 110)

        G.text(c, "الإشعارات", top.right - u * 6f, top.top + u * 10f, u * 6.8f, Color.WHITE, Paint.Align.RIGHT)
        G.text(c, "كل التطبيقات", top.right - u * 6f, top.top + u * 15.5f, u * 4f, G.al(Color.WHITE, 150), Paint.Align.RIGHT)
        c.drawCircle(top.left + u * 11f, top.top + u * 11f, u * 6.5f, G.p(G.al(Color.WHITE, 45)))
        c.drawCircle(top.left + u * 11f, top.top + u * 11f, u * 6.5f, G.p(G.al(Color.WHITE, 90), Paint.Style.STROKE, 1.2f))
        G.arrowUR(c, top.left + u * 11f, top.top + u * 11f, u * 2.4f, Color.WHITE, u * 0.7f)

        // chart
        var vals = State.hist(ctx)
        if (vals.all { it == 0 }) vals = intArrayOf(2, 4, 3, 8, 11, 6, 5)
        val mx = max(1, vals.max()).toFloat()
        val cl = top.left + u * 5f; val cr = top.right - u * 5f
        val cTop = h * 0.20f; val cBot = h * 0.385f
        val pts = vals.mapIndexed { i, v -> PointF(cl + (cr - cl) * i / 6f, cBot - (cBot - cTop) * (v / mx)) }
        val cp = Path(); cp.moveTo(pts[0].x, pts[0].y)
        for (i in 1 until pts.size) {
            val mxp = (pts[i - 1].x + pts[i].x) / 2
            cp.cubicTo(mxp, pts[i - 1].y, mxp, pts[i].y, pts[i].x, pts[i].y)
        }
        val fill = Path(cp); fill.lineTo(pts.last().x, cBot + u * 3f); fill.lineTo(pts[0].x, cBot + u * 3f); fill.close()
        val fp = Paint(Paint.ANTI_ALIAS_FLAG)
        fp.shader = LinearGradient(0f, cTop, 0f, cBot, G.al(orange, 90), G.al(orange, 0), Shader.TileMode.CLAMP)
        c.drawPath(fill, fp)
        c.drawPath(cp, G.glowPaint(orange, u * 1.6f, u * 2f, 160))
        c.drawPath(cp, G.p(0xFFFFD0A8.toInt(), Paint.Style.STROKE, u * 1f))
        var pk = 0; for (i in vals.indices) if (vals[i] >= vals[pk]) pk = i
        c.drawLine(pts[pk].x, pts[pk].y, pts[pk].x, cBot + u * 3f, G.p(G.al(Color.WHITE, 60), Paint.Style.STROKE, 1f))
        c.drawCircle(pts[pk].x, pts[pk].y, u * 3.6f, G.glowPaint(orange, u * 3f, u * 3f, (130 + 120 * Fx.pulse(1100)).toInt()).apply { style = Paint.Style.FILL })
        c.drawCircle(pts[pk].x, pts[pk].y, u * 1.9f, G.p(Color.WHITE))
        c.drawCircle(pts[pk].x, pts[pk].y, u * 1.1f, G.p(orange))
        run {
            val pmv = PathMeasure(cp, false); val pos = FloatArray(2)
            if (pmv.getPosTan(pmv.length * Fx.phase(3600), pos, null)) {
                c.drawCircle(pos[0], pos[1], u * 2.8f, G.glowPaint(orange, u * 3f, u * 3f, 220).apply { style = Paint.Style.FILL })
                c.drawCircle(pos[0], pos[1], u * 1.2f, G.p(Color.WHITE))
            }
        }

        // weekday bubbles (last 7 days, today = filled)
        val letters = arrayOf("ح", "ن", "ث", "ر", "خ", "ج", "س")
        val cal = Calendar.getInstance()
        for (i in 0..6) {
            val dcal = Calendar.getInstance(); dcal.add(Calendar.DAY_OF_YEAR, -(6 - i))
            val lt = letters[dcal.get(Calendar.DAY_OF_WEEK) - 1]
            val bx = cl + (cr - cl) * i / 6f; val by = h * 0.455f
            val today = i == 6
            c.drawCircle(bx, by, u * 4.4f, G.p(if (today) Color.WHITE else G.al(Color.WHITE, 28)))
            c.drawCircle(bx, by, u * 4.4f, G.p(G.al(Color.WHITE, 60), Paint.Style.STROKE, 1f))
            G.text(c, lt, bx, by + u * 1.6f, u * 4.4f, if (today) 0xFF111111.toInt() else G.al(Color.WHITE, 190))
        }
        G.text(c, SimpleDateFormat("d MMM", Locale("ar")).format(cal.time) + " • آخر ٧ أيام", w / 2, h * 0.535f, u * 4.2f, G.al(Color.WHITE, 170))

        // 2x2 pills
        val on = State.listenerOn
        val today = vals[6]; val yest = vals[5]
        val delta = if (yest > 0) ((today - yest) * 100f / yest).roundToInt() else 0
        val ph = h * 0.145f; val gap = u * 2.4f
        val colW = (w - pad * 2 - gap) / 2
        fun card(col: Int, row: Int, label: String, value: String, badge: String?, c1: Int, c2: Int) {
            val l = pad + col * (colW + gap); val t = if (row == 0) h * 0.595f else h * 0.77f
            val rf = RectF(l, t, l + colW, t + ph)
            G.glass(c, rf, ph / 2.4f, c1, c2, 110)
            G.text(c, label, rf.right - u * 5f, rf.top + u * 7f, u * 4.2f, G.al(Color.WHITE, 200), Paint.Align.RIGHT)
            G.text(c, value, rf.right - u * 5f, rf.bottom - u * 4.4f, u * 11f, Color.WHITE, Paint.Align.RIGHT)
            if (badge != null) {
                val bw = u * 17f; val bh = u * 6.6f
                val br = RectF(rf.left + u * 5f, rf.bottom - u * 4.4f - bh, rf.left + u * 5f + bw, rf.bottom - u * 4.4f)
                c.drawRoundRect(br, bh / 2, bh / 2, G.p(G.al(Color.WHITE, 35)))
                c.drawRoundRect(br, bh / 2, bh / 2, G.p(G.al(Color.WHITE, 80), Paint.Style.STROKE, 1f))
                G.text(c, badge, br.centerX(), br.centerY() + u * 1.6f, u * 4f, Color.WHITE)
            }
        }
        card(0, 0, "نشطة الآن", if (on) "${State.activeNotifs}" else "–", null, G.al(0xFFFF7A5C.toInt(), 215), G.al(0xFFB04A38.toInt(), 190))
        card(1, 0, "اليوم", "$today", if (yest > 0) (if (delta >= 0) "↑ $delta%" else "↓ ${abs(delta)}%") else null, G.al(0xFF5A5450.toInt(), 215), G.al(0xFF3A3532.toInt(), 200))
        card(0, 1, "التطبيقات", if (on) "${State.appsCount}" else "–", null, G.al(0xFFC4601E.toInt(), 215), G.al(0xFF5A2A10.toInt(), 200))
        // settings pill with glowing plus
        run {
            val l = pad + (colW + gap); val t = h * 0.77f
            val rf = RectF(l, t, l + colW, t + ph)
            G.glass(c, rf, ph / 2.4f, G.al(0xFF4A4541.toInt(), 215), G.al(0xFF302C29.toInt(), 200), 110)
            G.text(c, if (on) "الإعدادات" else "فعّل الوصول", rf.right - u * 5f, rf.centerY() + u * 1.7f, u * 4.6f, Color.WHITE, Paint.Align.RIGHT)
            val gx = rf.left + ph * 0.62f
            c.drawCircle(gx, rf.centerY(), ph * 0.34f, G.glowPaint(orange, ph * 0.3f, ph * 0.25f, (120 + 130 * Fx.pulse(1500)).toInt()).apply { style = Paint.Style.FILL })
            c.drawCircle(gx, rf.centerY(), ph * 0.3f, G.p(G.al(0xFFFFC38A.toInt(), 235)))
            G.plus(c, gx, rf.centerY(), ph * 0.13f, Color.WHITE, u * 0.9f)
        }
        Fx.edgeGlow(c, w, h, 0xFFFF7A2F.toInt(), 4285L)
        return k.b
    }

    // ===================== 9) COUNTDOWN capsule (image 12) =====================
    fun countdown(ctx: Context, wi: Int, hi: Int): Bitmap {
        val k = Cv(wi, hi); val c = k.c; val w = k.w; val h = k.h; val u = k.u
        val green = 0xFF22E070.toInt(); val cyan = 0xFF27E6D0.toInt()
        val pad = u * 8f
        val sp = ctx.getSharedPreferences("cfg", 0)
        val name = sp.getString("cd_name", "رأس السنة") ?: "رأس السنة"
        val def = Calendar.getInstance().apply { add(Calendar.YEAR, 1); set(Calendar.MONTH, 0); set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0) }.timeInMillis
        val ts = sp.getLong("cd_ts", def)
        val days = max(0L, ceil((ts - System.currentTimeMillis()) / 86_400_000.0).toLong())

        val r0 = (w - 2 * pad) / 2
        val rect = RectF(pad, pad, w - pad, h - pad)
        c.drawRoundRect(rect, r0, r0, G.glowPaint(green, pad * 0.7f, pad * 0.9f, (70 + 120 * Fx.pulse(2800)).toInt()))
        c.save(); val cp = Path(); cp.addRoundRect(rect, r0, r0, Path.Direction.CW); c.clipPath(cp)
        c.drawRect(0f, 0f, w, h, G.p(0xFF050505.toInt()))
        val bp = Paint(Paint.ANTI_ALIAS_FLAG)
        val gh = h * (0.38f + 0.06f * Fx.pulse(2800))
        bp.shader = LinearGradient(0f, h - pad, 0f, h - gh, intArrayOf(cyan, green, G.al(green, 0)), floatArrayOf(0f, 0.3f, 1f), Shader.TileMode.CLAMP)
        bp.maskFilter = BlurMaskFilter(pad, BlurMaskFilter.Blur.NORMAL)
        c.drawRect(0f, h - gh, w, h, bp)
        Fx.sparkles(c, pad + u * 8f, w - pad - u * 8f, h - pad - u * 4f, gh * 0.9f, u * 1f, 0xFFB6FFD6.toInt(), 9, 3600)
        c.restore()
        c.drawRoundRect(rect, r0, r0, G.p(G.al(Color.WHITE, 70), Paint.Style.STROKE, 1.5f))

        val cx = w / 2; val cy1 = pad + r0; val R = r0 * 0.80f
        val arc = RectF(cx - R, cy1 - R, cx + R, cy1 + R)
        c.drawArc(arc, 180f, 180f, false, G.p(G.al(Color.WHITE, 50), Paint.Style.STROKE, u * 4.5f))
        val frac = (1f - min(days, 365L) / 365f).coerceIn(0.03f, 1f)
        c.drawArc(arc, 180f, 180f * frac, false, G.glowPaint(green, u * 4.5f, u * 3f, (130 + 100 * Fx.pulse(1500)).toInt()))
        c.drawArc(arc, 180f, 180f * frac, false, G.p(0xFF2BD264.toInt(), Paint.Style.STROKE, u * 4.5f))
        val hd = G.pt(cx, cy1, R, 180.0 + 180.0 * frac)
        c.drawCircle(hd.x, hd.y, u * (3f + 1.2f * Fx.pulse(1000)), G.p(G.al(Color.WHITE, 90)))
        c.drawCircle(hd.x, hd.y, u * 1.6f, G.p(Color.WHITE))

        G.text(c, "باقي", cx, cy1 - R * 0.22f, u * 5.4f, G.al(Color.WHITE, 170))
        val ds = days.toString()
        G.text(c, ds, cx, cy1 + R * 0.36f, G.fit(ds, u * 21f, R * 1.1f), Color.WHITE, font = "sans-serif")
        G.text(c, "يوم", cx, cy1 + R * 0.62f, u * 6.5f, G.al(Color.WHITE, 200))
        val big = LinearGradient(0f, h * 0.60f, 0f, h * 0.86f, Color.WHITE, G.al(0xFFBFFFE0.toInt(), 120), Shader.TileMode.CLAMP)
        G.text(c, name, cx, h * 0.80f, G.fit(name, u * 26f, w * 0.68f), shader = big)
        Fx.edgeGlow(c, w, h, 0xFF22E070.toInt(), 4833L)
        return k.b
    }

    // ===================== 10) GLOW CHART (image 10) =====================
    fun glowChart(ctx: Context, wi: Int, hi: Int): Bitmap {
        val k = Cv(wi, hi); val c = k.c; val w = k.w; val h = k.h; val u = k.u
        val green = 0xFF2BFF6A.toInt()
        val pad = u * 6f
        G.glowCard(c, w, h, pad, green, 0xFF3CFF7C.toInt(), 3.6f, 0xFF070A07.toInt(), glowAlpha = (60 + 130 * Fx.pulse(2600)).toInt())

        G.text(c, "آخر تحديث الآن", pad + u * 9f, h * 0.175f, u * 4.2f, G.al(Color.WHITE, 130), Paint.Align.LEFT)
        val pr = RectF(w - pad - u * 36f, h * 0.135f, w - pad - u * 7f, h * 0.135f + u * 9f)
        c.drawRoundRect(pr, u * 4.5f, u * 4.5f, G.p(G.al(Color.WHITE, 40)))
        G.text(c, "أسبوعي  ⌄", pr.centerX(), pr.centerY() + u * 1.6f, u * 4.4f, G.al(Color.WHITE, 200))

        var vals = State.hist(ctx)
        if (vals.all { it == 0 }) vals = intArrayOf(3, 4, 3, 5, 14, 6, 5)
        val mx = max(1, vals.max()).toFloat()
        val l = pad + u * 1f; val r = w - pad - u * 1f
        val yt = h * 0.27f; val yb = h * 0.52f
        val pts = vals.mapIndexed { i, v -> PointF(l + (r - l) * i / 6f, yb - (yb - yt) * (v / mx)) }
        val cp = Path(); cp.moveTo(pts[0].x, pts[0].y)
        for (i in 1 until pts.size) { val m = (pts[i - 1].x + pts[i].x) / 2; cp.cubicTo(m, pts[i - 1].y, m, pts[i].y, pts[i].x, pts[i].y) }
        c.drawPath(cp, G.glowPaint(green, u * 3f, u * 4f, (120 + 110 * Fx.pulse(1800)).toInt()))
        c.drawPath(cp, G.p(green, Paint.Style.STROKE, u * 1.5f))
        var pk = 0; for (i in vals.indices) if (vals[i] >= vals[pk]) pk = i
        for (i in intArrayOf(1, 3, 5)) {
            c.drawLine(pts[i].x, pts[i].y, pts[i].x, h * 0.62f, G.p(G.al(Color.WHITE, 45), Paint.Style.STROKE, 1f))
            c.drawCircle(pts[i].x, pts[i].y, u * 1.6f, G.p(green))
        }
        c.drawLine(pts[pk].x, pts[pk].y, pts[pk].x, h * 0.62f, G.p(G.al(Color.WHITE, 70), Paint.Style.STROKE, 1f))
        c.drawCircle(pts[pk].x, pts[pk].y, u * (4.2f + 1.6f * Fx.pulse(1000)), G.p(G.al(green, 90)))
        c.drawCircle(pts[pk].x, pts[pk].y, u * 3.2f, G.p(0xFFB9FFCF.toInt()))
        run {
            val pm = PathMeasure(cp, false); val pos = FloatArray(2)
            if (pm.getPosTan(pm.length * Fx.phase(3200), pos, null)) {
                c.drawCircle(pos[0], pos[1], u * 3f, G.glowPaint(green, u * 3f, u * 3f, 230).apply { style = Paint.Style.FILL })
                c.drawCircle(pos[0], pos[1], u * 1.3f, G.p(Color.WHITE))
            }
        }
        val today = vals[6]; val yest = vals[5]
        val big = if (yest > 0) "${((today - yest) * 100f / yest).roundToInt()}%" else "$today"
        G.text(c, "الإشعارات", w / 2, h * 0.675f, u * 5.2f, G.al(Color.WHITE, 190))
        G.text(c, big, w / 2, h * 0.82f, G.fit(big, u * 27f, w * 0.7f), font = "sans-serif")
        G.text(c, if (yest > 0) "مقارنة بالأمس" else "إشعارات اليوم", w / 2, h * 0.875f, u * 4f, G.al(Color.WHITE, 140))
        Fx.sparkles(c, pad + u * 8f, w - pad - u * 8f, h - pad - u * 3f, h * 0.2f, u * 0.9f, 0xFFB6FFD6.toInt(), 8, 3400)
        Fx.edgeGlow(c, w, h, 0xFF2BFF6A.toInt(), 4833L)
        return k.b
    }
}
