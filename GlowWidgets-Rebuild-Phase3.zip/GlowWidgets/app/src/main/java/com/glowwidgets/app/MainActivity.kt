package com.glowwidgets.app

import android.Manifest
import android.app.Activity
import android.app.DatePickerDialog
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.Calendar
import kotlin.math.max
import kotlin.math.min

/** Main design gallery. The launcher widgets remain native AppWidget/RemoteViews. */
class MainActivity : Activity() {
    private data class Preview(val image: ImageView, val provider: BaseProvider)
    private val previews = mutableListOf<Preview>()
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var cardsHost: LinearLayout
    private lateinit var countLabel: TextView
    private var selectedCategory = "الكل"
    private val categories = listOf("الكل", "أساسي", "النظام", "أدوات", "إنتاجية")
    private val frame = object : Runnable {
        override fun run() {
            previews.toList().forEach { item ->
                val visible = Rect()
                if (item.image.width <= 0 || item.image.height <= 0 || !item.image.getLocalVisibleRect(visible)) return@forEach
                val w = item.image.width.coerceAtLeast(80)
                val h = item.image.height.coerceAtLeast(60)
                try { item.image.setImageBitmap(item.provider.draw(this@MainActivity, w, h)) }
                catch (_: Throwable) { }
            }
            ui.postDelayed(this, if (Fx.mode(this@MainActivity) == 2) 650L else 1200L)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun color(v: Long) = v.toInt()

    private fun rounded(fill: Int, radius: Int, stroke: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            cornerRadius = dp(radius).toFloat()
            setColor(fill)
            if (stroke != 0) setStroke(dp(1), stroke)
        }

    private fun gradient(a: Int, b: Int, radius: Int, stroke: Int = 0): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(a, b)).apply {
            cornerRadius = dp(radius).toFloat()
            if (stroke != 0) setStroke(dp(1), stroke)
        }

    private fun text(value: String, size: Float, tint: Int = Color.WHITE, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value; textSize = size; setTextColor(tint)
            if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
            includeFontPadding = false
        }

    private fun action(label: String, tint: Int, onClick: () -> Unit): TextView = text(label, 13f, Color.WHITE, true).apply {
        gravity = Gravity.CENTER
        background = rounded(tint, 16)
        setPadding(dp(14), 0, dp(14), 0)
        minHeight = dp(44)
        setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = color(0xFF080B12)
        window.navigationBarColor = color(0xFF080B12)
        if (Build.VERSION.SDK_INT >= 29) {
            window.isNavigationBarContrastEnforced = false
            window.isStatusBarContrastEnforced = false
        }

        val scroll = ScrollView(this).apply {
            setBackgroundColor(color(0xFF080B12)); clipToPadding = false
            isFillViewport = true
        }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(24), dp(18), dp(34))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        scroll.addView(page)
        page.addView(buildHero())
        page.addView(buildQuickActions(), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })
        page.addView(buildSectionHeader("استكشف الويدجات", "اختار شكل يليق بشاشتك"), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(28) })
        page.addView(buildFilters(), LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(14) })
        countLabel = text("10 تصميمات متاحة", 12f, color(0xFF8E9AAF))
        page.addView(countLabel, LinearLayout.LayoutParams(-1, dp(30)).apply { topMargin = dp(8) })
        cardsHost = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        page.addView(cardsHost)
        page.addView(buildSettings(), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(26) })
        page.addView(buildCountdownSettings(), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })
        page.addView(text("مصممة لتكون خفيفة، قابلة للتخصيص، وتعمل من الشاشة الرئيسية مباشرة.", 11f, color(0xFF657187)).apply {
            gravity = Gravity.CENTER; setPadding(dp(12), dp(22), dp(12), 0)
        })
        setContentView(scroll)
        renderCards()
    }

    private fun buildHero(): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(20), dp(20), dp(20))
            background = gradient(color(0xFF18243B), color(0xFF171329), 26, color(0x334CCBFF))
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val mark = TextView(this).apply {
            text = "✦"; textSize = 25f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = gradient(color(0xFF21B9D6), color(0xFF8C54FF), 18)
            layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
        }
        top.addView(mark)
        val titleCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        titleCol.addView(text("GLOW WIDGETS", 11f, color(0xFF8EDCFB), true))
        titleCol.addView(text("خلّي شاشتك تنبض بالحياة", 19f, Color.WHITE, true), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5) })
        top.addView(titleCol, LinearLayout.LayoutParams(0, -2, 1f))
        box.addView(top)
        box.addView(text("تصميمات مضيئة، بيانات حقيقية، ولمسات تفاعلية في مكان واحد.", 13f, color(0xFFC3CDE0)).apply {
            setLineSpacing(dp(3).toFloat(), 1f)
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(18) })
        val footer = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        footer.addView(text("10 ويدجات", 11f, color(0xFF9DE8F7), true))
        footer.addView(text("  •  " , 11f, color(0xFF64738C)))
        footer.addView(text("تحديثات حية", 11f, color(0xFFD5B7FF), true))
        box.addView(footer, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(17) })
        return box
    }

    private fun buildQuickActions(): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(action("تشغيل الخدمات", color(0xFFEA6A32)) { askPerms() }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(6) })
        row.addView(action("إذن الإشعارات", color(0xFF6046A8)) {
            try { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
            catch (_: Exception) { toast("إعدادات الإشعارات غير متاحة على هذا الجهاز") }
        }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginStart = dp(6) })
        return row
    }

    private fun buildSectionHeader(title: String, subtitle: String): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(text(title, 20f, Color.WHITE, true))
        col.addView(text(subtitle, 12f, color(0xFF8793A8)).apply { setPadding(0, dp(5), 0, 0) })
        return col
    }

    private fun buildFilters(): View {
        val horizontal = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        categories.forEach { category ->
            val chip = TextView(this).apply {
                text = category; textSize = 12f; gravity = Gravity.CENTER
                setTextColor(if (category == selectedCategory) Color.WHITE else color(0xFF9AA7BA))
                background = rounded(if (category == selectedCategory) color(0xFF344C70) else color(0xFF151C29), 18,
                    if (category == selectedCategory) color(0xFF6FCDF0) else color(0xFF273247))
                setPadding(dp(17), 0, dp(17), 0)
                layoutParams = LinearLayout.LayoutParams(-2, dp(40)).apply { marginStart = dp(6) }
                setOnClickListener {
                    selectedCategory = category
                    for (i in 0 until row.childCount) {
                        val v = row.getChildAt(i) as TextView
                        val active = v.text.toString() == selectedCategory
                        v.setTextColor(if (active) Color.WHITE else color(0xFF9AA7BA))
                        v.background = rounded(if (active) color(0xFF344C70) else color(0xFF151C29), 18,
                            if (active) color(0xFF6FCDF0) else color(0xFF273247))
                    }
                    renderCards()
                }
            }
            row.addView(chip)
        }
        horizontal.addView(row)
        return horizontal
    }

    private fun categoryOf(name: String): String = when (name) {
        "ساعة الوهج", "مشغل الموسيقى", "المنبه" -> "أساسي"
        "البطارية", "شريط البطارية", "الإشعارات" -> "النظام"
        "القبلة", "البوصلة" -> "أدوات"
        else -> "إنتاجية"
    }

    private fun renderCards() {
        previews.clear(); cardsHost.removeAllViews()
        val entries = ALL_WIDGETS.filter { selectedCategory == "الكل" || categoryOf(it.name) == selectedCategory }
        countLabel.text = "${entries.size} تصميمات متاحة"
        entries.chunked(2).forEach { pair ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.TOP }
            pair.forEachIndexed { index, entry ->
                row.addView(buildWidgetCard(entry), LinearLayout.LayoutParams(0, -2, 1f).apply {
                    if (index == 0) marginStart = dp(6) else marginEnd = dp(6)
                })
            }
            if (pair.size == 1) row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            cardsHost.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        }
        ui.removeCallbacks(frame); ui.post(frame)
    }

    private fun buildWidgetCard(entry: Entry): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(12))
            background = gradient(color(0xFF171F2D), color(0xFF111722), 22, color(0xFF29364B))
        }
        val imageFrame = FrameLayout(this).apply {
            background = rounded(color(0xFF0B1019), 16, color(0xFF29374B))
            clipToOutline = true
        }
        val image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "معاينة ${entry.name}"
            layoutParams = FrameLayout.LayoutParams(-1, dp(158), Gravity.CENTER)
            val d = resources.displayMetrics.density
            var w = entry.provider.defW * d; var h = entry.provider.defH * d
            val scale = min(1f, 440f / max(w, h)); w *= scale; h *= scale
            try { setImageBitmap(entry.provider.draw(this@MainActivity, w.toInt(), h.toInt())) } catch (_: Throwable) { }
        }
        imageFrame.addView(image)
        imageFrame.setOnClickListener { showPreview(entry) }
        card.addView(imageFrame, LinearLayout.LayoutParams(-1, dp(158)))
        card.addView(text(entry.name, 14f, Color.WHITE, true).apply { maxLines = 1 }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        val sub = text(categoryOf(entry.name) + "  ·  معاينة حية", 10f, color(0xFF91A1B8))
        card.addView(sub, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5) })
        val pin = TextView(this).apply {
            text = "＋  أضف للشاشة"; textSize = 11f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = gradient(color(0xFF245B78), color(0xFF384B83), 13)
            minHeight = dp(40)
            setOnClickListener { pin(entry.provider) }
        }
        card.addView(pin, LinearLayout.LayoutParams(-1, dp(40)).apply { topMargin = dp(12) })
        previews.add(Preview(image, entry.provider))
        return card
    }

    private fun showPreview(entry: Entry) {
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(16), dp(18), dp(18)); setBackgroundColor(color(0xFF111722)) }
        wrap.addView(text(entry.name, 19f, Color.WHITE, true))
        val iv = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            layoutParams = LinearLayout.LayoutParams(-1, dp(270)).apply { topMargin = dp(12) }
            val w = dp(entry.provider.defW).coerceAtLeast(200); val h = dp(entry.provider.defH).coerceAtLeast(150)
            try { setImageBitmap(entry.provider.draw(this@MainActivity, w, h)) } catch (_: Throwable) { }
        }
        wrap.addView(iv)
        wrap.addView(text("اضغط إضافة لوضع التصميم على الشاشة الرئيسية. قد تختلف الحركة حسب اللانشر وإصدار أندرويد.", 12f, color(0xFF9EACC0)).apply {
            setPadding(0, dp(8), 0, dp(14))
        })
        val dialog = android.app.Dialog(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8)); background = rounded(color(0xFF111722), 24) }
        col.addView(wrap)
        col.addView(action("＋  إضافة إلى الشاشة الرئيسية", color(0xFF276C91)) { dialog.dismiss(); pin(entry.provider) }, LinearLayout.LayoutParams(-1, dp(46)))
        dialog.setContentView(col)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * .90f).toInt(), -2)
    }

    private fun buildSettings(): View {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(16)); background = rounded(color(0xFF151D2A), 22, color(0xFF2B3A50)) }
        panel.addView(text("إعدادات الحركة", 17f, Color.WHITE, true))
        panel.addView(text("اختار سرعة المؤثرات بما يناسب جهازك.", 11f, color(0xFF8F9DB2)).apply { setPadding(0, dp(5), 0, dp(12)) })
        val prefs = getSharedPreferences("cfg", 0)
        val selected = prefs.getInt("anim", 2)
        val modes = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("إيقاف", "اقتصادي", "كامل").forEachIndexed { index, label ->
            val item = TextView(this).apply {
                text = label; textSize = 12f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
                background = rounded(if (selected == index) color(0xFFB65332) else color(0xFF273246), 14)
                layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginStart = dp(4); marginEnd = dp(4) }
                setOnClickListener {
                    prefs.edit().putInt("anim", index).apply()
                    for (i in 0 until modes.childCount) (modes.getChildAt(i) as TextView).background =
                        rounded(if (i == index) color(0xFFB65332) else color(0xFF273246), 14)
                    Live.start(this@MainActivity); Bus.all(this@MainActivity)
                }
            }
            modes.addView(item)
        }
        panel.addView(modes)
        panel.addView(text("ملاحظة: وضع الحركة الكامل يستخدم تحديثات متكررة للصور، لكن أندرويد واللانشر قد يدمجان الإطارات لتقليل استهلاك الطاقة.", 10f, color(0xFF7F8DA3)).apply {
            setLineSpacing(dp(3).toFloat(), 1f); setPadding(0, dp(12), 0, 0)
        })
        return panel
    }

    private fun buildCountdownSettings(): View {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(16)); background = rounded(color(0xFF151D2A), 22, color(0xFF2B3A50)) }
        panel.addView(text("موعدك القادم", 16f, Color.WHITE, true))
        val prefs = getSharedPreferences("cfg", 0)
        val name = EditText(this).apply {
            setSingleLine(true); textSize = 14f; setTextColor(Color.WHITE); setHintTextColor(color(0xFF748198)); hint = "اسم المناسبة"
            setText(prefs.getString("cd_name", "رأس السنة"))
            background = rounded(color(0xFF0D1420), 12, color(0xFF33445D)); setPadding(dp(12), 0, dp(12), 0)
        }
        panel.addView(name, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(12) })
        val chooseDate = action("اختيار التاريخ وحفظ", color(0xFF326C5C)) {
            val now = Calendar.getInstance()
            DatePickerDialog(this, { _, year, month, day ->
                val target = Calendar.getInstance().apply { set(year, month, day, 0, 0, 0); set(Calendar.MILLISECOND, 0) }
                prefs.edit().putString("cd_name", name.text.toString().ifBlank { "المناسبة" }).putLong("cd_ts", target.timeInMillis).apply()
                Bus.extra(this)
                toast("تم حفظ الموعد")
            }, now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH)).show()
        }
        panel.addView(chooseDate, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(10) })
        return panel
    }

    private fun pin(provider: BaseProvider) {
        val manager = AppWidgetManager.getInstance(this)
        if (Build.VERSION.SDK_INT >= 26 && manager.isRequestPinAppWidgetSupported) {
            manager.requestPinAppWidget(ComponentName(this, provider.javaClass), null, null)
        } else toast("اضغط مطولاً على الشاشة الرئيسية ← الأدوات ← ويدجتس الوهج")
    }

    private fun askPerms() {
        val permissions = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(permissions.toTypedArray(), 7)
        Live.start(this)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        Sys.loc(this); Live.start(this); Bus.all(this)
    }

    override fun onResume() {
        super.onResume(); Sys.loc(this); Live.start(this); Bus.all(this)
        ui.removeCallbacks(frame); ui.post(frame)
    }

    override fun onPause() { ui.removeCallbacks(frame); super.onPause() }
    override fun onDestroy() { ui.removeCallbacksAndMessages(null); super.onDestroy() }
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
