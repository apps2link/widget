package com.glowwidgets.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.GeomagneticField
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.view.KeyEvent
import kotlin.math.abs

object Live {
    fun start(ctx: Context) {
        try {
            val i = Intent(ctx, LiveService::class.java)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        } catch (_: Exception) { }
    }
}

class LiveService : Service(), SensorEventListener {
    private val h = Handler(Looper.getMainLooper())
    private var sensors: SensorManager? = null
    private var lastCompass = 0L
    private var lastBatt = 0L
    private var tick = 0
    private var declination = 0f

    private fun screenOn() = (getSystemService(POWER_SERVICE) as PowerManager).isInteractive

    private val screenRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == Intent.ACTION_SCREEN_OFF) stopSensors()
            else { startSensors(); Bus.all(this@LiveService) }
        }
    }
    private val timeRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            Bus.clock(c); Bus.alarm(c); Bus.battery(c)
        }
    }
    private val battRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val now = SystemClock.elapsedRealtime()
            if (now - lastBatt > 4000) { lastBatt = now; Bus.battery(c) }
        }
    }
    private val animLoop = object : Runnable {
        override fun run() {
            val c = this@LiveService
            val m = Fx.mode(c)
            val pm = c.getSystemService(POWER_SERVICE) as PowerManager
            val saver = pm.isPowerSaveMode
            if (m > 0 && screenOn() && !saver) Bus.animated(c)
            // RemoteViews are snapshots, not a real-time rendering surface. A 140ms
            // full redraw floods the launcher with bitmap updates and wastes power.
            // 250ms is the high-motion profile; the launcher may still coalesce frames.
            val delay = when {
                !screenOn() -> 2500L
                saver -> 1800L
                m == 2 -> 250L
                m == 1 -> 900L
                else -> 2500L
            }
            h.postDelayed(this, delay)
        }
    }
    private val loop = object : Runnable {
        override fun run() {
            val c = this@LiveService
            if (screenOn()) {
                if (State.playing) Bus.music(c)
                if (Sys.batt(c).charging) Bus.battery(c)
            }
            if (++tick % 300 == 0) { Sys.loc(c); updateDeclination() }
            h.postDelayed(this, 2000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("live", "Live widgets", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "live")
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("ويدجتس الوهج تعمل")
            .setContentIntent(Ix.app(this))
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)

        reg(screenRx, IntentFilter().apply { addAction(Intent.ACTION_SCREEN_ON); addAction(Intent.ACTION_SCREEN_OFF); addAction(Intent.ACTION_USER_PRESENT) })
        reg(timeRx, IntentFilter().apply {
            addAction(Intent.ACTION_TIME_TICK); addAction(Intent.ACTION_TIME_CHANGED); addAction(Intent.ACTION_TIMEZONE_CHANGED)
            addAction(android.app.AlarmManager.ACTION_NEXT_ALARM_CLOCK_CHANGED)
        })
        reg(battRx, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        Sys.loc(this); updateDeclination()
        if (screenOn()) startSensors()
        h.post(loop)
        h.post(animLoop)
        Bus.all(this)
    }

    private fun reg(rx: BroadcastReceiver, f: IntentFilter) {
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(rx, f, RECEIVER_NOT_EXPORTED) else registerReceiver(rx, f)
    }

    private fun updateDeclination() {
        declination = try {
            GeomagneticField(State.lat.toFloat(), State.lon.toFloat(), 0f, System.currentTimeMillis()).declination
        } catch (_: Exception) { 0f }
    }

    private fun startSensors() {
        if (sensors != null) return
        val sm = getSystemService(SENSOR_SERVICE) as SensorManager
        val s = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR) ?: return
        sm.registerListener(this, s, SensorManager.SENSOR_DELAY_UI)
        sensors = sm
    }
    private fun stopSensors() { sensors?.unregisterListener(this); sensors = null }

    override fun onSensorChanged(e: SensorEvent) {
        val r = FloatArray(9); val o = FloatArray(3)
        SensorManager.getRotationMatrixFromVector(r, e.values)
        SensorManager.getOrientation(r, o)
        if (abs(Math.toDegrees(o[1].toDouble())) > 50.0 || abs(Math.toDegrees(o[2].toDouble())) > 140.0) {
            val r2 = FloatArray(9)
            SensorManager.remapCoordinateSystem(r, SensorManager.AXIS_X, SensorManager.AXIS_Z, r2)
            SensorManager.getOrientation(r2, o)
        }
        val az = ((Math.toDegrees(o[0].toDouble()) + declination + 360.0) % 360.0).toFloat()
        val d = ((az - State.azimuth + 540f) % 360f) - 180f
        State.azimuth = (State.azimuth + 0.25f * d + 360f) % 360f
        val now = SystemClock.elapsedRealtime()
        if (Fx.mode(this) == 0 && now - lastCompass > 400) { lastCompass = now; Bus.compass(this); Bus.qibla(this) }
    }
    override fun onAccuracyChanged(s: Sensor?, a: Int) {}

    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY
    override fun onBind(i: Intent?): IBinder? = null
    override fun onDestroy() {
        stopSensors(); h.removeCallbacks(loop); h.removeCallbacks(animLoop)
        try { unregisterReceiver(screenRx); unregisterReceiver(timeRx); unregisterReceiver(battRx) } catch (_: Exception) {}
        super.onDestroy()
    }
}

class MediaNotifListener : NotificationListenerService() {
    private var msm: MediaSessionManager? = null
    private var current: MediaController? = null

    private val cb = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) { sync() }
        override fun onPlaybackStateChanged(state: PlaybackState?) { sync() }
    }
    private val sessListener = MediaSessionManager.OnActiveSessionsChangedListener { list -> pick(list) }

    override fun onListenerConnected() {
        State.listenerOn = true
        try {
            msm = getSystemService(MediaSessionManager::class.java)
            val cn = ComponentName(this, MediaNotifListener::class.java)
            msm?.addOnActiveSessionsChangedListener(sessListener, cn)
            pick(msm?.getActiveSessions(cn))
        } catch (_: Exception) {}
        recount()
        Live.start(this)
    }

    override fun onListenerDisconnected() {
        State.listenerOn = false
        try { msm?.removeOnActiveSessionsChangedListener(sessListener) } catch (_: Exception) {}
        current?.unregisterCallback(cb); current = null; State.controller = null
        Bus.notif(this)
    }

    private fun pick(list: List<MediaController>?) {
        current?.unregisterCallback(cb)
        val best = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: list?.firstOrNull()
        current = best; State.controller = best
        best?.registerCallback(cb)
        sync()
    }

    private fun sync() {
        val c = current
        if (c == null) {
            State.title = ""; State.artist = ""; State.playing = false; State.posMs = 0; State.durMs = 0
        } else {
            val md = c.metadata; val ps = c.playbackState
            State.title = md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: ""
            State.artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
            State.durMs = md?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
            State.playing = ps?.state == PlaybackState.STATE_PLAYING
            State.posMs = ps?.position ?: 0L
            State.posStamp = ps?.lastPositionUpdateTime ?: SystemClock.elapsedRealtime()
        }
        Bus.music(this)
    }

    private fun counts(): List<StatusBarNotification> = try {
        activeNotifications.filter {
            !it.isOngoing && it.packageName != packageName &&
                (it.notification.flags and Notification.FLAG_GROUP_SUMMARY) == 0
        }
    } catch (_: Exception) { emptyList() }

    private fun recount() {
        val l = counts()
        State.activeNotifs = l.size
        State.appsCount = l.map { it.packageName }.toSet().size
        Bus.notif(this)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!sbn.isOngoing && sbn.packageName != packageName &&
            (sbn.notification.flags and Notification.FLAG_GROUP_SUMMARY) == 0) State.bump(this)
        recount()
    }
    override fun onNotificationRemoved(sbn: StatusBarNotification) { recount() }
}

class MediaActionReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        val k = i.getStringExtra("k") ?: return
        val tc = State.controller?.transportControls
        if (tc != null) {
            when (k) {
                "prev" -> tc.skipToPrevious()
                "next" -> tc.skipToNext()
                else -> if (State.playing) tc.pause() else tc.play()
            }
        } else {
            val code = when (k) {
                "prev" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
                "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
                else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
            }
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) { Live.start(ctx); Bus.all(ctx) }
}
