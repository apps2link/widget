package com.glowwidgets.app

import android.Manifest
import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun btn(label: String, bg: Int, onClick: () -> Unit) = Button(this).apply {
        text = label; setTextColor(Color.WHITE); isAllCaps = false; textSize = 14f
        background = GradientDrawable().apply { cornerRadius = dp(22).toFloat(); setColor(bg) }
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8) }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.statusBarColor = 0xFF0A0A0A.toInt(); window.navigationBarColor = 0xFF0A0A0A.toInt()
        val sv = ScrollView(this); sv.setBackgroundColor(0xFF0A0A0A.toInt())
        val root = LinearLayout(this); root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(18), dp(36), dp(18), dp(36)); root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        sv.addView(root)

        root.addView(TextView(this).apply { text = "ويدجتس الوهج"; setTextColor(Color.WHITE); textSize = 28f; typeface = Typeface.DEFAULT_BOLD })
        root.addView(TextView(this).apply {
            text = "ساعة • موسيقى • منبه • قبلة • بوصلة • بطارية • إشعارات"
            setTextColor(0xFF9AA0A6.toInt()); textSize = 13f; setPadding(0, dp(4), 0, dp(10))
        })
        root.addView(btn("١) تشغيل الخدمة والأذونات (موقع + إشعارات)", 0xFFFF5A12.toInt()) { askPerms() })
        root.addView(btn("٢) السماح بالوصول للإشعارات والموسيقى", 0xFF8A3DFF.toInt()) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })

        for (e in ALL_WIDGETS) {
            root.addView(TextView(this).apply {
                text = e.name; setTextColor(Color.WHITE); textSize = 17f; typeface = Typeface.DEFAULT_BOLD
                setPadding(0, dp(22), 0, dp(8))
            })
            val d = resources.displayMetrics.density
            var wp = e.provider.defW * d; var hp = e.provider.defH * d
            val sc = min(1f, 560f / max(wp, hp)); wp *= sc; hp *= sc
            val bmp = try { e.provider.draw(this, wp.toInt(), hp.toInt()) } catch (_: Throwable) { null }
            val iv = ImageView(this).apply {
                if (bmp != null) setImageBitmap(bmp)
                adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER
                layoutParams = LinearLayout.LayoutParams(-2, -2).apply { gravity = Gravity.CENTER_HORIZONTAL }
                maxWidth = dp(e.provider.defW)
            }
            root.addView(iv)
            root.addView(btn("إضافة إلى الشاشة الرئيسية", 0xFF2A2A2C.toInt()) { pin(e.provider) })
        }
        setContentView(sv)
    }

    private fun pin(p: BaseProvider) {
        val mgr = AppWidgetManager.getInstance(this)
        if (Build.VERSION.SDK_INT >= 26 && mgr.isRequestPinAppWidgetSupported)
            mgr.requestPinAppWidget(ComponentName(this, p.javaClass), null, null)
        else Toast.makeText(this, "اضغط مطولاً على الشاشة الرئيسية ← الأدوات ← ويدجتس الوهج", Toast.LENGTH_LONG).show()
    }

    private fun askPerms() {
        val l = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(l.toTypedArray(), 7)
        Live.start(this)
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r)
        Sys.loc(this); Live.start(this); Bus.all(this)
    }

    override fun onResume() { super.onResume(); Sys.loc(this); Live.start(this); Bus.all(this) }
}
