# Widget Studio 2.0

Premium Android widget studio: 38 designs in 14 categories, per-instance customisation, live preview,
and one-tap "Add to Home Screen" (`AppWidgetManager.requestPinAppWidget`) that preserves your configuration.

> **Build status: NOT compiled or run by the author.** The environment this was written in had no Android SDK,
> Gradle, Kotlin compiler or network. Static checks done: balanced syntax, well-formed XML, every `R.*`
> reference and every manifest class resolves. **Expect to fix a few compile errors on first build.**
> Open in Android Studio (Ladybug+, JDK 17) and run `:app:assembleDebug`, or push to GitHub: `.github/workflows/build.yml`
> builds and uploads the APK. The Gradle wrapper jar is not in the repo; Android Studio regenerates it.

## Architecture

```
core/      WidgetConfig (JSON, per instance), Store (DataStore), colour utils
render/    Node.kt     layout IR (Box/Col/Row/Text/Clock/Gfx/Analog) shared by both renderers
           Fx.kt       effects library: glass, neon, HUD, pulse, rings, liquid, waveform, sun arc, dials, icons, weather glyphs
           GlanceRenderer   IR -> Glance (real widget)      ComposeRenderer  IR -> Compose (preview, identical layout)
           BitmapCache bounded LRU, <=600k px per layer
designs/   Ctx + Design + Registry, 38 designs as pure functions Ctx -> N
data/      DataProvider (battery/system/agenda/apps), WeatherRepo (Open-Meteo), MediaListenerService
widgets/   StudioWidget (one GlanceAppWidget, SizeMode.Exact), 4 receivers (2x2, 4x1, 4x2, 4x4), Updater, Pinner,
           SystemEventsReceiver, WidgetConfigActivity, Actions
work/      Scheduler + RefreshWorker (WorkManager, only what installed widgets need)
wallpaper/ optional live wallpaper (24 fps cap, stops when hidden)
ui/        Home, Library, Favorites, My Widgets, Settings, Editor, Live Preview (+ preserved "Live Lab" demos)
```

* **Per-instance config**: `cfg_<appWidgetId>` JSON in DataStore; deleted in `onDeleted`.
* **Pin flow**: config saved as *pending* per provider -> `requestPinAppWidget` -> new instance claims it atomically
  (in `provideGlance`, the config activity, or the pin callback). Same mechanism makes the manual-add fallback keep your design (30 min TTL).
* **Preview = widget**: both renderers consume the same IR and the same `Painter`s at the widget's real dp size.
* **Battery**: clocks are platform `TextClock`/`AnalogClock` (self-ticking, zero background work). Everything else refreshes on
  manifest-allowed system events + WorkManager (15/30/60 min by setting; cancelled when no widget needs it).
* **Animation honesty**: pulse/light-sweep/liquid-wave/waveform/radar animate only in Live Preview and the live wallpaper;
  home-screen widgets render them statically.

## Known limits / things to verify on device
* Launchers differ in real widget size; designs lay out from actual `LocalSize`, but check yours.
* Transparent widgets can't know the wallpaper; use Text colour: Dark for light wallpapers.
* `RemoteViews.setCharSequence(..., "setFormat12Hour")` on `TextClock` is relied on for clock formats.
* Analog hands are the platform `AnalogClock`: hand colour snaps to 6 palette entries.
* Music: now-playing needs notification access (optional); transport buttons work without it. Waveform is decorative.
* UI strings are hard-coded English (not yet in `strings.xml`); the preserved Live Lab demos remain Arabic.

## Removed
`PillClockWidget`, `ShortcutPillsWidget` and their XML layouts/shape drawables: replaced by designs **Pill Duo** and **Shortcut Pills**
(same look and click targets, now fully customisable and installable per instance).


## Premium visual update (2.1.0)

This update adds four premium widget designs to the existing registry:

- **Aether Orbit** — orbital telemetry dial with spectral arc, calibration ticks, glow and animated particles in live rendering.
- **Prism Time** — layered prismatic glass clock surface with bevel, refraction bands and editorial typography.
- **Spectrum Pulse** — battery, memory and storage telemetry with segmented gradient meters.
- **Nébula Energy** — liquid battery capsule with luminous rim and waveform detail.

New reusable drawing primitives are in `render/PremiumFx.kt` (`OrbitPainter`, `PrismPainter`). Existing renderers and data models are retained. The Android home-screen widget surface is refreshed by the existing widget update mechanism; continuous animation remains limited to live preview / wallpaper because standard Android app widgets do not provide unrestricted frame-by-frame animation.

Version: **2.1.0** (versionCode 3).
