package com.example.widgetstudio.designs

import com.example.widgetstudio.core.*
import com.example.widgetstudio.render.*
import kotlin.math.min

private val P_WHITE = 0xFFFFFFFF.toInt()
private val P_CYAN = 0xFF55E7FF.toInt()
private val P_VIOLET = 0xFF9C72FF.toInt()
private val P_PINK = 0xFFFF6CCB.toInt()

private val premiumBase: (WidgetConfig) -> WidgetConfig = {
    it.copy(bg=0xFF080B18.toInt(), bg2=0xFF17112C.toInt(), accent=P_CYAN,
        gradient=true, gradientAngle=138, alpha=.98f, radius=30f, glow=.9f,
        font=FontKey.MEDIUM, textMode=TextMode.LIGHT, effects=setOf(Effect.GLASS,Effect.LIGHT,Effect.HUD))
}

private val orbitCore = Design(
    id="pr_orbit_core", name="Aether Orbit", tag="Orbital instrument with luminous calibration marks",
    cat=Category.HUD, sizes=listOf(WSize.SMALL,WSize.MEDIUM), needs=setOf(Need.BATTERY,Need.PERIODIC),
    featured=true, effects=Effect.entries.toList(), preset={ premiumBase(it).copy(accent=P_CYAN) }
) { c ->
    val s=min(c.h*.78f,c.w*.42f)
    c.root(Act.OpenStudio,8f,
        row(VA.C,HA.S,M.Fill,
            BoxN(A.C,M(w=s,h=s),listOf(gfx(OrbitPainter(P_CYAN,P_VIOLET,c.data.battery,c.cfg.glow),s,s),
                col(HA.C,VA.C,M(),c.T("${c.data.battery}%",s*.25f,1f,FontKey.BLACK),c.T("ENERGY",s*.085f,.72f,FontKey.CONDENSED)))),
            gap(12f),
            col(HA.S,VA.C,M(weight=true),
                c.T("AETHER / 01",10f,.65f,FontKey.MONO),
                c.C(c.tf,min(c.h*.31f,36f),1f,FontKey.LIGHT),
                c.T(if(c.data.charging) "CHARGING" else "POWER SYSTEM",9f,.7f,FontKey.CONDENSED),
                gap(h=8f),
                gfx(CellsPainter(c.data.battery,18,P_CYAN,P_VIOLET,0x334DE1FF,2f,.7f),c.w-s-38f,8f)
            )
        )
    )
}

private val prismClock = Design(
    id="pr_prism_clock", name="Prism Time", tag="Iridescent glass slab with editorial typography",
    cat=Category.GLASS, sizes=listOf(WSize.SMALL,WSize.MEDIUM,WSize.LARGE), needs=setOf(Need.DATE),
    featured=true, effects=Effect.entries.toList(), fields=listOf(Field.Toggle("h24","24-hour clock",false)),
    preset={ premiumBase(it).copy(bg=0xFF10142A.toInt(),bg2=0xFF29204C.toInt(),accent=P_PINK,glow=.65f,radius=34f) }
) { c ->
    val pad=8f
    val pw=c.w-pad*2; val ph=c.h-pad*2
    c.root(Act.Calendar,pad,
        BoxN(A.C,M.Fill,listOf(
            gfx(PrismPainter(0xFF3D70A8.toInt(),0xFF8055B8.toInt(),0xFFB84D9A.toInt(),34f),pw,ph),
            col(HA.S,VA.C,M.Fill.pad(18f),
                c.T("LOCAL TIME  /  STUDIO",9f,.8f,FontKey.MONO,color=P_WHITE),
                c.C(c.tf,min(c.h*.43f,66f),1f,FontKey.THIN,color=P_WHITE),
                row(VA.C,HA.S,M.FillW,c.T("WIDGET LAB",9f,.85f,FontKey.MEDIUM,color=P_WHITE),spacer(),c.C("EEE  ·  d MMM",10f,.9f,FontKey.MEDIUM,color=P_WHITE))
            )
        ))
    )
}

private val spectrumStatus = Design(
    id="pr_spectrum_status", name="Spectrum Pulse", tag="Layered spectral meters for battery and memory",
    cat=Category.SYSTEM, sizes=listOf(WSize.MEDIUM,WSize.LARGE),
    needs=setOf(Need.BATTERY,Need.SYSTEM,Need.PERIODIC), featured=true,
    effects=Effect.entries.toList(), preset={ premiumBase(it).copy(accent=P_VIOLET,glow=.72f) }
) { c ->
    val pad=14f; val w=c.w-pad*2
    fun meter(label:String,value:Int,a:Int,b:Int)=col(HA.S,VA.C,M(w=w),
        row(VA.C,HA.S,M.FillW,c.T(label,10f,.68f,FontKey.MONO),spacer(),c.T("$value%",13f,1f,FontKey.MEDIUM)),
        gap(h=5f),gfx(CellsPainter(value,30,a,b,a.withAlpha(.16f),2.4f,.75f),w,12f,"$label $value percent"))
    c.root(Act.OpenStudio,pad,
        col(HA.S,VA.C,M.Fill,
            row(VA.C,HA.S,M.FillW,c.T("SYSTEM / TELEMETRY",10f,.72f,FontKey.MONO),spacer(),c.icon(IconKind.CHIP,17f,P_CYAN)),
            gap(h=10f),
            row(VA.C,HA.S,M.FillW,
                BoxN(A.C,M(w=76f,h=76f),listOf(gfx(OrbitPainter(P_VIOLET,P_PINK,c.data.battery,.6f),76f,76f),c.T("${c.data.battery}%",17f,1f,FontKey.BLACK))),
                gap(14f),col(HA.S,VA.C,M(weight=true),c.C(c.tf,min(c.h*.25f,34f)),c.T("DEVICE STATUS",9f,.62f,FontKey.MONO),c.T(if(c.data.charging)"POWER CONNECTED" else "RUNNING NORMAL",10f,.9f,FontKey.MEDIUM))
            ),
            gap(h=12f),meter("MEMORY",c.data.ramPct,P_CYAN,P_VIOLET),gap(h=10f),meter("STORAGE",c.data.storagePct,P_PINK,P_VIOLET)
        )
    )
}

private val liquidEnergy = Design(
    id="pr_liquid_energy", name="Nébula Energy", tag="Glass battery capsule with liquid fill and halo",
    cat=Category.BATTERY, sizes=listOf(WSize.SMALL,WSize.MEDIUM), needs=setOf(Need.BATTERY,Need.PERIODIC),
    effects=Effect.entries.toList(), featured=true,
    preset={ premiumBase(it).copy(accent=0xFF69F5C8.toInt(),bg=0xFF071A1B.toInt(),bg2=0xFF101B35.toInt(),glow=.95f) }
) { c ->
    val s=min(c.h*.76f,c.w*.34f)
    c.root(Act.OpenStudio,10f,
        row(VA.C,HA.S,M.Fill,
            BoxN(A.C,M(w=s,h=s),listOf(gfx(LiquidPainter(c.data.battery,0xFF41E6C1.toInt(),0xFF347DFF.toInt(),0xFF69F5C8.toInt(),.85f,0,26f),s,s),
                c.T("${c.data.battery}%",s*.22f,1f,FontKey.BLACK))),
            gap(14f),col(HA.S,VA.C,M(weight=true),
                c.T("ENERGY CELL",10f,.65f,FontKey.MONO),c.C(c.tf,min(c.h*.34f,40f),1f,FontKey.LIGHT),
                c.T(if(c.data.charging)"FAST CHARGE" else "CAPACITY",10f,.8f,FontKey.MEDIUM),gap(h=8f),
                gfx(WavePainter(12,24,0xFF69F5C8.toInt(),0xFF347DFF.toInt(),.12f,true),c.w-s-42f,18f)
            )
        )
    )
}

val premiumDesigns: List<Design> = listOf(orbitCore,prismClock,spectrumStatus,liquidEnergy)
