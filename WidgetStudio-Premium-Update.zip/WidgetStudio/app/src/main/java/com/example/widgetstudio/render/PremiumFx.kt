package com.example.widgetstudio.render

import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import com.example.widgetstudio.core.lerpColor
import com.example.widgetstudio.core.withAlpha
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

private fun premiumPaint(color: Int = 0, style: Paint.Style = Paint.Style.FILL, width: Float = 1f) =
    Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color; this.style = style; strokeWidth = width; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }

/** Layered orbital instrument: gradient rings, luminous nodes, radial bloom and fine calibration marks. */
data class OrbitPainter(val primary: Int, val secondary: Int, val value: Int = 72, val glow: Float = .8f) : Painter {
    override fun paint(c: Canvas, w: Float, h: Float, d: Float, phase: Float) {
        val cx = w * .5f; val cy = h * .5f
        val radius = min(w, h) * .37f
        if (radius < 8f) return
        val bloom = premiumPaint().apply { shader = RadialGradient(cx, cy, radius * 1.8f, primary.withAlpha(.24f * glow), primary.withAlpha(0f), Shader.TileMode.CLAMP) }
        c.drawCircle(cx, cy, radius * 1.8f, bloom)
        val outer = RectF(cx-radius, cy-radius, cx+radius, cy+radius)
        c.drawCircle(cx, cy, radius, premiumPaint(0x22FFFFFF, Paint.Style.STROKE, 1.1f*d))
        c.drawCircle(cx, cy, radius*.78f, premiumPaint(0x33FFFFFF, Paint.Style.STROKE, .7f*d))
        val sweep = SweepGradient(cx, cy, intArrayOf(primary.withAlpha(.05f), primary, secondary, primary.withAlpha(.08f)), null)
        val arc = premiumPaint(style = Paint.Style.STROKE, width = 3.2f*d).apply { shader = sweep }
        c.drawArc(outer, -90f, 360f*value.coerceIn(0,100)/100f, false, arc)
        val inner = RectF(cx-radius*.68f, cy-radius*.68f, cx+radius*.68f, cy+radius*.68f)
        c.drawArc(inner, 205f, 130f, false, premiumPaint(secondary.withAlpha(.72f), Paint.Style.STROKE, 1.2f*d))
        for (i in 0 until 48) {
            val a = Math.PI*2*i/48.0
            val major = i%4==0
            val r1 = radius*(if(major) .88f else .92f); val r2=radius*(if(major) .98f else .95f)
            c.drawLine(cx+cos(a).toFloat()*r1, cy+sin(a).toFloat()*r1, cx+cos(a).toFloat()*r2, cy+sin(a).toFloat()*r2,
                premiumPaint(if(major) 0x99FFFFFF.toInt() else 0x44FFFFFF, Paint.Style.STROKE, (if(major) 1.2f else .7f)*d))
        }
        val angle = (-90.0 + 360.0*value.coerceIn(0,100)/100.0)
        val rad = Math.toRadians(angle)
        val nx = cx+cos(rad).toFloat()*radius; val ny=cy+sin(rad).toFloat()*radius
        for(i in 3 downTo 1) c.drawCircle(nx,ny,(3f+i*2f)*d,premiumPaint(primary.withAlpha(.12f*glow)))
        c.drawCircle(nx,ny,3.2f*d,premiumPaint(0xFFFFFFFF.toInt()))
        c.drawCircle(cx,cy,3f*d,premiumPaint(0xFFFFFFFF.toInt()))
        // Three orbiting particles move only in animated preview / wallpaper; static widgets stay battery-safe.
        for(i in 0..2){
            val a=phase*6.283185f+i*2.094f
            val rr=radius*(.52f+i*.055f)
            c.drawCircle(cx+cos(a)*rr,cy+sin(a)*rr,1.8f*d,premiumPaint(lerpColor(primary,secondary,i/2f).withAlpha(.85f)))
        }
    }
}

/** Prismatic glass surface with diagonal spectral refraction and a fine inner bevel. */
data class PrismPainter(val a: Int, val b: Int, val c3: Int, val radius: Float = 24f) : Painter {
    override fun paint(c: Canvas, w: Float, h: Float, d: Float, phase: Float) {
        val r=RectF(1.5f*d,1.5f*d,w-1.5f*d,h-1.5f*d)
        if(r.width()<=2 || r.height()<=2) return
        val rad=min(radius*d,min(r.width(),r.height())*.22f)
        val path=Path().apply{addRoundRect(r,rad,rad,Path.Direction.CW)}
        c.save(); c.clipPath(path)
        val base=premiumPaint().apply{shader=LinearGradient(r.left,r.top,r.right,r.bottom,intArrayOf(a.withAlpha(.88f),b.withAlpha(.76f),c3.withAlpha(.88f)),null,Shader.TileMode.CLAMP)}
        c.drawRect(r,base)
        val light=premiumPaint().apply{shader=RadialGradient(r.left+r.width()*.2f,r.top+r.height()*.08f,r.width()*.9f,intArrayOf(0x66FFFFFF,0x12FFFFFF,0x00FFFFFF),null,Shader.TileMode.CLAMP)}
        c.drawRect(r,light)
        val stripe=Path().apply{moveTo(r.left-r.width()*.2f,r.bottom);lineTo(r.left+r.width()*.42f,r.top);lineTo(r.left+r.width()*.56f,r.top);lineTo(r.left-r.width()*.06f,r.bottom);close()}
        c.drawPath(stripe,premiumPaint(0x16FFFFFF))
        c.restore()
        c.drawPath(path,premiumPaint(0x77FFFFFF,Paint.Style.STROKE,1.1f*d))
        val inner=RectF(r.left+3*d,r.top+3*d,r.right-3*d,r.bottom-3*d)
        c.drawRoundRect(inner,max(0f,rad-3*d),max(0f,rad-3*d),premiumPaint(0x22FFFFFF,Paint.Style.STROKE,.65f*d))
    }
}
