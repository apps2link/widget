# Widget Studio

Android app (Kotlin, Jetpack Compose, Glance) with animated demos and two home-screen widgets.

## Run
1. Open the folder in Android Studio (Ladybug or newer, JDK 17).
2. Let Gradle sync (the wrapper downloads Gradle 8.9).
3. Run on a device or emulator with Android 8.0 (API 26) or newer.

## Widgets
Long-press the home screen, open Widgets, pick Widget Studio: Pill Clock or Shortcut Pills.

## Structure
- ui/effects: aurora background, particles, glass card
- ui/screens: gallery, clock, weather, pills, HUD, ring
- widgets: Glance widgets (clock and shortcut pills)
- util: app launch helpers
