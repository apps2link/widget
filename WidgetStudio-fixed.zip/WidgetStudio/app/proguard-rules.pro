# Glance / WorkManager ship their own consumer rules. Keep our receivers, services and callbacks.
-keep class com.example.widgetstudio.widgets.** { *; }
-keep class com.example.widgetstudio.work.** { *; }
-keep class com.example.widgetstudio.data.MediaListenerService { *; }
-keep class com.example.widgetstudio.wallpaper.** { *; }
