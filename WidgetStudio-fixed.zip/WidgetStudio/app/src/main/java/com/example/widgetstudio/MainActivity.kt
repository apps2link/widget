package com.example.widgetstudio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.example.widgetstudio.ui.effects.AuroraBackground
import com.example.widgetstudio.ui.screens.ClockScreen
import com.example.widgetstudio.ui.screens.Demo
import com.example.widgetstudio.ui.screens.GalleryScreen
import com.example.widgetstudio.ui.screens.HudScreen
import com.example.widgetstudio.ui.screens.PillsScreen
import com.example.widgetstudio.ui.screens.RingScreen
import com.example.widgetstudio.ui.screens.WeatherScreen
import com.example.widgetstudio.ui.theme.WidgetStudioTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { WidgetStudioTheme { AppRoot() } }
    }
}

@Composable
fun AppRoot() {
    var current by remember { mutableStateOf<Demo?>(null) }
    BackHandler(enabled = current != null) { current = null }

    AuroraBackground {
        AnimatedContent(
            targetState = current,
            transitionSpec = {
                (fadeIn(tween(450)) + scaleIn(initialScale = 0.92f, animationSpec = tween(450))) togetherWith
                    (fadeOut(tween(250)) + scaleOut(targetScale = 1.06f, animationSpec = tween(250)))
            },
            label = "root"
        ) { demo ->
            val back = { current = null }
            when (demo) {
                null -> GalleryScreen(onOpen = { current = it })
                Demo.CLOCK -> ClockScreen(back)
                Demo.WEATHER -> WeatherScreen(back)
                Demo.PILLS -> PillsScreen(back)
                Demo.HUD -> HudScreen(back)
                Demo.RING -> RingScreen(back)
            }
        }
    }
}
