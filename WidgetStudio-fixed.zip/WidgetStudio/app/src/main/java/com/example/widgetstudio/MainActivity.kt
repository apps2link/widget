package com.example.widgetstudio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.lifecycle.lifecycleScope
import com.example.widgetstudio.ui.AppViewModel
import com.example.widgetstudio.ui.StudioApp
import com.example.widgetstudio.ui.theme.WidgetStudioTheme
import com.example.widgetstudio.work.Scheduler
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { WidgetStudioTheme { StudioApp(vm, onApplyConfig = {}, onCancelConfig = {}) } }
        lifecycleScope.launch { Scheduler.sync(applicationContext) } // re-align background work with what is installed
    }
}
