package com.example.widgetstudio.core

import android.graphics.Color as AColor

fun Int.withAlpha(a: Float): Int = (this and 0x00FFFFFF) or ((a.coerceIn(0f, 1f) * 255f + 0.5f).toInt() shl 24)
fun Int.withAlphaInt(a: Int): Int = (this and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)
fun Int.opaque(): Int = this or (0xFF shl 24)

fun luminance(c: Int): Float {
    fun ch(v: Int): Float { val s = v / 255f; return if (s <= 0.03928f) s / 12.92f else Math.pow(((s + 0.055f) / 1.055f).toDouble(), 2.4).toFloat() }
    return 0.2126f * ch(AColor.red(c)) + 0.7152f * ch(AColor.green(c)) + 0.0722f * ch(AColor.blue(c))
}

fun lerpColor(a: Int, b: Int, t: Float): Int {
    val k = t.coerceIn(0f, 1f)
    fun l(x: Int, y: Int) = (x + (y - x) * k).toInt()
    return AColor.argb(l(AColor.alpha(a), AColor.alpha(b)), l(AColor.red(a), AColor.red(b)), l(AColor.green(a), AColor.green(b)), l(AColor.blue(a), AColor.blue(b)))
}

fun hsv(h: Float, s: Float, v: Float): Int = AColor.HSVToColor(floatArrayOf(h.coerceIn(0f, 360f), s.coerceIn(0f, 1f), v.coerceIn(0f, 1f)))
fun toHsv(c: Int): FloatArray = FloatArray(3).also { AColor.colorToHSV(c, it) }
fun hexOf(c: Int): String = String.format("#%06X", c and 0xFFFFFF)
fun parseHex(s: String): Int? = runCatching { AColor.parseColor(if (s.startsWith("#")) s else "#$s") }.getOrNull()?.let { it or (0xFF shl 24) }

private const val WHITE = 0xFFFFFFFF.toInt()
private const val INK = 0xFF10131A.toInt()

/** Primary text colour for a widget. AUTO picks by background luminance; translucent backgrounds assume a dark wallpaper. */
fun WidgetConfig.fg(): Int = when (textMode) {
    TextMode.LIGHT -> WHITE
    TextMode.DARK -> INK
    TextMode.ACCENT -> accent
    TextMode.AUTO -> {
        val l = if (gradient) (luminance(bg) + luminance(bg2)) / 2f else luminance(bg)
        if (alpha < 0.4f || l < 0.32f) WHITE else INK
    }
}
