package com.example.widgetstudio.core

import org.json.JSONArray
import org.json.JSONObject

/** Widget size classes. Each one maps to its own AppWidget provider (see widgets/Receivers.kt). */
enum class WSize(val label: String, val cw: Int, val ch: Int) {
    SMALL("Small 2×2", 2, 2),
    STRIP("Strip 4×1", 4, 1),
    MEDIUM("Medium 4×2", 4, 2),
    LARGE("Large 4×4", 4, 4);

    /** AOSP cell → dp formula; launchers differ, so designs are always laid out from the *actual* size. */
    val wDp: Float get() = 70f * cw - 30f
    val hDp: Float get() = 70f * ch - 30f
}

enum class IconKind {
    HOME, GRID, HEART, HEART_O, WIDGET, GEAR, SEARCH, PLUS, CHECK, CLOSE, PLAY, PAUSE, NEXT, PREV,
    BOLT, BATTERY, CLOCK, DIAL, RADAR, SUN, MOON, CLOUD, MUSIC, CALENDAR, TIMER, CHIP, STORAGE,
    DOT, DIAMOND, NOTE, WIFI, BACK, SPARKLE, TRASH, EDIT, CHEVRON, EMPTY_BOX
}

enum class Category(val title: String, val icon: IconKind) {
    DIGITAL("Digital Clocks", IconKind.CLOCK),
    ANALOG("Analog Clocks", IconKind.DIAL),
    HUD("Futuristic HUD", IconKind.RADAR),
    WEATHER("Weather", IconKind.SUN),
    BATTERY("Battery", IconKind.BATTERY),
    MUSIC("Music Player", IconKind.MUSIC),
    CALENDAR("Calendar", IconKind.CALENDAR),
    PRODUCTIVITY("Productivity", IconKind.CHECK),
    COUNTDOWN("Countdown", IconKind.TIMER),
    SYSTEM("System Info", IconKind.CHIP),
    SHORTCUTS("App Shortcuts", IconKind.GRID),
    MINIMAL("Minimalist", IconKind.DOT),
    GLASS("Glass", IconKind.DIAMOND),
    NEON("Neon", IconKind.BOLT)
}

enum class FontKey(val label: String, val family: String) {
    SANS("Sans", "sans-serif"),
    LIGHT("Light", "sans-serif-light"),
    THIN("Thin", "sans-serif-thin"),
    MEDIUM("Medium", "sans-serif-medium"),
    BLACK("Black", "sans-serif-black"),
    CONDENSED("Condensed", "sans-serif-condensed"),
    SERIF("Serif", "serif"),
    MONO("Mono", "monospace")
}

enum class TextMode(val label: String) { AUTO("Auto"), LIGHT("Light"), DARK("Dark"), ACCENT("Accent") }
enum class IconStyle(val label: String) { ROUNDED("Rounded"), CIRCLE("Circle"), SQUARE("Square"), PLAIN("Plain") }

enum class Effect(val label: String, val hint: String) {
    GLASS("Glassmorphism", "Frosted gradient, gloss and rim light"),
    NEON("Neon rim", "Glowing accent outline"),
    LIGHT("Gradient light", "Accent light washing in from the top"),
    HUD("HUD details", "Corner brackets and tick marks"),
    PULSE("Pulse halo", "Breathing glow. Animated in Live Preview / wallpaper; static on the home screen")
}

/** What data a design reads. Also decides which system events / background jobs refresh it. */
enum class Need { BATTERY, SYSTEM, WEATHER, TASKS, MEDIA, AGENDA, APPS, DATE, PERIODIC }

/** Everything a user can customise for ONE widget instance. Serialised to JSON in DataStore. */
data class WidgetConfig(
    val designId: String,
    val size: WSize,
    val bg: Int = 0xFF0B0F1A.toInt(),
    val bg2: Int = 0xFF1B2440.toInt(),
    val gradient: Boolean = true,
    val gradientAngle: Int = 135,
    val alpha: Float = 0.88f,
    val radius: Float = 28f,
    val glow: Float = 0.5f,
    val accent: Int = 0xFF4DE1FF.toInt(),
    val font: FontKey = FontKey.LIGHT,
    val fontScale: Float = 1f,
    val textMode: TextMode = TextMode.AUTO,
    val iconStyle: IconStyle = IconStyle.ROUNDED,
    val layout: Int = 0,
    val effects: Set<Effect> = setOf(Effect.GLASS),
    val extras: Map<String, String> = emptyMap()
) {
    fun flag(key: String, def: Boolean): Boolean = extras[key]?.let { it == "1" } ?: def
    fun str(key: String, def: String = ""): String = extras[key] ?: def
    fun idx(key: String, def: Int = 0): Int = extras[key]?.toIntOrNull() ?: def
    fun with(key: String, value: String): WidgetConfig = copy(extras = extras + (key to value))
    fun withFlag(key: String, v: Boolean): WidgetConfig = with(key, if (v) "1" else "0")
    fun has(e: Effect) = e in effects

    fun toJson(): JSONObject = JSONObject().apply {
        put("design", designId); put("size", size.name)
        put("bg", bg); put("bg2", bg2); put("gradient", gradient); put("angle", gradientAngle)
        put("alpha", alpha.toDouble()); put("radius", radius.toDouble()); put("glow", glow.toDouble())
        put("accent", accent); put("font", font.name); put("fontScale", fontScale.toDouble())
        put("textMode", textMode.name); put("iconStyle", iconStyle.name); put("layout", layout)
        put("effects", JSONArray(effects.map { it.name }))
        put("extras", JSONObject(extras as Map<*, *>))
    }

    companion object {
        fun fromJson(o: JSONObject): WidgetConfig {
            val d = WidgetConfig("", WSize.MEDIUM)
            val fx = o.optJSONArray("effects")
            val effects = if (fx == null) d.effects else
                (0 until fx.length()).mapNotNull { runCatching { Effect.valueOf(fx.getString(it)) }.getOrNull() }.toSet()
            val ex = o.optJSONObject("extras")
            val extras = HashMap<String, String>()
            ex?.keys()?.forEach { k -> extras[k] = ex.optString(k) }
            return WidgetConfig(
                designId = o.optString("design"),
                size = runCatching { WSize.valueOf(o.optString("size")) }.getOrDefault(WSize.MEDIUM),
                bg = o.optInt("bg", d.bg), bg2 = o.optInt("bg2", d.bg2),
                gradient = o.optBoolean("gradient", d.gradient), gradientAngle = o.optInt("angle", d.gradientAngle),
                alpha = o.optDouble("alpha", d.alpha.toDouble()).toFloat(),
                radius = o.optDouble("radius", d.radius.toDouble()).toFloat(),
                glow = o.optDouble("glow", d.glow.toDouble()).toFloat(),
                accent = o.optInt("accent", d.accent),
                font = runCatching { FontKey.valueOf(o.optString("font")) }.getOrDefault(d.font),
                fontScale = o.optDouble("fontScale", 1.0).toFloat(),
                textMode = runCatching { TextMode.valueOf(o.optString("textMode")) }.getOrDefault(d.textMode),
                iconStyle = runCatching { IconStyle.valueOf(o.optString("iconStyle")) }.getOrDefault(d.iconStyle),
                layout = o.optInt("layout", 0), effects = effects, extras = extras
            )
        }
        fun parse(s: String): WidgetConfig? = runCatching { fromJson(JSONObject(s)) }.getOrNull()
    }
}

/** A saved, named customisation the user can re-apply to any new widget. */
data class Preset(val name: String, val config: WidgetConfig)

data class TaskItem(val id: String, val text: String, val done: Boolean)
data class MediaInfo(val title: String, val artist: String, val playing: Boolean, val pkg: String)
data class DayForecast(val code: Int, val maxC: Float, val minC: Float, val dow: Int)
data class Weather(
    val city: String, val tempC: Float, val feelsC: Float, val code: Int, val isDay: Boolean,
    val days: List<DayForecast>, val sunriseMs: Long, val sunsetMs: Long, val fetchedAt: Long,
    val tzOffsetSec: Int = 0
)
data class AgendaItem(val title: String, val begin: Long, val end: Long, val allDay: Boolean, val color: Int)

/** A snapshot of everything a design may display. Built once per widget refresh. */
class Data(
    val nowMs: Long = System.currentTimeMillis(),
    val battery: Int = 0, val charging: Boolean = false, val batteryTempC: Float = 0f,
    val ramPct: Int = 0, val ramUsedGb: Float = 0f, val ramTotalGb: Float = 0f,
    val storagePct: Int = 0, val storageUsedGb: Float = 0f, val storageTotalGb: Float = 0f,
    val uptimeMs: Long = 0L, val net: String = "—",
    val weather: Weather? = null, val weatherIsSample: Boolean = false, val fahrenheit: Boolean = false,
    val tasks: List<TaskItem> = emptyList(),
    val media: MediaInfo? = null, val mediaAccess: Boolean = false,
    val agenda: List<AgendaItem> = emptyList(), val calendarPerm: Boolean = false,
    val icons: Map<String, android.graphics.Bitmap> = emptyMap(),
    val labels: Map<String, String> = emptyMap()
)
