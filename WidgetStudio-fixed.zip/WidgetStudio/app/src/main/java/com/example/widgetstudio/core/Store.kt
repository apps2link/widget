package com.example.widgetstudio.core

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.ds: DataStore<Preferences> by preferencesDataStore(name = "widget_studio")

data class Settings(
    /** 0 = battery saver, 1 = balanced, 2 = frequent. Scales WorkManager periods. */
    val updateMode: Int = 1,
    val fahrenheit: Boolean = false,
    val reducedMotion: Boolean = false
)

/** Last widget pinned through the launcher callback (for in-app confirmation). */
data class PinEvent(val appWidgetId: Int, val at: Long)

/**
 * Single persistence entry point. One JSON document per widget instance (`cfg_<appWidgetId>`),
 * so two widgets with the same design can have different colours, sizes and settings.
 */
object Store {
    private const val CFG = "cfg_"
    private const val PENDING_TTL = 30 * 60 * 1000L

    private val K_FAV = stringSetPreferencesKey("favorites")
    private val K_RECENT = stringPreferencesKey("recents")
    private val K_PRESETS = stringPreferencesKey("presets")
    private val K_UPDATE = intPreferencesKey("update_mode")
    private val K_F = booleanPreferencesKey("fahrenheit")
    private val K_RM = booleanPreferencesKey("reduced_motion")
    private val K_TASKS = stringPreferencesKey("tasks")
    private val K_MEDIA = stringPreferencesKey("media")
    private val K_PIN_ID = intPreferencesKey("pin_id")
    private val K_PIN_AT = longPreferencesKey("pin_at")

    private fun cfgKey(id: Int) = stringPreferencesKey("$CFG$id")
    private fun pendingKey(size: WSize) = stringPreferencesKey("pending_${size.name}")
    private fun weatherKey(city: String) = stringPreferencesKey("weather_${city.trim().lowercase().hashCode()}")

    // ---- widget instance configs -------------------------------------------------------------
    suspend fun config(ctx: Context, id: Int): WidgetConfig? =
        ctx.ds.data.first()[cfgKey(id)]?.let { WidgetConfig.parse(it) }

    suspend fun saveConfig(ctx: Context, id: Int, cfg: WidgetConfig) {
        ctx.ds.edit { it[cfgKey(id)] = cfg.toJson().toString() }
    }

    suspend fun deleteConfig(ctx: Context, id: Int) { ctx.ds.edit { it.remove(cfgKey(id)) } }

    private fun Preferences.configs(): Map<Int, WidgetConfig> {
        val out = HashMap<Int, WidgetConfig>()
        for ((k, v) in asMap()) {
            if (k.name.startsWith(CFG) && v is String) {
                val id = k.name.removePrefix(CFG).toIntOrNull() ?: continue
                WidgetConfig.parse(v)?.let { out[id] = it }
            }
        }
        return out
    }

    suspend fun allConfigs(ctx: Context): Map<Int, WidgetConfig> = ctx.ds.data.first().configs()
    fun configsFlow(ctx: Context): Flow<Map<Int, WidgetConfig>> = ctx.ds.data.map { it.configs() }

    // ---- pending config: preserves the user's design across the pin / picker hand-off ---------
    suspend fun setPending(ctx: Context, cfg: WidgetConfig) {
        val o = JSONObject().put("at", System.currentTimeMillis()).put("cfg", cfg.toJson())
        ctx.ds.edit { it[pendingKey(cfg.size)] = o.toString() }
    }

    /** Atomically claims the pending config for [size] (if fresh) and binds it to [id]. */
    suspend fun claimPending(ctx: Context, size: WSize, id: Int): WidgetConfig? {
        var claimed: WidgetConfig? = null
        ctx.ds.edit { p ->
            val raw = p[pendingKey(size)] ?: return@edit
            val o = runCatching { JSONObject(raw) }.getOrNull()
            val fresh = o != null && System.currentTimeMillis() - o.optLong("at") < PENDING_TTL
            val cfg = if (fresh) o?.optJSONObject("cfg")?.let { WidgetConfig.fromJson(it) } else null
            p.remove(pendingKey(size))
            if (cfg != null) { p[cfgKey(id)] = cfg.toJson().toString(); claimed = cfg }
        }
        return claimed
    }

    suspend fun hasPending(ctx: Context, size: WSize): Boolean {
        val raw = ctx.ds.data.first()[pendingKey(size)] ?: return false
        return runCatching { System.currentTimeMillis() - JSONObject(raw).optLong("at") < PENDING_TTL }.getOrDefault(false)
    }

    // ---- favourites / recents / presets -------------------------------------------------------
    fun favorites(ctx: Context): Flow<Set<String>> = ctx.ds.data.map { it[K_FAV] ?: emptySet() }
    suspend fun toggleFavorite(ctx: Context, designId: String) {
        ctx.ds.edit { val s = (it[K_FAV] ?: emptySet()).toMutableSet(); if (!s.add(designId)) s.remove(designId); it[K_FAV] = s }
    }

    fun recents(ctx: Context): Flow<List<String>> = ctx.ds.data.map { p -> p[K_RECENT]?.split(",")?.filter { it.isNotBlank() } ?: emptyList() }
    suspend fun pushRecent(ctx: Context, designId: String) {
        ctx.ds.edit { p ->
            val cur = p[K_RECENT]?.split(",")?.filter { it.isNotBlank() && it != designId } ?: emptyList()
            p[K_RECENT] = (listOf(designId) + cur).take(10).joinToString(",")
        }
    }

    fun presets(ctx: Context): Flow<List<Preset>> = ctx.ds.data.map { parsePresets(it[K_PRESETS]) }
    private fun parsePresets(raw: String?): List<Preset> {
        if (raw == null) return emptyList()
        return runCatching {
            val a = JSONArray(raw)
            (0 until a.length()).mapNotNull { i ->
                val o = a.getJSONObject(i)
                Preset(o.getString("name"), WidgetConfig.fromJson(o.getJSONObject("cfg")))
            }
        }.getOrDefault(emptyList())
    }
    private fun List<Preset>.toJson(): String =
        JSONArray(map { JSONObject().put("name", it.name).put("cfg", it.config.toJson()) }).toString()

    suspend fun savePreset(ctx: Context, p: Preset) {
        ctx.ds.edit { it[K_PRESETS] = (parsePresets(it[K_PRESETS]).filter { x -> x.name != p.name } + p).toJson() }
    }
    suspend fun deletePreset(ctx: Context, name: String) {
        ctx.ds.edit { it[K_PRESETS] = parsePresets(it[K_PRESETS]).filter { x -> x.name != name }.toJson() }
    }

    // ---- settings ------------------------------------------------------------------------------
    fun settings(ctx: Context): Flow<Settings> =
        ctx.ds.data.map { Settings(it[K_UPDATE] ?: 1, it[K_F] ?: false, it[K_RM] ?: false) }
    suspend fun getSettings(ctx: Context): Settings = settings(ctx).first()
    suspend fun setUpdateMode(ctx: Context, v: Int) { ctx.ds.edit { it[K_UPDATE] = v } }
    suspend fun setFahrenheit(ctx: Context, v: Boolean) { ctx.ds.edit { it[K_F] = v } }
    suspend fun setReducedMotion(ctx: Context, v: Boolean) { ctx.ds.edit { it[K_RM] = v } }

    // ---- tasks ---------------------------------------------------------------------------------
    fun tasks(ctx: Context): Flow<List<TaskItem>> = ctx.ds.data.map { parseTasks(it[K_TASKS]) }
    private fun parseTasks(raw: String?): List<TaskItem> {
        if (raw == null) return emptyList()
        return runCatching {
            val a = JSONArray(raw)
            (0 until a.length()).map { i -> a.getJSONObject(i).let { TaskItem(it.getString("id"), it.getString("t"), it.optBoolean("d")) } }
        }.getOrDefault(emptyList())
    }
    suspend fun setTasks(ctx: Context, list: List<TaskItem>) {
        val a = JSONArray(list.map { JSONObject().put("id", it.id).put("t", it.text).put("d", it.done) })
        ctx.ds.edit { it[K_TASKS] = a.toString() }
    }
    suspend fun toggleTask(ctx: Context, id: String) {
        val cur = tasks(ctx).first()
        setTasks(ctx, cur.map { if (it.id == id) it.copy(done = !it.done) else it })
    }

    // ---- media (written by MediaListenerService) --------------------------------------------------
    fun media(ctx: Context): Flow<MediaInfo?> = ctx.ds.data.map { p ->
        p[K_MEDIA]?.let { raw -> runCatching { JSONObject(raw).let { MediaInfo(it.getString("t"), it.optString("a"), it.optBoolean("p"), it.optString("k")) } }.getOrNull() }
    }
    suspend fun setMedia(ctx: Context, m: MediaInfo?) {
        ctx.ds.edit {
            if (m == null) it.remove(K_MEDIA)
            else it[K_MEDIA] = JSONObject().put("t", m.title).put("a", m.artist).put("p", m.playing).put("k", m.pkg).toString()
        }
    }

    // ---- weather cache ---------------------------------------------------------------------------
    suspend fun weather(ctx: Context, city: String): Weather? =
        ctx.ds.data.first()[weatherKey(city)]?.let { raw ->
            runCatching {
                val o = JSONObject(raw)
                val d = o.getJSONArray("days")
                Weather(
                    o.getString("city"), o.getDouble("t").toFloat(), o.getDouble("f").toFloat(), o.getInt("c"), o.getBoolean("day"),
                    (0 until d.length()).map { i -> d.getJSONObject(i).let { DayForecast(it.getInt("c"), it.getDouble("x").toFloat(), it.getDouble("n").toFloat(), it.getInt("w")) } },
                    o.getLong("sr"), o.getLong("ss"), o.getLong("at"), o.optInt("z", 0)
                )
            }.getOrNull()
        }

    suspend fun setWeather(ctx: Context, key: String, w: Weather) {
        val days = JSONArray(w.days.map { JSONObject().put("c", it.code).put("x", it.maxC.toDouble()).put("n", it.minC.toDouble()).put("w", it.dow) })
        val o = JSONObject().put("city", w.city).put("t", w.tempC.toDouble()).put("f", w.feelsC.toDouble()).put("c", w.code)
            .put("day", w.isDay).put("days", days).put("sr", w.sunriseMs).put("ss", w.sunsetMs).put("at", w.fetchedAt).put("z", w.tzOffsetSec)
        ctx.ds.edit { it[weatherKey(key)] = o.toString() }
    }

    // ---- pin confirmation ---------------------------------------------------------------------------
    suspend fun setPinned(ctx: Context, id: Int) { ctx.ds.edit { it[K_PIN_ID] = id; it[K_PIN_AT] = System.currentTimeMillis() } }
    fun pinned(ctx: Context): Flow<PinEvent?> = ctx.ds.data.map { p ->
        val id = p[K_PIN_ID]; val at = p[K_PIN_AT]
        if (id != null && at != null) PinEvent(id, at) else null
    }
}
