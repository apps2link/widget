package com.example.widgetstudio.data

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import android.os.SystemClock
import android.provider.CalendarContract
import android.util.LruCache
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import com.example.widgetstudio.core.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import android.graphics.Bitmap
import android.Manifest

/** Builds the [Data] snapshot a design needs. Only reads what the design declared in `needs`. */
object DataProvider {
    private val iconCache = LruCache<String, Bitmap>(24)

    suspend fun load(ctx: Context, needs: Set<Need>, cfg: WidgetConfig): Data = withContext(Dispatchers.IO) {
        val app = ctx.applicationContext
        val settings = Store.getSettings(app)
        var d = Data(nowMs = System.currentTimeMillis(), fahrenheit = settings.fahrenheit)
        if (Need.BATTERY in needs) d = withBattery(app, d)
        if (Need.SYSTEM in needs) d = withSystem(app, d)
        val weather = if (Need.WEATHER in needs) cfg.str("city").takeIf { it.isNotBlank() }?.let { Store.weather(app, it) } else null
        val tasks = if (Need.TASKS in needs) Store.tasks(app).first() else emptyList()
        val media = if (Need.MEDIA in needs) Store.media(app).first() else null
        val access = Need.MEDIA in needs && mediaAccessEnabled(app)
        val perm = Need.AGENDA in needs && hasCalendar(app)
        val agenda = if (perm) agenda(app) else emptyList()
        val pkgs = if (Need.APPS in needs) cfg.str("apps").split(",").filter { it.isNotBlank() } else emptyList()
        val icons = HashMap<String, Bitmap>(); val labels = HashMap<String, String>()
        for (p in pkgs) { appIcon(app, p)?.let { icons[p] = it }; appLabel(app, p)?.let { labels[p] = it } }
        Data(
            nowMs = d.nowMs, battery = d.battery, charging = d.charging, batteryTempC = d.batteryTempC,
            ramPct = d.ramPct, ramUsedGb = d.ramUsedGb, ramTotalGb = d.ramTotalGb,
            storagePct = d.storagePct, storageUsedGb = d.storageUsedGb, storageTotalGb = d.storageTotalGb,
            uptimeMs = d.uptimeMs, net = d.net, weather = weather, fahrenheit = d.fahrenheit,
            tasks = tasks, media = media, mediaAccess = access, agenda = agenda, calendarPerm = perm,
            icons = icons, labels = labels
        )
    }

    /** Preview data: real device values where cheap and safe, labelled sample data where a real value needs setup. */
    suspend fun forPreview(ctx: Context, cfg: WidgetConfig): Data {
        val design = com.example.widgetstudio.designs.Registry.get(cfg.designId)
        val real = load(ctx, design?.needs ?: emptySet(), cfg)
        val sample = sample(real.nowMs)
        return Data(
            nowMs = real.nowMs, battery = real.battery, charging = real.charging, batteryTempC = real.batteryTempC,
            ramPct = real.ramPct, ramUsedGb = real.ramUsedGb, ramTotalGb = real.ramTotalGb,
            storagePct = real.storagePct, storageUsedGb = real.storageUsedGb, storageTotalGb = real.storageTotalGb,
            uptimeMs = real.uptimeMs, net = real.net,
            weather = real.weather ?: sample.weather, weatherIsSample = real.weather == null, fahrenheit = real.fahrenheit,
            tasks = real.tasks.ifEmpty { sample.tasks }, media = real.media ?: sample.media, mediaAccess = real.mediaAccess,
            agenda = real.agenda.ifEmpty { if (real.calendarPerm) emptyList() else sample.agenda }, calendarPerm = true,
            icons = real.icons, labels = real.labels
        )
    }

    fun sample(now: Long = System.currentTimeMillis()): Data {
        val dayMs = 86_400_000L
        val z = java.time.ZoneId.systemDefault()
        val today = java.time.Instant.ofEpochMilli(now).atZone(z).toLocalDate()
        return Data(
            nowMs = now, battery = 76, charging = false, batteryTempC = 31f,
            ramPct = 58, ramUsedGb = 4.6f, ramTotalGb = 8f, storagePct = 64, storageUsedGb = 82f, storageTotalGb = 128f,
            uptimeMs = 3 * dayMs + 5 * 3_600_000L, net = "Wi-Fi",
            weather = Weather("Sample City", 21f, 20f, 2, true,
                (0 until 5).map { DayForecast(intArrayOf(2, 0, 61, 3, 95)[it], 23f + it, 14f + it, today.plusDays(it.toLong()).dayOfWeek.value) },
                now - 4 * 3_600_000L, now + 5 * 3_600_000L, now, java.time.ZoneId.systemDefault().rules.getOffset(java.time.Instant.ofEpochMilli(now)).totalSeconds),
            weatherIsSample = true,
            tasks = listOf(TaskItem("s1", "Review pull requests", true), TaskItem("s2", "Book dentist", false), TaskItem("s3", "Plan weekend trip", false)),
            media = MediaInfo("Midnight City", "M83", true, ""), mediaAccess = true,
            agenda = listOf(AgendaItem("Team stand-up", now + 3_600_000L, now + 5_400_000L, false, 0xFF4DE1FF.toInt()), AgendaItem("Lunch with Sam", now + 4 * 3_600_000L, now + 6 * 3_600_000L, false, 0xFFFFC857.toInt())),
            calendarPerm = true
        )
    }

    private fun withBattery(ctx: Context, d: Data): Data {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else 0
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        val temp = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        return Data(nowMs = d.nowMs, battery = pct, charging = charging, batteryTempC = temp, fahrenheit = d.fahrenheit)
    }

    private fun withSystem(ctx: Context, d: Data): Data {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val gb = 1024f * 1024f * 1024f
        val total = mi.totalMem.toFloat(); val used = (mi.totalMem - mi.availMem).toFloat()
        val st = StatFs(Environment.getDataDirectory().path)
        val sTotal = st.totalBytes.toFloat(); val sUsed = (st.totalBytes - st.availableBytes).toFloat()
        val net = runCatching {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            when {
                caps == null -> "Offline"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
                else -> "Online"
            }
        }.getOrDefault("—")
        return Data(
            nowMs = d.nowMs, battery = d.battery, charging = d.charging, batteryTempC = d.batteryTempC,
            ramPct = (used * 100 / total).toInt(), ramUsedGb = used / gb, ramTotalGb = total / gb,
            storagePct = if (sTotal > 0) (sUsed * 100 / sTotal).toInt() else 0, storageUsedGb = sUsed / gb, storageTotalGb = sTotal / gb,
            uptimeMs = SystemClock.elapsedRealtime(), net = net, fahrenheit = d.fahrenheit
        )
    }

    fun mediaAccessEnabled(ctx: Context): Boolean = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)

    fun hasCalendar(ctx: Context): Boolean =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED

    private fun agenda(ctx: Context): List<AgendaItem> = runCatching {
        val now = System.currentTimeMillis()
        val b = CalendarContract.Instances.CONTENT_URI.buildUpon()
        android.content.ContentUris.appendId(b, now)
        android.content.ContentUris.appendId(b, now + 7L * 86_400_000L)
        val out = ArrayList<AgendaItem>()
        ctx.contentResolver.query(
            b.build(),
            arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN, CalendarContract.Instances.END, CalendarContract.Instances.ALL_DAY, CalendarContract.Instances.DISPLAY_COLOR),
            null, null, "${CalendarContract.Instances.BEGIN} ASC"
        )?.use { c ->
            while (c.moveToNext() && out.size < 8) {
                out.add(AgendaItem(c.getString(0) ?: "(no title)", c.getLong(1), c.getLong(2), c.getInt(3) == 1, c.getInt(4)))
            }
        }
        out
    }.getOrDefault(emptyList())

    fun appIcon(ctx: Context, pkg: String): Bitmap? {
        iconCache.get(pkg)?.let { return it }
        return runCatching { ctx.packageManager.getApplicationIcon(pkg).toBitmap(96, 96) }.getOrNull()?.also { iconCache.put(pkg, it) }
    }

    fun appLabel(ctx: Context, pkg: String): String? = runCatching {
        ctx.packageManager.getApplicationLabel(ctx.packageManager.getApplicationInfo(pkg, 0)).toString()
    }.getOrNull()

    data class LaunchableApp(val pkg: String, val label: String)

    /** Launchable apps for the app-shortcut picker (needs the <queries> LAUNCHER entry in the manifest). */
    fun launchableApps(ctx: Context): List<LaunchableApp> {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0)
            .map { LaunchableApp(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
            .filter { it.pkg != ctx.packageName }.distinctBy { it.pkg }.sortedBy { it.label.lowercase() }
    }
}
