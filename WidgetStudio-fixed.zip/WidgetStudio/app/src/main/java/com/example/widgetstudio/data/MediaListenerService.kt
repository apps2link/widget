package com.example.widgetstudio.data

import android.content.ComponentName
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.service.notification.NotificationListenerService
import com.example.widgetstudio.core.MediaInfo
import com.example.widgetstudio.core.Need
import com.example.widgetstudio.core.Store
import com.example.widgetstudio.widgets.Updater
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Event-driven now-playing source (no polling). Only runs if the user enables notification access;
 * music widgets show a "tap to enable" hint otherwise, and their transport buttons still work.
 */
class MediaListenerService : NotificationListenerService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var pending: Job? = null
    private var msm: MediaSessionManager? = null
    private val controllers = ArrayList<MediaController>()
    private val ctlCallback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = publish()
        override fun onPlaybackStateChanged(state: PlaybackState?) = publish()
    }
    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { list -> attach(list ?: emptyList()) }

    override fun onListenerConnected() {
        super.onListenerConnected()
        val cn = ComponentName(this, MediaListenerService::class.java)
        msm = getSystemService(MediaSessionManager::class.java)
        runCatching {
            msm?.addOnActiveSessionsChangedListener(sessionsListener, cn)
            attach(msm?.getActiveSessions(cn) ?: emptyList())
        }
    }

    override fun onListenerDisconnected() {
        detach(); runCatching { msm?.removeOnActiveSessionsChangedListener(sessionsListener) }
        super.onListenerDisconnected()
    }

    private fun attach(list: List<MediaController>) {
        detach()
        list.forEach { it.registerCallback(ctlCallback); controllers.add(it) }
        publish()
    }

    private fun detach() { controllers.forEach { runCatching { it.unregisterCallback(ctlCallback) } }; controllers.clear() }

    private fun publish() {
        pending?.cancel()
        pending = scope.launch {
            delay(1200) // debounce bursts of metadata/state callbacks
            val c = controllers.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: controllers.firstOrNull()
            val title = c?.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)
            val info = if (c == null || title.isNullOrBlank()) null else MediaInfo(
                title, c.metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: "",
                c.playbackState?.state == PlaybackState.STATE_PLAYING, c.packageName
            )
            Store.setMedia(applicationContext, info)
            Updater.refreshNeeding(applicationContext, setOf(Need.MEDIA))
        }
    }

    override fun onDestroy() { scope.cancel(); super.onDestroy() }
}
