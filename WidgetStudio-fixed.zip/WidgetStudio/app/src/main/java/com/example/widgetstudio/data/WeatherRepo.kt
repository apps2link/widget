package com.example.widgetstudio.data

import android.content.Context
import com.example.widgetstudio.core.DayForecast
import com.example.widgetstudio.core.Store
import com.example.widgetstudio.core.Weather
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneOffset

/** Keyless Open-Meteo client. The user types a city, so no location permission is ever needed. */
object WeatherRepo {
    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10_000; c.readTimeout = 10_000
        try {
            if (c.responseCode !in 200..299) error("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally { c.disconnect() }
    }

    /** Fetches and caches weather for [city]. Returns null on any failure (the cached value stays in place). */
    suspend fun refresh(ctx: Context, city: String): Weather? = withContext(Dispatchers.IO) {
        runCatching {
            val geo = JSONObject(get("https://geocoding-api.open-meteo.com/v1/search?count=1&name=${URLEncoder.encode(city.trim(), "UTF-8")}"))
            val hit = geo.optJSONArray("results")?.optJSONObject(0) ?: return@runCatching null
            val lat = hit.getDouble("latitude"); val lon = hit.getDouble("longitude")
            val name = hit.optString("name", city)
            val f = JSONObject(get(
                "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                    "&current=temperature_2m,apparent_temperature,weather_code,is_day" +
                    "&daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset&timezone=auto&forecast_days=5"
            ))
            val cur = f.getJSONObject("current"); val daily = f.getJSONObject("daily")
            val tz = f.optInt("utc_offset_seconds", 0)
            val times = daily.getJSONArray("time"); val codes = daily.getJSONArray("weather_code")
            val mx = daily.getJSONArray("temperature_2m_max"); val mn = daily.getJSONArray("temperature_2m_min")
            val days = (0 until times.length()).map { i ->
                DayForecast(codes.getInt(i), mx.getDouble(i).toFloat(), mn.getDouble(i).toFloat(), LocalDate.parse(times.getString(i)).dayOfWeek.value)
            }
            fun epoch(s: String) = LocalDateTime.parse(s).toEpochSecond(ZoneOffset.ofTotalSeconds(tz)) * 1000L
            val w = Weather(
                name, cur.getDouble("temperature_2m").toFloat(), cur.getDouble("apparent_temperature").toFloat(), cur.getInt("weather_code"),
                cur.getInt("is_day") == 1, days, epoch(daily.getJSONArray("sunrise").getString(0)), epoch(daily.getJSONArray("sunset").getString(0)),
                System.currentTimeMillis(), tz
            )
            Store.setWeather(ctx.applicationContext, city, w)
            w
        }.getOrNull()
    }
}
