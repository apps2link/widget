package com.example.widgetstudio.designs

import com.example.widgetstudio.core.Category
import com.example.widgetstudio.core.Data
import com.example.widgetstudio.core.Effect
import com.example.widgetstudio.core.FontKey
import com.example.widgetstudio.core.Need
import com.example.widgetstudio.core.WSize
import com.example.widgetstudio.core.WidgetConfig
import com.example.widgetstudio.core.fg
import com.example.widgetstudio.core.lerpColor
import com.example.widgetstudio.core.toHsv
import com.example.widgetstudio.core.hsv
import com.example.widgetstudio.core.withAlpha
import com.example.widgetstudio.render.A
import com.example.widgetstudio.render.Act
import com.example.widgetstudio.render.BgPainter
import com.example.widgetstudio.render.BoxN
import com.example.widgetstudio.render.ClockN
import com.example.widgetstudio.render.GfxN
import com.example.widgetstudio.render.IconPainter
import com.example.widgetstudio.render.M
import com.example.widgetstudio.render.N
import com.example.widgetstudio.render.TextN
import com.example.widgetstudio.render.bgStyle
import com.example.widgetstudio.render.gfx
import com.example.widgetstudio.core.IconKind
import kotlin.math.min
import kotlin.math.roundToInt

/** Customisation fields a design exposes in the editor's "Data" tab. Values live in WidgetConfig.extras. */
sealed class Field(val key: String, val label: String) {
    class Toggle(key: String, label: String, val def: Boolean = true) : Field(key, label)
    class Str(key: String, label: String, val hint: String = "", val def: String = "", val multiline: Boolean = false) : Field(key, label)
    /** ISO date; default = today + [offsetDays]. */
    class DateF(key: String, label: String, val offsetDays: Int = 0) : Field(key, label)
    class Apps(key: String, label: String, val max: Int) : Field(key, label)
    class Choice(key: String, label: String, val options: List<String>, val def: Int = 0) : Field(key, label)
    /** kind: "tasks" | "media" | "calendar" | "weather" — specialised editor rows. */
    class Special(key: String, label: String, val kind: String) : Field(key, label)
}

class Design(
    val id: String,
    val name: String,
    val tag: String,
    val cat: Category,
    val sizes: List<WSize>,
    val needs: Set<Need> = emptySet(),
    val layouts: List<String> = emptyList(),
    val fields: List<Field> = emptyList(),
    val effects: List<Effect> = Effect.entries.toList(),
    val featured: Boolean = false,
    val preset: (WidgetConfig) -> WidgetConfig = { it },
    val build: (Ctx) -> N
) {
    fun node(cfg: WidgetConfig, w: Float, h: Float, data: Data): N = build(Ctx(cfg, w, h, data))
}

/** Everything a design needs to lay itself out at the *actual* widget size. */
class Ctx(val cfg: WidgetConfig, val w: Float, val h: Float, val data: Data) {
    val fg: Int = cfg.fg()
    val acc: Int = cfg.accent
    val acc2: Int = toHsv(cfg.accent).let { hsv((it[0] + 38f) % 360f, it[1], it[2]) }
    val track: Int = fg.withAlpha(0.14f)
    val size: WSize get() = cfg.size
    val h24: Boolean get() = cfg.flag("h24", false)
    val tf: String get() = if (h24) "HH:mm" else "h:mm"

    /** Uniform scale factor relative to a reference widget box. */
    fun k(rw: Float, rh: Float): Float = min(w / rw, h / rh).coerceIn(0.55f, 2.4f)

    fun T(text: String, sp: Float, a: Float = 1f, font: FontKey = cfg.font, lines: Int = 1, color: Int = fg, m: M = M()): N =
        TextN(text, sp * cfg.fontScale, if (a >= 1f) color else color.withAlpha(a), font, lines, m)

    fun C(fmt: String, sp: Float, a: Float = 1f, font: FontKey = cfg.font, color: Int = fg, m: M = M()): N =
        ClockN(fmt, sp * cfg.fontScale, if (a >= 1f) color else color.withAlpha(a), font, m)

    fun bg(): N = GfxN(BgPainter(cfg.bgStyle()), null, M.Fill)

    /** Widget root: background layer + padded content layer. */
    fun root(act: Act?, pad: Float, vararg k: N): N =
        BoxN(A.C, M.Fill.click(act), listOf(bg(), BoxN(A.C, M.Fill.pad(pad), k.toList())))

    fun icon(kind: IconKind, sizeDp: Float, color: Int = fg, a: Float = 1f): N = gfx(IconPainter(kind, color.withAlpha(a)), sizeDp, sizeDp)

    fun temp(cDeg: Float): String = "${(if (data.fahrenheit) cDeg * 9f / 5f + 32f else cDeg).roundToInt()}°"

    fun battColor(): Int = when {
        data.charging -> 0xFF5CFFB0.toInt()
        data.battery <= 20 -> 0xFFFF5C6C.toInt()
        else -> acc
    }
    fun battColor2(): Int = lerpColor(battColor(), 0xFFFFFFFF.toInt(), 0.3f)
}

fun spacer(): N = BoxN(A.C, M.Weight, emptyList())
