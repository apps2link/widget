package com.example.widgetstudio.designs

import com.example.widgetstudio.core.*
import com.example.widgetstudio.render.*
import kotlin.math.max
import kotlin.math.min

private val BAT_NEEDS = setOf(Need.BATTERY)
private val SYS_NEEDS = setOf(Need.BATTERY, Need.SYSTEM)

private fun uptime(ms: Long): String {
    val m = ms / 60000; val h = m / 60; val d = h / 24
    return if (d > 0) "${d}d ${h % 24}h" else "${h}h ${m % 60}m"
}

private fun batteryStatus(c: Ctx): String = when {
    c.data.charging -> "Charging"
    c.data.battery <= 20 -> "Low battery"
    else -> "On battery"
}

/** Label + value row over a bar. */
private fun stat(c: Ctx, label: String, pct: Int, w: Float, color: Int, segments: Int = 12): N =
    col(
        HA.S, VA.C, M(w = w),
        row(VA.C, HA.S, M(w = w), c.T(label, 9f, 0.7f, FontKey.MONO), spacer(), c.T("$pct%", 9f, 1f, FontKey.MONO)),
        gfx(CellsPainter(pct, segments, color, lerpColor(color, 0xFFFFFFFF.toInt(), 0.3f), c.track, 1.5f, c.cfg.glow * 0.6f), w, 7f, m = M(pt = 2f))
    )

// ================================================================================================ HUD
private val cockpit = Design(
    id = "hud_cockpit", name = "Cockpit Bar", tag = "Clock + live battery, RAM and storage cells", cat = Category.HUD,
    sizes = listOf(WSize.STRIP, WSize.MEDIUM), needs = SYS_NEEDS + Need.PERIODIC, featured = true,
    fields = listOf(Field.Toggle("h24", "24-hour clock", true)),
    preset = { it.copy(font = FontKey.MONO, accent = 0xFF4DE1FF.toInt(), effects = setOf(Effect.HUD, Effect.GLASS), bg = 0xFF050A12.toInt(), bg2 = 0xFF0B1A2B.toInt(), glow = 0.5f) }
) { c ->
    val pad = 10f
    if (c.size == WSize.STRIP) {
        val bw = (c.w - 2 * pad) * 0.22f
        c.root(
            Act.Alarms, pad,
            row(VA.C, HA.S, M.Fill, c.C(c.tf, c.h * 0.5f), spacer(), stat(c, "BAT", c.data.battery, bw, c.battColor(), 8), gap(10f), stat(c, "RAM", c.data.ramPct, bw, c.acc2, 8))
        )
    } else {
        val left = (c.w - 2 * pad) * 0.4f
        val bw = c.w - 2 * pad - left - 14f
        c.root(
            Act.Alarms, pad,
            row(
                VA.C, HA.S, M.Fill,
                col(HA.S, VA.C, M(w = left), c.T("LOCAL TIME", 8f, 0.6f, FontKey.MONO), c.C(c.tf, min(c.h * 0.36f, left * 0.3f)), c.C("EEE d MMM", 11f, 0.75f)),
                gap(14f),
                col(
                    HA.S, VA.C, M(w = bw),
                    stat(c, "BAT", c.data.battery, bw, c.battColor()), gap(h = 6f),
                    stat(c, "RAM", c.data.ramPct, bw, c.acc2), gap(h = 6f),
                    stat(c, "STO", c.data.storagePct, bw, c.acc)
                )
            )
        )
    }
}

private val reactor = Design(
    id = "hud_reactor", name = "Reactor Core", tag = "Concentric gauges around the time", cat = Category.HUD,
    sizes = listOf(WSize.SMALL, WSize.LARGE), needs = SYS_NEEDS + Need.PERIODIC,
    layouts = listOf("Dual ring", "Segmented"), fields = listOf(Field.Toggle("h24", "24-hour clock", true)),
    preset = { it.copy(font = FontKey.CONDENSED, accent = 0xFF7C9CFF.toInt(), effects = setOf(Effect.NEON, Effect.HUD), bg = 0xFF06070F.toInt(), bg2 = 0xFF0F1230.toInt(), glow = 0.6f) }
) { c ->
    val side = if (c.size == WSize.LARGE) min(c.w - 24f, c.h - 70f) else min(c.w, c.h) - 16f
    val seg = if (c.cfg.layout == 1) 24 else 0
    val outer = RingPainter(c.data.battery, c.battColor(), c.battColor2(), side * 0.045f, c.track, c.cfg.glow, seg)
    val inner = RingPainter(c.data.ramPct, c.acc, c.acc2, side * 0.035f, c.track, c.cfg.glow * 0.7f, seg)
    val core = BoxN(
        A.C, M(w = side, h = side),
        listOf(
            gfx(outer, side, side, "Battery ${c.data.battery}%"),
            gfx(inner, side * 0.76f, side * 0.76f, "Memory ${c.data.ramPct}%"),
            col(HA.C, VA.C, M(), c.C(c.tf, side * 0.19f), c.T("BAT ${c.data.battery}%", side * 0.075f, 0.75f, FontKey.MONO))
        )
    )
    c.root(
        Act.Alarms, 8f,
        if (c.size == WSize.LARGE)
            col(HA.C, VA.C, M.Fill, core, gap(h = 8f), row(VA.C, HA.C, M.FillW, c.T("RAM ${c.data.ramPct}%", 11f, 0.8f, FontKey.MONO), gap(14f), c.T("STO ${c.data.storagePct}%", 11f, 0.8f, FontKey.MONO), gap(14f), c.T(if (c.data.charging) "CHARGING" else "ON BATT", 11f, 0.8f, FontKey.MONO)))
        else col(HA.C, VA.C, M.Fill, core)
    )
}

private val hudFrame = Design(
    id = "hud_frame", name = "Sci-Fi Frame", tag = "Terminal readout inside HUD brackets", cat = Category.HUD,
    sizes = listOf(WSize.MEDIUM, WSize.LARGE), needs = SYS_NEEDS + Need.PERIODIC,
    fields = listOf(Field.Toggle("h24", "24-hour clock", true)),
    preset = { it.copy(font = FontKey.MONO, accent = 0xFF5CFFB0.toInt(), effects = setOf(Effect.HUD, Effect.NEON), bg = 0xFF03100B.toInt(), bg2 = 0xFF072016.toInt(), glow = 0.45f, radius = 18f) }
) { c ->
    val line = if (c.size == WSize.LARGE) 12f else 10f
    fun ln(k: String, v: String) = row(VA.C, HA.S, M.FillW, c.T(k, line, 0.55f, FontKey.MONO, m = M(w = 40f)), c.T(v, line, 1f, FontKey.MONO))
    val data = col(
        HA.S, VA.C, M(),
        ln("BAT", "${c.data.battery}%${if (c.data.charging) " +CHG" else ""}"), ln("NET", c.data.net), ln("MEM", "${c.data.ramPct}%  ${"%.1f".format(c.data.ramUsedGb)}G"), ln("STO", "${c.data.storagePct}%"),
        if (c.size == WSize.LARGE) ln("UP", uptime(c.data.uptimeMs)) else gap()
    )
    c.root(
        Act.Alarms, 16f,
        if (c.size == WSize.LARGE)
            col(HA.S, VA.C, M.Fill, c.T("SYS//CLOCK", 10f, 0.7f, color = c.acc), c.C(c.tf, 52f), c.C("EEE dd MMM yyyy", 12f, 0.7f, m = M(pb = 12f)), data)
        else row(VA.C, HA.S, M.Fill, col(HA.S, VA.C, M(), c.T("SYS//CLOCK", 9f, 0.7f, color = c.acc), c.C(c.tf, min(c.h * 0.36f, 40f)), c.C("EEE dd MMM", 10f, 0.7f)), spacer(), data)
    )
}

// ================================================================================================ Battery
private val liquid = Design(
    id = "bt_liquid", name = "Liquid Cell", tag = "Battery as a rising liquid", cat = Category.BATTERY,
    sizes = listOf(WSize.SMALL, WSize.MEDIUM), needs = BAT_NEEDS + Need.PERIODIC, featured = true,
    layouts = listOf("Circle", "Capsule"),
    preset = { it.copy(font = FontKey.MEDIUM, effects = setOf(Effect.GLASS), glow = 0.5f, accent = 0xFF4DE1FF.toInt()) }
) { c ->
    val side = min(c.w, c.h) - 16f
    val shape = if (c.cfg.layout == 1) 1 else 0
    val cw = if (shape == 1) side * 0.72f else side
    val tank = BoxN(
        A.C, M(w = cw, h = side),
        listOf(
            gfx(LiquidPainter(c.data.battery, c.battColor(), c.battColor2(), c.battColor(), c.cfg.glow, shape, 18f), cw, side, "Battery ${c.data.battery}%"),
            col(HA.C, VA.C, M(), c.T("${c.data.battery}", side * 0.3f), if (c.data.charging) c.icon(IconKind.BOLT, side * 0.16f) else gap())
        )
    )
    c.root(
        null, 8f,
        if (c.size == WSize.MEDIUM) row(VA.C, HA.C, M.Fill, tank, gap(16f), col(HA.S, VA.C, M(), c.T(batteryStatus(c), 15f), c.T("${"%.0f".format(c.data.batteryTempC)}°C", 12f, 0.65f)))
        else col(HA.C, VA.C, M.Fill, tank)
    )
}

private val batRing = Design(
    id = "bt_ring", name = "Neon Ring", tag = "Glowing gauge with charge bolt", cat = Category.BATTERY,
    sizes = listOf(WSize.SMALL, WSize.MEDIUM, WSize.LARGE), needs = BAT_NEEDS + Need.PERIODIC,
    layouts = listOf("Smooth", "Segmented"),
    preset = { it.copy(font = FontKey.THIN, effects = setOf(Effect.NEON, Effect.PULSE), glow = 0.7f, bg = 0xFF05060B.toInt(), bg2 = 0xFF0C1022.toInt()) }
) { c ->
    val side = if (c.size == WSize.LARGE) min(c.w, c.h) - 40f else min(c.w, c.h) - 18f
    val ring = RingPainter(c.data.battery, c.battColor(), c.battColor2(), side * 0.075f, c.track, c.cfg.glow, if (c.cfg.layout == 1) 20 else 0)
    val dial = BoxN(A.C, M(w = side, h = side), listOf(gfx(ring, side, side, "Battery ${c.data.battery}%"),
        col(HA.C, VA.C, M(), if (c.data.charging) c.icon(IconKind.BOLT, side * 0.14f, c.battColor()) else gap(), c.T("${c.data.battery}%", side * 0.24f))))
    c.root(null, 8f, if (c.size == WSize.MEDIUM) row(VA.C, HA.C, M.Fill, dial, gap(18f), col(HA.S, VA.C, M(), c.T(batteryStatus(c), 16f), c.T("${"%.0f".format(c.data.batteryTempC)}°C", 12f, 0.6f))) else col(HA.C, VA.C, M.Fill, dial, if (c.size == WSize.LARGE) c.T(batteryStatus(c), 16f, 0.8f, m = M(pt = 10f)) else gap()))
}

private val batBar = Design(
    id = "bt_bar", name = "Cell Bar", tag = "Segmented battery strip", cat = Category.BATTERY,
    sizes = listOf(WSize.STRIP, WSize.MEDIUM), needs = BAT_NEEDS + Need.PERIODIC,
    layouts = listOf("Segmented", "Smooth"),
    preset = { it.copy(font = FontKey.CONDENSED, effects = setOf(Effect.GLASS), glow = 0.4f) }
) { c ->
    val bw = c.w - 32f
    val bar = gfx(CellsPainter(c.data.battery, if (c.cfg.layout == 1) 0 else 20, c.battColor(), c.battColor2(), c.track, 3f, c.cfg.glow), bw, if (c.size == WSize.STRIP) 10f else 16f, "Battery ${c.data.battery}%")
    c.root(
        null, 14f,
        if (c.size == WSize.STRIP) col(HA.S, VA.C, M.Fill, row(VA.C, HA.S, M(w = bw), c.icon(IconKind.BATTERY, 14f, c.battColor()), gap(6f), c.T("${c.data.battery}%", 13f), spacer(), c.T(batteryStatus(c), 11f, 0.65f)), gap(h = 3f), bar)
        else col(HA.S, VA.C, M.Fill, row(VA.C, HA.S, M(w = bw), c.T("${c.data.battery}%", 34f), spacer(), if (c.data.charging) c.icon(IconKind.BOLT, 22f, c.battColor()) else gap()), gap(h = 8f), bar, gap(h = 8f), c.T("${batteryStatus(c)} · ${"%.0f".format(c.data.batteryTempC)}°C", 12f, 0.65f))
    )
}

// ================================================================================================ System
private val gauges = Design(
    id = "sy_gauges", name = "System Gauges", tag = "RAM, storage and battery rings", cat = Category.SYSTEM,
    sizes = listOf(WSize.MEDIUM, WSize.LARGE), needs = SYS_NEEDS + Need.PERIODIC, featured = true,
    preset = { it.copy(font = FontKey.CONDENSED, effects = setOf(Effect.GLASS, Effect.HUD), glow = 0.5f) }
) { c ->
    val side = min((c.w - 32f) / 3f - 8f, c.h - (if (c.size == WSize.LARGE) 90f else 40f))
    fun g(label: String, pct: Int, c1: Int, sub: String): N = col(
        HA.C, VA.C, M(),
        BoxN(A.C, M(w = side, h = side), listOf(gfx(RingPainter(pct, c1, lerpColor(c1, 0xFFFFFFFF.toInt(), 0.35f), side * 0.09f, c.track, c.cfg.glow), side, side, "$label $pct%"), c.T("$pct%", side * 0.26f))),
        c.T(label, 11f, 0.75f, m = M(pt = 4f)),
        if (c.size == WSize.LARGE) c.T(sub, 10f, 0.5f) else gap()
    )
    val rowN = row(VA.C, HA.C, M.FillW, g("RAM", c.data.ramPct, c.acc, "%.1f / %.1f GB".format(c.data.ramUsedGb, c.data.ramTotalGb)), gap(12f),
        g("STORAGE", c.data.storagePct, c.acc2, "%.0f / %.0f GB".format(c.data.storageUsedGb, c.data.storageTotalGb)), gap(12f),
        g("BATTERY", c.data.battery, c.battColor(), batteryStatus(c)))
    c.root(null, 10f, if (c.size == WSize.LARGE) col(HA.C, VA.C, M.Fill, rowN, gap(h = 14f), c.T("Uptime ${uptime(c.data.uptimeMs)}  ·  ${c.data.net}", 12f, 0.65f)) else col(HA.C, VA.C, M.Fill, rowN))
}

private val storage = Design(
    id = "sy_storage", name = "Storage Tank", tag = "Used storage as liquid", cat = Category.SYSTEM,
    sizes = listOf(WSize.SMALL, WSize.MEDIUM), needs = setOf(Need.SYSTEM, Need.PERIODIC),
    preset = { it.copy(font = FontKey.MEDIUM, accent = 0xFF9B6BFF.toInt(), effects = setOf(Effect.GLASS), glow = 0.5f) }
) { c ->
    val side = min(c.w, c.h) - 16f
    val tank = BoxN(A.C, M(w = side, h = side), listOf(
        gfx(LiquidPainter(c.data.storagePct, c.acc, c.acc2, c.acc, c.cfg.glow, 1, 24f), side, side, "Storage ${c.data.storagePct}%"),
        col(HA.C, VA.C, M(), c.T("${c.data.storagePct}%", side * 0.26f), c.T("used", side * 0.1f, 0.7f))))
    c.root(null, 8f, if (c.size == WSize.MEDIUM) row(VA.C, HA.C, M.Fill, tank, gap(16f), col(HA.S, VA.C, M(), c.T("Storage", 16f), c.T("%.0f of %.0f GB".format(c.data.storageUsedGb, c.data.storageTotalGb), 12f, 0.65f))) else col(HA.C, VA.C, M.Fill, tank))
}

private val sysStrip = Design(
    id = "sy_strip", name = "Status Strip", tag = "Uptime, network and memory at a glance", cat = Category.SYSTEM,
    sizes = listOf(WSize.STRIP, WSize.MEDIUM), needs = SYS_NEEDS + Need.PERIODIC,
    preset = { it.copy(font = FontKey.CONDENSED, effects = setOf(Effect.GLASS), glow = 0.35f) }
) { c ->
    val bw = c.w * 0.3f
    c.root(
        null, 12f,
        row(
            VA.C, HA.S, M.Fill,
            c.icon(IconKind.WIFI, 18f, c.acc), gap(6f),
            col(HA.S, VA.C, M(), c.T(c.data.net, 13f), c.T("Up ${uptime(c.data.uptimeMs)}", 10f, 0.6f)),
            spacer(),
            stat(c, "RAM", c.data.ramPct, bw, c.acc, 10)
        )
    )
}

val deviceDesigns: List<Design> = listOf(cockpit, reactor, hudFrame, liquid, batRing, batBar, gauges, storage, sysStrip)
