package com.example.widgetstudio.designs

import android.view.KeyEvent
import com.example.widgetstudio.core.*
import com.example.widgetstudio.render.*
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Calendar
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

private val WHITE = 0xFFFFFFFF.toInt()

// ================================================================================================ Weather
private fun wxPrompt(c: Ctx): N = c.root(
    Act.OpenStudio, 10f,
    col(HA.C, VA.C, M.Fill, c.icon(IconKind.CLOUD, min(c.h * 0.3f, 34f), c.acc), c.T("Set a city", 14f, m = M(pt = 4f)), c.T("Open Widget Studio → Data", 10f, 0.6f))
)

private fun withWeather(c: Ctx, body: (Weather) -> N): N = c.data.weather?.let(body) ?: wxPrompt(c)
private fun wxIcon(c: Ctx, code: Int, day: Boolean, s: Float): N = gfx(WeatherPainter(wKind(code, day), c.acc, c.fg.withAlpha(0.92f)), s, s, wLabel(code))
private fun dowName(dow: Int): String = java.time.DayOfWeek.of(dow).getDisplayName(java.time.format.TextStyle.SHORT, Locale.getDefault())
private val wxFields: List<Field> = listOf(Field.Special("city", "City", "weather"))

private val wxGlass = Design(
    id = "wx_glass", name = "Glass Forecast", tag = "Current conditions + multi-day outlook", cat = Category.WEATHER,
    sizes = listOf(WSize.MEDIUM, WSize.LARGE), needs = setOf(Need.WEATHER), fields = wxFields, featured = true,
    preset = { it.copy(font = FontKey.LIGHT, effects = setOf(Effect.GLASS, Effect.LIGHT), glow = 0.5f, accent = 0xFFFFC857.toInt(), bg = 0xFF132A4A.toInt(), bg2 = 0xFF0A1424.toInt()) }
) { c ->
    withWeather(c) { w ->
        val pad = 12f
        val n = if (c.size == WSize.LARGE) 5 else 4
        val days = w.days.take(n)
        fun day(d: DayForecast, cw: Float) = col(HA.C, VA.C, M(w = cw), c.T(dowName(d.dow), 11f, 0.7f), wxIcon(c, d.code, true, 22f), c.T(c.temp(d.maxC), 12f), c.T(c.temp(d.minC), 11f, 0.5f))
        if (c.size == WSize.LARGE) {
            val cw = (c.w - 2 * pad) / n
            c.root(
                Act.OpenStudio, pad,
                col(
                    HA.S, VA.T, M.Fill,
                    row(VA.C, HA.S, M.FillW, col(HA.S, VA.T, M(), c.T(w.city, 14f, 0.8f), c.T(c.temp(w.tempC), 64f), c.T("${wLabel(w.code)} · feels ${c.temp(w.feelsC)}", 12f, 0.7f)), spacer(), wxIcon(c, w.code, w.isDay, 72f)),
                    spacer(),
                    row(VA.C, HA.S, M.FillW, *days.map { day(it, cw) }.toTypedArray())
                )
            )
        } else {
            val cw = (c.w - 2 * pad) * 0.5f / n
            c.root(
                Act.OpenStudio, pad,
                row(
                    VA.C, HA.S, M.Fill,
                    wxIcon(c, w.code, w.isDay, 44f), gap(8f),
                    col(HA.S, VA.C, M(w = (c.w - 2 * pad) * 0.4f), c.T(c.temp(w.tempC), 36f), c.T(wLabel(w.code), 11f, 0.75f), c.T(w.city, 10f, 0.55f)),
                    spacer(),
                    row(VA.C, HA.E, M(), *days.map { day(it, cw) }.toTypedArray())
                )
            )
        }
    }
}

private val wxMinimal = Design(
    id = "wx_minimal", name = "Minimal Temp", tag = "Temperature and condition only", cat = Category.WEATHER,
    sizes = listOf(WSize.SMALL, WSize.STRIP), needs = setOf(Need.WEATHER), fields = wxFields,
    preset = { it.copy(font = FontKey.THIN, effects = setOf(Effect.GLASS), glow = 0.3f, accent = 0xFF7CE0FF.toInt()) }
) { c ->
    withWeather(c) { w ->
        if (c.size == WSize.STRIP) c.root(Act.OpenStudio, 10f, row(VA.C, HA.S, M.Fill, wxIcon(c, w.code, w.isDay, c.h * 0.7f), gap(8f), c.T(c.temp(w.tempC), c.h * 0.6f), spacer(), col(HA.E, VA.C, M(), c.T(wLabel(w.code), 12f, 0.85f), c.T(w.city, 10f, 0.55f))))
        else {
            val s = min(c.w, c.h)
            c.root(Act.OpenStudio, 8f, col(HA.C, VA.C, M.Fill, wxIcon(c, w.code, w.isDay, s * 0.34f), c.T(c.temp(w.tempC), s * 0.3f), c.T(wLabel(w.code), s * 0.1f, 0.75f)))
        }
    }
}

private fun fmtClock(ms: Long, tz: Int, h24: Boolean): String =
    Instant.ofEpochMilli(ms).atOffset(ZoneOffset.ofTotalSeconds(tz)).format(DateTimeFormatter.ofPattern(if (h24) "HH:mm" else "h:mm a"))

private val wxSun = Design(
    id = "wx_sun", name = "Sun Arc", tag = "Today's sun path with sunrise and sunset", cat = Category.WEATHER,
    sizes = listOf(WSize.MEDIUM, WSize.LARGE), needs = setOf(Need.WEATHER, Need.PERIODIC), fields = wxFields + Field.Toggle("h24", "24-hour times", false),
    preset = { it.copy(font = FontKey.MEDIUM, effects = setOf(Effect.GLASS), glow = 0.55f, accent = 0xFFFFB347.toInt(), bg = 0xFF2A1630.toInt(), bg2 = 0xFF0F0A1E.toInt()) }
) { c ->
    withWeather(c) { w ->
        val now = c.data.nowMs
        val pct = if (now in w.sunriseMs..w.sunsetMs && w.sunsetMs > w.sunriseMs) ((now - w.sunriseMs) * 100 / (w.sunsetMs - w.sunriseMs)).toInt() else -1
        val times = row(VA.C, HA.S, M.FillW, c.T("↑ ${fmtClock(w.sunriseMs, w.tzOffsetSec, c.h24)}", 12f, 0.8f), spacer(), c.T("↓ ${fmtClock(w.sunsetMs, w.tzOffsetSec, c.h24)}", 12f, 0.8f))
        if (c.size == WSize.LARGE) {
            val aw = c.w - 32f
            c.root(Act.OpenStudio, 16f, col(HA.S, VA.T, M.Fill, c.T(w.city, 13f, 0.7f), c.T(c.temp(w.tempC), 56f), c.T(wLabel(w.code), 13f, 0.75f), spacer(),
                gfx(SunArcPainter(pct, c.acc, c.track, c.cfg.glow), aw, aw * 0.5f), times))
        } else {
            val aw = (c.w - 24f) * 0.5f
            c.root(Act.OpenStudio, 12f, row(VA.C, HA.S, M.Fill,
                col(HA.S, VA.C, M(w = aw), c.T(c.temp(w.tempC), 34f), c.T(wLabel(w.code), 11f, 0.75f), c.T(w.city, 10f, 0.5f)), spacer(),
                col(HA.S, VA.C, M(w = aw), gfx(SunArcPainter(pct, c.acc, c.track, c.cfg.glow), aw, min(aw * 0.5f, c.h - 50f)), gap(h = 4f), times)))
        }
    }
}

// ================================================================================================ Music
private fun mediaTitle(c: Ctx) = c.data.media?.title ?: "Nothing playing"
private fun mediaSub(c: Ctx) = c.data.media?.artist?.takeIf { it.isNotBlank() } ?: if (!c.data.mediaAccess) "Tap to enable now-playing" else "Start playback in any app"
private fun subAct(c: Ctx): Act? = if (!c.data.mediaAccess) Act.MediaAccess else null
private fun playing(c: Ctx) = c.data.media?.playing == true

private fun ctl(c: Ctx, kind: IconKind, code: Int, s: Float, primary: Boolean): N = BoxN(
    A.C, M(w = s, h = s).click(Act.Media(code)),
    listOf(
        gfx(if (primary) PanelPainter(c.acc, c.acc2, -1f, glowColor = c.acc, glow = c.cfg.glow * 0.5f) else PanelPainter(c.fg.withAlpha(0.14f), c.fg.withAlpha(0.06f), -1f, stroke = c.fg.withAlpha(0.18f)), s, s),
        c.icon(kind, s * 0.5f, if (primary) (if (luminance(c.acc) > 0.4f) 0xFF10131A.toInt() else WHITE) else c.fg)
    )
)
private fun controls(c: Ctx, s: Float): N = row(
    VA.C, HA.C, M(),
    ctl(c, IconKind.PREV, KeyEvent.KEYCODE_MEDIA_PREVIOUS, s, false), gap(10f),
    ctl(c, if (playing(c)) IconKind.PAUSE else IconKind.PLAY, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, s * 1.2f, true), gap(10f),
    ctl(c, IconKind.NEXT, KeyEvent.KEYCODE_MEDIA_NEXT, s, false)
)
private fun wave(c: Ctx, w: Float, h: Float): N = gfx(WavePainter(mediaTitle(c).hashCode(), max(8, (w / 7f).toInt()), c.acc, c.acc2, 0.14f, playing(c)), w, h)
private val musicFields = listOf(Field.Special("media", "Now-playing info", "media"))

private val muGlass = Design(
    id = "mu_glass", name = "Player Glass", tag = "Disc, waveform and transport controls", cat = Category.MUSIC,
    sizes = listOf(WSize.MEDIUM, WSize.LARGE), needs = setOf(Need.MEDIA), fields = musicFields, featured = true,
    preset = { it.copy(font = FontKey.MEDIUM, effects = setOf(Effect.GLASS, Effect.LIGHT), glow = 0.55f, accent = 0xFFFF4DDB.toInt(), bg = 0xFF1A0B24.toInt(), bg2 = 0xFF0A0614.toInt()) }
) { c ->
    val pad = 12f
    if (c.size == WSize.LARGE) {
        val disc = min(c.w - 2 * pad, c.h * 0.45f)
        c.root(null, pad, col(HA.C, VA.C, M.Fill, gfx(VinylPainter(c.fg, c.acc, playing(c), c.cfg.glow), disc, disc), gap(h = 8f),
            BoxN(A.C, M.FillW.click(subAct(c)), listOf(col(HA.C, VA.C, M.FillW, c.T(mediaTitle(c), 17f), c.T(mediaSub(c), 12f, 0.65f)))), gap(h = 6f),
            wave(c, c.w - 2 * pad, 26f), gap(h = 8f), controls(c, 38f)))
    } else {
        val disc = c.h - 2 * pad
        val rw = c.w - 2 * pad - disc - 12f
        c.root(null, pad, row(VA.C, HA.S, M.Fill, gfx(VinylPainter(c.fg, c.acc, playing(c), c.cfg.glow), disc, disc), gap(12f),
            col(HA.S, VA.C, M(w = rw), BoxN(A.L, M(w = rw).click(subAct(c)), listOf(col(HA.S, VA.C, M(), c.T(mediaTitle(c), 14f), c.T(mediaSub(c), 11f, 0.65f)))), gap(h = 4f), wave(c, rw, 16f), gap(h = 4f), controls(c, 26f))))
    }
}

private val muMini = Design(
    id = "mu_mini", name = "Mini Controls", tag = "One-row transport with title", cat = Category.MUSIC,
    sizes = listOf(WSize.STRIP, WSize.MEDIUM), needs = setOf(Need.MEDIA), fields = musicFields,
    preset = { it.copy(font = FontKey.CONDENSED, effects = setOf(Effect.GLASS), glow = 0.4f, accent = 0xFF5CFFB0.toInt()) }
) { c ->
    val s = if (c.size == WSize.STRIP) c.h - 14f else 40f
    val tw = c.w - 24f - s * 3.3f - 28f
    c.root(null, 10f, row(VA.C, HA.S, M.Fill,
        BoxN(A.L, M(w = tw).click(subAct(c)), listOf(col(HA.S, VA.C, M(w = tw), c.T(mediaTitle(c), if (c.size == WSize.STRIP) 13f else 16f), c.T(mediaSub(c), 10f, 0.6f)))),
        spacer(), ctl(c, IconKind.PREV, KeyEvent.KEYCODE_MEDIA_PREVIOUS, s * 0.8f, false), gap(6f),
        ctl(c, if (playing(c)) IconKind.PAUSE else IconKind.PLAY, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, s, true), gap(6f),
        ctl(c, IconKind.NEXT, KeyEvent.KEYCODE_MEDIA_NEXT, s * 0.8f, false)))
}

private val muVinyl = Design(
    id = "mu_vinyl", name = "Vinyl Card", tag = "Big record with a play button", cat = Category.MUSIC,
    sizes = listOf(WSize.SMALL, WSize.LARGE), needs = setOf(Need.MEDIA), fields = musicFields,
    preset = { it.copy(font = FontKey.SERIF, effects = setOf(Effect.GLASS), glow = 0.5f, accent = 0xFFFFC857.toInt(), bg = 0xFF241608.toInt(), bg2 = 0xFF0F0A05.toInt()) }
) { c ->
    if (c.size == WSize.SMALL) {
        val d = min(c.w, c.h) - 14f
        c.root(null, 6f, BoxN(A.C, M.Fill, listOf(gfx(VinylPainter(c.fg, c.acc, playing(c), c.cfg.glow), d, d), ctl(c, if (playing(c)) IconKind.PAUSE else IconKind.PLAY, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, d * 0.3f, true))))
    } else {
        val d = min(c.w - 40f, c.h * 0.58f)
        c.root(null, 16f, col(HA.C, VA.C, M.Fill, gfx(VinylPainter(c.fg, c.acc, playing(c), c.cfg.glow), d, d), gap(h = 10f),
            BoxN(A.C, M.FillW.click(subAct(c)), listOf(col(HA.C, VA.C, M.FillW, c.T(mediaTitle(c), 18f), c.T(mediaSub(c), 12f, 0.65f)))), gap(h = 10f), controls(c, 36f)))
    }
}

// ================================================================================================ Calendar
private fun today(c: Ctx): LocalDate = Instant.ofEpochMilli(c.data.nowMs).atZone(ZoneId.systemDefault()).toLocalDate()
private fun sundayFirst(): Boolean = Calendar.getInstance().firstDayOfWeek == Calendar.SUNDAY

private val caMonth = Design(
    id = "ca_month", name = "Month View", tag = "Week strip (medium) or full month grid (large)", cat = Category.CALENDAR,
    sizes = listOf(WSize.MEDIUM, WSize.LARGE), needs = setOf(Need.DATE),
    preset = { it.copy(font = FontKey.MEDIUM, effects = setOf(Effect.GLASS), glow = 0.4f, accent = 0xFFFF6B6B.toInt()) }
) { c ->
    val t = today(c)
    val sf = sundayFirst()
    if (c.size == WSize.LARGE) {
        val first = t.withDayOfMonth(1)
        val off = if (sf) first.dayOfWeek.value % 7 else first.dayOfWeek.value - 1
        val gw = c.w - 32f
        c.root(Act.Calendar, 16f, col(HA.S, VA.T, M.Fill, row(VA.C, HA.S, M.FillW, c.C("MMMM", 24f), gap(8f), c.C("yyyy", 24f, 0.5f)), gap(h = 8f),
            gfx(MonthPainter(off, t.lengthOfMonth(), t.dayOfMonth, c.fg, c.acc, c.cfg.font.family, sf), gw, max(60f, c.h - 32f - 44f), "Calendar")))
    } else {
        val start = if (sf) t.minusDays((t.dayOfWeek.value % 7).toLong()) else t.minusDays((t.dayOfWeek.value - 1).toLong())
        val cw = (c.w - 24f) / 7f
        val cells = (0 until 7).map { i ->
            val d = start.plusDays(i.toLong())
            val isToday = d == t
            BoxN(A.C, M(w = cw, h = c.h - 56f), listOf(
                gfx(PanelPainter(if (isToday) c.acc else c.fg.withAlpha(0.07f), if (isToday) c.acc2 else c.fg.withAlpha(0.03f), -1f), cw - 4f, c.h - 56f),
                col(HA.C, VA.C, M(), c.T(d.dayOfWeek.getDisplayName(java.time.format.TextStyle.NARROW, Locale.getDefault()), 10f, 0.7f, color = if (isToday) 0xFF10131A.toInt() else c.fg),
                    c.T(d.dayOfMonth.toString(), 17f, color = if (isToday) 0xFF10131A.toInt() else c.fg))))
        }
        c.root(Act.Calendar, 12f, col(HA.S, VA.C, M.Fill, row(VA.C, HA.S, M.FillW, c.C("MMMM yyyy", 14f), spacer(), c.C("EEEE", 11f, 0.6f)), gap(h = 6f), row(VA.C, HA.S, M.FillW, *cells.toTypedArray())))
    }
}

private val caDate = Design(
    id = "ca_date", name = "Date Block", tag = "Tear-off calendar page", cat = Category.CALENDAR,
    sizes = listOf(WSize.SMALL, WSize.MEDIUM), needs = setOf(Need.DATE),
    preset = { it.copy(font = FontKey.BLACK, effects = setOf(Effect.GLASS), glow = 0.3f, accent = 0xFFFF6B6B.toInt(), radius = 22f) }
) { c ->
    val s = min(c.w, c.h) - 20f
    val ink = if (luminance(c.acc) > 0.4f) 0xFF10131A.toInt() else WHITE
    val page = BoxN(A.C, M(w = s, h = s), listOf(
        gfx(PanelPainter(c.fg.withAlpha(0.10f), c.fg.withAlpha(0.05f), 14f, stroke = c.fg.withAlpha(0.16f)), s, s),
        col(HA.C, VA.T, M.Fill,
            BoxN(A.C, M(w = s - 4f, h = s * 0.26f), listOf(gfx(PanelPainter(c.acc, c.acc2, 12f), s - 4f, s * 0.26f), c.C("MMM", s * 0.14f, color = ink))),
            c.C("d", s * 0.42f, m = M(pt = 0f)), c.C("EEEE", s * 0.11f, 0.7f))))
    c.root(Act.Calendar, 10f, if (c.size == WSize.MEDIUM) row(VA.C, HA.C, M.Fill, page, gap(18f), col(HA.S, VA.C, M(), c.C("EEEE", 22f), c.C("d MMMM yyyy", 13f, 0.65f))) else col(HA.C, VA.C, M.Fill, page))
}

private fun fmtT(ms: Long, h24: Boolean) = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern(if (h24) "HH:mm" else "h:mm a"))

private val caAgenda = Design(
    id = "ca_agenda", name = "Agenda", tag = "Your next calendar events", cat = Category.CALENDAR,
    sizes = listOf(WSize.MEDIUM, WSize.LARGE), needs = setOf(Need.AGENDA, Need.DATE, Need.PERIODIC),
    fields = listOf(Field.Special("calendar", "Calendar access", "calendar"), Field.Toggle("h24", "24-hour times", false)),
    preset = { it.copy(font = FontKey.MEDIUM, effects = setOf(Effect.GLASS), glow = 0.35f, accent = 0xFF7C9CFF.toInt()) }
) { c ->
    val pad = 12f
    if (!c.data.calendarPerm) {
        c.root(Act.OpenStudio, pad, col(HA.C, VA.C, M.Fill, c.icon(IconKind.CALENDAR, 28f, c.acc), c.T("Allow calendar access", 14f, m = M(pt = 4f)), c.T("Open Widget Studio → Data", 10f, 0.6f)))
    } else {
        val rowH = 30f
        val n = max(1, ((c.h - 2 * pad - 20f) / rowH).toInt())
        val items = c.data.agenda.take(n)
        c.root(Act.Calendar, pad, col(HA.S, VA.T, M.Fill, c.C("EEEE, d MMM", 13f, 0.7f, m = M(pb = 4f)),
            if (items.isEmpty()) c.T("No upcoming events", 14f, 0.8f, m = M(pt = 6f))
            else col(HA.S, VA.T, M.FillW, *items.map { e ->
                row(VA.C, HA.S, M(fw = true, h = rowH), gfx(PanelPainter(e.color.opaque(), e.color.opaque(), -1f), 4f, rowH - 10f), gap(8f),
                    col(HA.S, VA.C, M(), c.T(e.title, 13f), c.T(if (e.allDay) "All day" else fmtT(e.begin, c.h24), 10f, 0.6f)))
            }.toTypedArray())))
    }
}

// ================================================================================================ Productivity
private val prTasks = Design(
    id = "pr_tasks", name = "Task List", tag = "Tap a task on the home screen to tick it", cat = Category.PRODUCTIVITY,
    sizes = listOf(WSize.MEDIUM, WSize.LARGE), needs = setOf(Need.TASKS),
    fields = listOf(Field.Special("tasks", "Tasks", "tasks")), featured = true,
    preset = { it.copy(font = FontKey.MEDIUM, effects = setOf(Effect.GLASS), glow = 0.4f, accent = 0xFF5CFFB0.toInt()) }
) { c ->
    val pad = 12f
    val rowH = 26f
    val n = max(1, ((c.h - 2 * pad - 24f) / rowH).toInt())
    val left = c.data.tasks.count { !it.done }
    c.root(Act.OpenStudio, pad, col(HA.S, VA.T, M.Fill,
        row(VA.C, HA.S, M.FillW, c.T("Tasks", 15f), spacer(), c.T("$left left", 11f, 0.6f)), gap(h = 4f),
        if (c.data.tasks.isEmpty()) c.T("Nothing to do. Add tasks in Widget Studio.", 12f, 0.7f, lines = 2, m = M(pt = 6f))
        else col(HA.S, VA.T, M.FillW, *c.data.tasks.take(n).map { t ->
            row(VA.C, HA.S, M(fw = true, h = rowH).click(Act.ToggleTask(t.id)),
                gfx(IconPainter(if (t.done) IconKind.CHECK else IconKind.EMPTY_BOX, if (t.done) c.acc else c.fg.withAlpha(0.6f), 2.2f), 18f, 18f), gap(8f),
                c.T(t.text, 13f, if (t.done) 0.4f else 1f))
        }.toTypedArray())))
}

private val prNote = Design(
    id = "pr_note", name = "Quick Note", tag = "A sticky note on your home screen", cat = Category.PRODUCTIVITY,
    sizes = listOf(WSize.SMALL, WSize.MEDIUM, WSize.LARGE),
    fields = listOf(Field.Str("title", "Title", def = "Note"), Field.Str("note", "Note text", def = "Pick up groceries\nCall the dentist", multiline = true)),
    preset = { it.copy(font = FontKey.SERIF, effects = setOf(Effect.GLASS), glow = 0.25f, accent = 0xFFFFC857.toInt(), bg = 0xFF2B2410.toInt(), bg2 = 0xFF1A1608.toInt()) }
) { c ->
    c.root(Act.OpenStudio, 12f, col(HA.S, VA.T, M.Fill,
        row(VA.C, HA.S, M.FillW, c.icon(IconKind.NOTE, 16f, c.acc), gap(6f), c.T(c.cfg.str("title", "Note"), 14f, color = c.acc)), gap(h = 6f),
        c.T(c.cfg.str("note", ""), if (c.size == WSize.SMALL) 12f else 14f, 0.92f, lines = 5)))
}

private val prDay = Design(
    id = "pr_day", name = "Day Progress", tag = "Day, week, month and year bars", cat = Category.PRODUCTIVITY,
    sizes = listOf(WSize.SMALL, WSize.MEDIUM, WSize.LARGE), needs = setOf(Need.DATE, Need.PERIODIC),
    preset = { it.copy(font = FontKey.CONDENSED, effects = setOf(Effect.GLASS, Effect.HUD), glow = 0.45f, accent = 0xFF4DE1FF.toInt()) }
) { c ->
    val z = Instant.ofEpochMilli(c.data.nowMs).atZone(ZoneId.systemDefault())
    val frac = z.toLocalTime().toSecondOfDay() / 86400f
    val day = (frac * 100).toInt()
    val week = (((z.dayOfWeek.value - 1) + frac) / 7f * 100).toInt()
    val month = (((z.dayOfMonth - 1) + frac) / z.toLocalDate().lengthOfMonth() * 100).toInt()
    val year = (((z.dayOfYear - 1) + frac) / z.toLocalDate().lengthOfYear() * 100).toInt()
    val all = listOf("Day" to day, "Week" to week, "Month" to month, "Year" to year)
    val rows = if (c.size == WSize.SMALL) all.take(2) else all
    val bw = c.w - 28f
    val colors = listOf(c.acc, c.acc2, lerpColor(c.acc, 0xFFFF6BD6.toInt(), 0.6f), lerpColor(c.acc2, 0xFFFFC857.toInt(), 0.6f))
    c.root(null, 14f, col(HA.S, VA.C, M.Fill, *rows.mapIndexed { i, (l, p) ->
        col(HA.S, VA.C, M(w = bw, pt = if (i == 0) 0f else 7f), row(VA.C, HA.S, M(w = bw), c.T(l, 11f, 0.75f), spacer(), c.T("$p%", 11f)),
            gfx(CellsPainter(p, 0, colors[i], lerpColor(colors[i], WHITE, 0.3f), c.track, 3f, c.cfg.glow * 0.6f), bw, 6f, "$l $p%", M(pt = 3f)))
    }.toTypedArray()))
}

// ================================================================================================ Countdown
private fun parseDate(s: String): LocalDate? = runCatching { LocalDate.parse(s) }.getOrNull()
private class Cd(val days: Long, val pct: Int, val title: String, val target: LocalDate)
private fun cd(c: Ctx): Cd {
    val now = today(c)
    val target = parseDate(c.cfg.str("target")) ?: now.plusDays(30)
    val start = parseDate(c.cfg.str("start")) ?: now.minusDays(30)
    val total = max(1L, ChronoUnit.DAYS.between(start, target))
    val done = ChronoUnit.DAYS.between(start, now)
    return Cd(ChronoUnit.DAYS.between(now, target), (done * 100 / total).toInt().coerceIn(0, 100), c.cfg.str("title", "My event"), target)
}
private val cdFields = listOf(Field.Str("title", "Event name", def = "My event"), Field.DateF("target", "Target date", 30), Field.DateF("start", "Start date (for the ring)", 0))
private fun cdUnit(d: Long) = if (d == 1L || d == -1L) "day" else "days"
private fun cdWord(d: Long) = if (d >= 0) "until" else "since"

private val cdRing = Design(
    id = "cd_ring", name = "Ring Countdown", tag = "Days left as a progress ring", cat = Category.COUNTDOWN,
    sizes = listOf(WSize.SMALL, WSize.MEDIUM), needs = setOf(Need.DATE), fields = cdFields, featured = true,
    preset = { it.copy(font = FontKey.LIGHT, effects = setOf(Effect.NEON), glow = 0.6f, accent = 0xFFFF6B9D.toInt(), bg = 0xFF150810.toInt(), bg2 = 0xFF2A0F22.toInt()) }
) { c ->
    val d = cd(c)
    val side = min(c.w, c.h) - 18f
    val ring = BoxN(A.C, M(w = side, h = side), listOf(gfx(RingPainter(d.pct, c.acc, c.acc2, side * 0.07f, c.track, c.cfg.glow), side, side, "${d.days} ${cdUnit(d.days)}"),
        col(HA.C, VA.C, M(), c.T("${kotlin.math.abs(d.days)}", side * 0.3f), c.T(cdUnit(kotlin.math.abs(d.days)), side * 0.1f, 0.7f))))
    c.root(Act.OpenStudio, 8f, if (c.size == WSize.MEDIUM) row(VA.C, HA.C, M.Fill, ring, gap(16f), col(HA.S, VA.C, M(), c.T(d.title, 17f, lines = 2), c.T("${cdWord(d.days)} ${d.target.format(DateTimeFormatter.ofPattern("d MMM yyyy"))}", 11f, 0.65f))) else col(HA.C, VA.C, M.Fill, ring))
}

private val cdBig = Design(
    id = "cd_big", name = "Big Days", tag = "Giant number with weeks breakdown", cat = Category.COUNTDOWN,
    sizes = listOf(WSize.STRIP, WSize.MEDIUM, WSize.LARGE), needs = setOf(Need.DATE), fields = cdFields,
    preset = { it.copy(font = FontKey.BLACK, effects = setOf(Effect.GLASS, Effect.LIGHT), glow = 0.5f, accent = 0xFFFFC857.toInt()) }
) { c ->
    val d = cd(c)
    val a = kotlin.math.abs(d.days)
    if (c.size == WSize.STRIP) c.root(Act.OpenStudio, 10f, row(VA.C, HA.S, M.Fill, c.T("$a", c.h * 0.6f, color = c.acc), gap(8f), c.T("${cdUnit(a)} ${cdWord(d.days)} ${d.title}", 13f, 0.85f)))
    else {
        val big = min(c.h * 0.5f, c.w * 0.3f)
        c.root(Act.OpenStudio, 14f, col(HA.S, VA.C, M.Fill, c.T(d.title, 13f, 0.7f), row(VA.C, HA.S, M(), c.T("$a", big, color = c.acc), gap(8f), c.T("${cdUnit(a)}\n${cdWord(d.days)}", big * 0.22f, 0.75f, lines = 2)),
            c.T("${a / 7} weeks, ${a % 7} days  ·  ${d.target.format(DateTimeFormatter.ofPattern("EEE d MMM"))}", 11f, 0.6f),
            if (c.size == WSize.LARGE) gfx(CellsPainter(d.pct, 0, c.acc, c.acc2, c.track, 4f, c.cfg.glow), c.w - 28f, 10f, null, M(pt = 12f)) else gap()))
    }
}

val infoDesigns: List<Design> = listOf(wxGlass, wxMinimal, wxSun, muGlass, muMini, muVinyl, caMonth, caDate, caAgenda, prTasks, prNote, prDay, cdRing, cdBig)
