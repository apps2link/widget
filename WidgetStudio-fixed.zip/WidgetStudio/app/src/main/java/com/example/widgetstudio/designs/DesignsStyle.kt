package com.example.widgetstudio.designs

import com.example.widgetstudio.R
import com.example.widgetstudio.core.*
import com.example.widgetstudio.render.*
import kotlin.math.max
import kotlin.math.min

private val WHITE = 0xFFFFFFFF.toInt()
private val BLACK = 0xFF000000.toInt()
private val BAT = setOf(Need.BATTERY, Need.PERIODIC)

// ================================================================================================ App shortcuts
private fun pkgs(c: Ctx): List<String> = c.cfg.str("apps").split(",").filter { it.isNotBlank() }

private fun appIcon(c: Ctx, pkg: String, s: Float): N = BoxN(
    A.C, M(w = s, h = s).click(Act.App(pkg)),
    listOf(gfx(AppIconPainter(pkg, c.data.icons[pkg], c.cfg.iconStyle.ordinal, c.fg.withAlpha(0.10f)), s, s, c.data.labels[pkg] ?: pkg))
)

private fun pickApps(c: Ctx): N = c.root(
    Act.OpenStudio, 10f,
    col(HA.C, VA.C, M.Fill, c.icon(IconKind.PLUS, min(c.h * 0.3f, 28f), c.acc), c.T("Choose apps", 13f, m = M(pt = 4f)), c.T("Open Widget Studio → Data", 10f, 0.6f))
)

private val appField = listOf(Field.Apps("apps", "Apps", 8))

private val dock = Design(
    id = "sc_dock", name = "Glass Dock", tag = "A floating dock of your favourite apps", cat = Category.SHORTCUTS,
    sizes = listOf(WSize.STRIP, WSize.MEDIUM), needs = setOf(Need.APPS), fields = appField, featured = true,
    layouts = listOf("Evenly spaced", "Packed"),
    preset = { it.copy(effects = setOf(Effect.GLASS), glow = 0.4f, alpha = 0.55f, radius = 30f, iconStyle = IconStyle.ROUNDED) }
) { c ->
    val list = pkgs(c).take(if (c.size == WSize.STRIP) 5 else 6)
    if (list.isEmpty()) pickApps(c) else {
        val s = min(c.h - 14f, 52f)
        val items = list.map { appIcon(c, it, s) }
        val withGaps = ArrayList<N>()
        items.forEachIndexed { i, n -> if (i > 0) withGaps.add(if (c.cfg.layout == 0) spacer() else gap(10f)); withGaps.add(n) }
        c.root(null, 8f, row(VA.C, if (c.cfg.layout == 0) HA.S else HA.C, M.Fill, *withGaps.toTypedArray()))
    }
}

private val grid = Design(
    id = "sc_grid", name = "App Grid", tag = "Icons with labels in a tidy grid", cat = Category.SHORTCUTS,
    sizes = listOf(WSize.MEDIUM, WSize.LARGE), needs = setOf(Need.APPS), fields = appField,
    preset = { it.copy(effects = setOf(Effect.GLASS), glow = 0.35f, iconStyle = IconStyle.CIRCLE, font = FontKey.MEDIUM) }
) { c ->
    val list = pkgs(c).take(8)
    if (list.isEmpty()) pickApps(c) else {
        val pad = 10f
        val cols = 4
        val rows = if (c.size == WSize.LARGE) 2 else 1
        val cw = (c.w - 2 * pad) / cols
        val s = min(cw - 14f, (c.h - 2 * pad) / rows - 20f).coerceAtLeast(24f)
        val cells = list.map { p ->
            col(HA.C, VA.C, M(w = cw), appIcon(c, p, s), c.T((c.data.labels[p] ?: p).take(10), 10f, 0.8f, m = M(pt = 2f)))
        }
        c.root(null, pad, col(HA.S, VA.C, M.Fill, *cells.chunked(cols).take(rows).map { r -> row(VA.T, HA.S, M.FillW, *r.toTypedArray()) }.toTypedArray()))
    }
}

private val pills = Design(
    id = "sc_pills", name = "Shortcut Pills", tag = "Instagram, WhatsApp and Call pills", cat = Category.SHORTCUTS,
    sizes = listOf(WSize.MEDIUM, WSize.LARGE), layouts = listOf("Knob left", "Knob right", "Alternating"),
    effects = listOf(Effect.GLASS, Effect.NEON, Effect.LIGHT, Effect.PULSE),
    preset = { it.copy(accent = 0xFF4A5B8C.toInt(), bg = 0xFF1B1F27.toInt(), bg2 = 0xFF0F1218.toInt(), font = FontKey.MEDIUM, glow = 0.25f, effects = setOf(Effect.GLASS)) }
) { c ->
    val pad = 10f
    val gv = 6f
    val rowH = (c.h - 2 * pad - 2 * gv) / 3f
    val w = c.w - 2 * pad
    val knobs = listOf(c.acc, lerpColor(c.acc, BLACK, 0.55f), BLACK)
    val defs = listOf(Triple("Instagram", R.drawable.ic_ig, Act.App("com.instagram.android", "https://instagram.com")),
        Triple("WhatsApp", R.drawable.ic_wa, Act.App("com.whatsapp", "https://wa.me/")), Triple("Call", R.drawable.ic_call, Act.Dial))
    fun pill(i: Int): N {
        val (label, ic, act) = defs[i]
        val right = when (c.cfg.layout) { 1 -> true; 2 -> i % 2 == 1; else -> false }
        val ks = rowH - 8f
        val knob = BoxN(A.C, M(w = ks, h = ks), listOf(gfx(PanelPainter(knobs[i], knobs[i], -1f, stroke = c.fg.withAlpha(0.18f)), ks, ks), VecN(ic, WHITE, M(w = ks * 0.5f, h = ks * 0.5f))))
        val text = c.T(label, min(14f, rowH * 0.42f))
        return BoxN(A.C, M(w = w, h = rowH).click(act), listOf(
            gfx(PanelPainter(c.fg.withAlpha(0.13f), c.fg.withAlpha(0.06f), -1f, stroke = c.fg.withAlpha(0.16f)), w, rowH),
            if (right) row(VA.C, HA.S, M(fw = true, h = rowH, pl = 16f, pr = 4f), text, spacer(), knob)
            else row(VA.C, HA.S, M(fw = true, h = rowH, pl = 4f, pr = 16f), knob, gap(12f), text)
        ))
    }
    c.root(null, pad, col(HA.S, VA.C, M.Fill, pill(0), gap(h = gv), pill(1), gap(h = gv), pill(2)))
}

// ================================================================================================ Glass
private fun tile(c: Ctx, w: Float, h: Float, vararg k: N): N = BoxN(
    A.C, M(w = w, h = h),
    listOf(gfx(PanelPainter(c.fg.withAlpha(0.14f), c.fg.withAlpha(0.05f), 18f, stroke = c.fg.withAlpha(0.22f)), w, h), *k)
)
private val glassPreset: (WidgetConfig) -> WidgetConfig = {
    it.copy(bg = 0xFF9FB4FF.toInt(), bg2 = 0xFF6B7CFF.toInt(), alpha = 0.30f, textMode = TextMode.LIGHT, effects = setOf(Effect.GLASS, Effect.LIGHT), glow = 0.35f, radius = 32f, accent = 0xFFFFFFFF.toInt(), font = FontKey.LIGHT)
}

private val glClock = Design(
    id = "gl_clock", name = "Frost Clock", tag = "Frosted tile with time and chips", cat = Category.GLASS,
    sizes = listOf(WSize.MEDIUM, WSize.LARGE), needs = BAT, featured = true, effects = Effect.entries.toList(),
    fields = listOf(Field.Toggle("h24", "24-hour clock", false)), preset = glassPreset
) { c ->
    val pad = 10f
    val tw = c.w - 2 * pad
    if (c.size == WSize.LARGE) {
        val th = (c.h - 2 * pad) * 0.62f
        val cw = (tw - 8f) / 2f
        val ch = c.h - 2 * pad - th - 8f
        c.root(Act.Alarms, pad, col(HA.S, VA.T, M.Fill,
            tile(c, tw, th, col(HA.C, VA.C, M(), c.C(c.tf, min(th * 0.5f, 72f)), c.C("EEEE, d MMMM", 14f, 0.8f))), gap(h = 8f),
            row(VA.C, HA.S, M.FillW, tile(c, cw, ch, row(VA.C, HA.C, M(), c.icon(IconKind.BATTERY, 20f), gap(6f), c.T("${c.data.battery}%", 18f))), gap(8f),
                tile(c, cw, ch, c.C("d MMM", 18f)))))
    } else {
        val th = c.h - 2 * pad
        val tw1 = tw * 0.62f
        c.root(Act.Alarms, pad, row(VA.C, HA.S, M.Fill,
            tile(c, tw1, th, col(HA.C, VA.C, M(), c.C(c.tf, min(th * 0.5f, 50f)), c.C("EEE, d MMM", 11f, 0.8f))), gap(8f),
            tile(c, tw - tw1 - 8f, th, col(HA.C, VA.C, M(), c.icon(if (c.data.charging) IconKind.BOLT else IconKind.BATTERY, 20f), c.T("${c.data.battery}%", 20f)))))
    }
}

private val glDuo = Design(
    id = "gl_duo", name = "Frost Pair", tag = "Time tile beside a battery ring", cat = Category.GLASS,
    sizes = listOf(WSize.MEDIUM), needs = BAT, fields = listOf(Field.Toggle("h24", "24-hour clock", false)), preset = glassPreset
) { c ->
    val pad = 10f
    val th = c.h - 2 * pad
    val lw = (c.w - 2 * pad - 8f) * 0.6f
    val rw = c.w - 2 * pad - 8f - lw
    val rs = min(rw, th) - 14f
    c.root(Act.Alarms, pad, row(VA.C, HA.S, M.Fill,
        tile(c, lw, th, c.C(c.tf, min(th * 0.52f, 52f))), gap(8f),
        tile(c, rw, th, BoxN(A.C, M(w = rs, h = rs), listOf(gfx(RingPainter(c.data.battery, c.battColor(), c.battColor2(), rs * 0.1f, c.track, c.cfg.glow * 0.5f), rs, rs), c.T("${c.data.battery}", rs * 0.3f))))))
}

private val glTiles = Design(
    id = "gl_tiles", name = "Frost Tiles", tag = "Four glass tiles: time, date, battery, memory", cat = Category.GLASS,
    sizes = listOf(WSize.LARGE), needs = setOf(Need.BATTERY, Need.SYSTEM, Need.DATE, Need.PERIODIC), fields = listOf(Field.Toggle("h24", "24-hour clock", false)), preset = glassPreset
) { c ->
    val pad = 10f
    val tw = (c.w - 2 * pad - 8f) / 2f
    val th = (c.h - 2 * pad - 8f) / 2f
    val rs = min(tw, th) - 24f
    fun gauge(pct: Int, c1: Int, label: String) = tile(c, tw, th, BoxN(A.C, M(w = rs, h = rs), listOf(gfx(RingPainter(pct, c1, lerpColor(c1, WHITE, 0.3f), rs * 0.09f, c.track, c.cfg.glow * 0.5f), rs, rs), col(HA.C, VA.C, M(), c.T("$pct%", rs * 0.26f), c.T(label, rs * 0.11f, 0.7f)))))
    c.root(Act.Alarms, pad, col(HA.S, VA.T, M.Fill,
        row(VA.C, HA.S, M.FillW, tile(c, tw, th, c.C(c.tf, min(th * 0.38f, 40f))), gap(8f), tile(c, tw, th, col(HA.C, VA.C, M(), c.C("d", th * 0.4f), c.C("EEE MMM", 12f, 0.75f)))), gap(h = 8f),
        row(VA.C, HA.S, M.FillW, gauge(c.data.battery, c.battColor(), "BATTERY"), gap(8f), gauge(c.data.ramPct, c.acc2, "MEMORY"))))
}

// ================================================================================================ Neon
private val neonPreset: (WidgetConfig) -> WidgetConfig = {
    it.copy(bg = 0xFF05060B.toInt(), bg2 = 0xFF14081E.toInt(), alpha = 0.96f, effects = setOf(Effect.NEON, Effect.PULSE), accent = 0xFFFF4DDB.toInt(), glow = 0.85f, textMode = TextMode.ACCENT, font = FontKey.MEDIUM, radius = 24f)
}

private val nnSign = Design(
    id = "nn_sign", name = "Neon Sign", tag = "Glowing tube time on a dark wall", cat = Category.NEON,
    sizes = listOf(WSize.SMALL, WSize.MEDIUM, WSize.LARGE), featured = true,
    fields = listOf(Field.Toggle("h24", "24-hour clock", false), Field.Toggle("date", "Show date", true)),
    preset = neonPreset
) { c ->
    val big = min(c.h * 0.46f, c.w * 0.27f)
    c.root(Act.Alarms, 8f, BoxN(A.C, M.Fill, listOf(
        gfx(GlowPainter(c.acc, c.cfg.glow), c.w * 0.85f, c.h * 0.55f),
        col(HA.C, VA.C, M(), c.C(c.tf, big), if (c.cfg.flag("date", true)) c.C("EEE d MMM", big * 0.26f, 0.8f, color = c.fg, m = M(pt = 2f)) else gap()))))
}

private fun nbar(c: Ctx, label: String, pct: Int, w: Float, color: Int): N = col(
    HA.S, VA.C, M(w = w),
    row(VA.C, HA.S, M(w = w), c.T(label, 10f, 0.85f, FontKey.CONDENSED), spacer(), c.T("$pct%", 10f, 1f, FontKey.CONDENSED)),
    gfx(CellsPainter(pct, 16, color, lerpColor(color, WHITE, 0.35f), color.withAlpha(0.13f), 2f, c.cfg.glow), w, 9f, "$label $pct%", M(pt = 2f))
)

private val nnBars = Design(
    id = "nn_bars", name = "Neon Bars", tag = "Battery, memory and storage tubes", cat = Category.NEON,
    sizes = listOf(WSize.MEDIUM, WSize.LARGE), needs = setOf(Need.BATTERY, Need.SYSTEM, Need.PERIODIC),
    preset = { neonPreset(it).copy(accent = 0xFF4DE1FF.toInt(), bg2 = 0xFF081426.toInt()) }
) { c ->
    val pad = 14f
    val w = if (c.size == WSize.LARGE) c.w - 2 * pad else (c.w - 2 * pad) * 0.58f
    val bars = col(HA.S, VA.C, M(w = w), nbar(c, "BATTERY", c.data.battery, w, c.battColor()), gap(h = 8f), nbar(c, "MEMORY", c.data.ramPct, w, c.acc2), gap(h = 8f), nbar(c, "STORAGE", c.data.storagePct, w, lerpColor(c.acc, 0xFFFF4DDB.toInt(), 0.6f)))
    c.root(Act.Alarms, pad, if (c.size == WSize.LARGE) col(HA.S, VA.C, M.Fill, c.C(if (c.h24) "HH:mm" else "h:mm", 56f), gap(h = 14f), bars) else row(VA.C, HA.S, M.Fill, c.C(if (c.h24) "HH:mm" else "h:mm", min(c.h * 0.3f, 34f)), spacer(), bars))
}

private val nnSun = Design(
    id = "nn_sun", name = "Synth Sunset", tag = "Retro sunset with the date", cat = Category.NEON,
    sizes = listOf(WSize.SMALL, WSize.MEDIUM), needs = setOf(Need.DATE),
    preset = { neonPreset(it).copy(accent = 0xFFFF4DDB.toInt(), bg = 0xFF0B0418.toInt(), bg2 = 0xFF1E0A38.toInt(), textMode = TextMode.LIGHT) }
) { c ->
    val pad = 6f
    val gw = c.w - 2 * pad; val gh = c.h - 2 * pad
    c.root(Act.Calendar, pad, BoxN(A.C, M.Fill, listOf(
        gfx(SynthPainter(0xFFFF4DDB.toInt(), 0xFFFFC857.toInt(), c.acc, c.cfg.glow), gw, gh),
        BoxN(A.T, M.Fill.pad(0f, 6f), listOf(c.C("EEE d MMM", min(c.h * 0.16f, 15f), color = c.fg))))))
}

val styleDesigns: List<Design> = listOf(dock, grid, pills, glClock, glDuo, glTiles, nnSign, nnBars, nnSun)
