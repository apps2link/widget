package com.example.widgetstudio.designs

import com.example.widgetstudio.core.*
import java.time.LocalDate

object Registry {
    val all: List<Design> = (clockDesigns + deviceDesigns + infoDesigns + styleDesigns)
    private val byId = all.associateBy { it.id }

    fun get(id: String): Design? = byId[id]
    fun byCategory(cat: Category): List<Design> = all.filter { it.cat == cat }
    fun featured(): List<Design> = all.filter { it.featured }
    fun search(q: String): List<Design> {
        val s = q.trim().lowercase()
        if (s.isEmpty()) return all
        return all.filter { it.name.lowercase().contains(s) || it.tag.lowercase().contains(s) || it.cat.title.lowercase().contains(s) }
    }

    /** First design for a size class, used when a widget is added with no configuration at all. */
    fun fallback(size: WSize): Design = all.first { size in it.sizes && it.id.startsWith("dc_aurora") }

    fun defaultSize(d: Design): WSize = d.sizes.firstOrNull { it == WSize.MEDIUM } ?: d.sizes.first()

    /** Preset defaults + field defaults for a design at a size. */
    fun defaultConfig(d: Design, size: WSize = defaultSize(d)): WidgetConfig {
        var cfg = d.preset(WidgetConfig(d.id, size, effects = setOf(Effect.GLASS)))
        cfg = cfg.copy(designId = d.id, size = size, effects = cfg.effects.filter { it in d.effects }.toSet())
        val ex = HashMap(cfg.extras)
        for (f in d.fields) when (f) {
            is Field.Toggle -> ex.getOrPut(f.key) { if (f.def) "1" else "0" }
            is Field.Str -> ex.getOrPut(f.key) { f.def }
            is Field.Choice -> ex.getOrPut(f.key) { f.def.toString() }
            is Field.DateF -> ex.getOrPut(f.key) { LocalDate.now().plusDays(f.offsetDays.toLong()).toString() }
            else -> Unit
        }
        return cfg.copy(extras = ex)
    }

    /** Switch an existing config to a different size, keeping the user's styling. */
    fun resize(cfg: WidgetConfig, size: WSize): WidgetConfig = cfg.copy(size = size)
}
