package com.example.widgetstudio.render

import android.graphics.Bitmap
import android.graphics.Canvas
import android.util.LruCache
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Painter -> Bitmap for RemoteViews. Bounded LRU keyed by painter value + pixel size, so identical
 * layers (same config, same data) are never re-rendered or re-allocated between refreshes.
 * Each layer is capped at ~600k pixels to stay well inside the RemoteViews bitmap memory budget.
 */
object BitmapCache {
    private data class Key(val p: Painter, val w: Int, val h: Int)

    private val cache = object : LruCache<Key, Bitmap>(8 * 1024 * 1024) {
        override fun sizeOf(key: Key, value: Bitmap): Int = value.byteCount
    }

    @Synchronized
    fun get(p: Painter, wDp: Float, hDp: Float, density: Float): Bitmap {
        var d = min(density, 3f)
        var pw = wDp * d; var ph = hDp * d
        if (pw * ph > 600_000f) { val f = sqrt(600_000f / (pw * ph)); d *= f; pw *= f; ph *= f }
        val w = max(1, pw.toInt()); val h = max(1, ph.toInt())
        val key = Key(p, w, h)
        cache.get(key)?.let { return it }
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        p.paint(Canvas(bmp), w.toFloat(), h.toFloat(), d, 0f)
        cache.put(key, bmp)
        return bmp
    }
}
