package com.example.widgetstudio.render

import android.graphics.Typeface
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.State
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Calendar

/** Compose interpreter of the layout IR (in-app previews). Mirrors GlanceRenderer node by node. */
private fun mod(m: M, rs: RowScope?, cs: ColumnScope?): Modifier {
    var g: Modifier = Modifier
    if (m.fw) g = g.fillMaxWidth()
    if (m.fh) g = g.fillMaxHeight()
    m.w?.let { g = g.width(it.dp) }
    m.h?.let { g = g.height(it.dp) }
    if (m.weight) {
        if (rs != null) g = g.then(with(rs) { Modifier.weight(1f) })
        else if (cs != null) g = g.then(with(cs) { Modifier.weight(1f) })
    }
    if (m.pl + m.pt + m.pr + m.pb > 0f) g = g.padding(start = m.pl.dp, top = m.pt.dp, end = m.pr.dp, bottom = m.pb.dp)
    return g
}

private fun al(a: A): Alignment = when (a) {
    A.TL -> Alignment.TopStart; A.T -> Alignment.TopCenter; A.TR -> Alignment.TopEnd
    A.L -> Alignment.CenterStart; A.C -> Alignment.Center; A.R -> Alignment.CenterEnd
    A.BL -> Alignment.BottomStart; A.B -> Alignment.BottomCenter; A.BR -> Alignment.BottomEnd
}
private fun hal(a: HA): Alignment.Horizontal = when (a) { HA.S -> Alignment.Start; HA.C -> Alignment.CenterHorizontally; HA.E -> Alignment.End }
private fun vertAl(a: VA): Alignment.Vertical = when (a) { VA.T -> Alignment.Top; VA.C -> Alignment.CenterVertically; VA.B -> Alignment.Bottom }
private fun vArr(a: VA): Arrangement.Vertical = when (a) { VA.T -> Arrangement.Top; VA.C -> Arrangement.Center; VA.B -> Arrangement.Bottom }
private fun hArr(a: HA): Arrangement.Horizontal = when (a) { HA.S -> Arrangement.Start; HA.C -> Arrangement.Center; HA.E -> Arrangement.End }

@Composable
fun NodeView(n: N, phase: State<Float>, nowMs: Long, rs: RowScope? = null, cs: ColumnScope? = null) {
    val m = mod(n.m, rs, cs)
    when (n) {
        is BoxN -> Box(m, contentAlignment = al(n.al)) { n.kids.forEach { NodeView(it, phase, nowMs) } }
        is ColN -> Column(m, verticalArrangement = vArr(n.va), horizontalAlignment = hal(n.ha)) {
            val scope = this
            n.kids.forEach { NodeView(it, phase, nowMs, cs = scope) }
        }
        is RowN -> Row(m, horizontalArrangement = hArr(n.ha), verticalAlignment = vertAl(n.va)) {
            val scope = this
            n.kids.forEach { NodeView(it, phase, nowMs, rs = scope) }
        }
        is TextN -> {
            val ff = remember(n.font) { FontFamily(Typeface.create(n.font.family, Typeface.NORMAL)) }
            BasicText(n.text, m, TextStyle(color = Color(n.color), fontSize = n.sp.sp, fontFamily = ff), maxLines = n.lines, overflow = TextOverflow.Ellipsis)
        }
        is ClockN -> {
            val ff = remember(n.font) { FontFamily(Typeface.create(n.font.family, Typeface.NORMAL)) }
            val s = android.text.format.DateFormat.format(n.fmt, nowMs).toString()
            BasicText(s, m, TextStyle(color = Color(n.color), fontSize = n.sp.sp, fontFamily = ff), maxLines = 1)
        }
        is GfxN -> Canvas(if (n.m.w == null && !n.m.fw) m.fillMaxSize() else m) {
            drawIntoCanvas { cv -> n.p.paint(cv.nativeCanvas, size.width, size.height, density, phase.value) }
        }
        is VecN -> Image(painterResource(n.res), null, m, colorFilter = ColorFilter.tint(Color(n.tint)))
        is AnalogN -> Box(m.size(n.sizeDp.dp)) {
            Canvas(Modifier.fillMaxSize()) {
                drawIntoCanvas { cv -> n.dial.paint(cv.nativeCanvas, size.width, size.height, density, phase.value) }
            }
            Canvas(Modifier.fillMaxSize()) {
                val cal = Calendar.getInstance().also { it.timeInMillis = nowMs }
                drawIntoCanvas { cv ->
                    drawHands(cv.nativeCanvas, size.width, cal.get(Calendar.HOUR), cal.get(Calendar.MINUTE), cal.get(Calendar.SECOND),
                        HAND_COLORS[nearestHand(n.handColor)])
                }
            }
        }
    }
}

/**
 * Renders [node] at the widget's real dp size, then scales the whole thing uniformly to fit the
 * available width (by overriding LocalDensity), so spacing, text and bitmaps match the installed widget.
 */
@Composable
fun WidgetPreview(
    node: N, wDp: Float, hDp: Float, phase: State<Float>, nowMs: Long,
    modifier: Modifier = Modifier, maxHeight: Dp = Dp.Unspecified
) {
    BoxWithConstraints(modifier) {
        val base = LocalDensity.current
        var s = maxWidth.value / wDp
        if (maxHeight != Dp.Unspecified) s = minOf(s, maxHeight.value / hDp)
        if (s.isNaN() || s <= 0f) s = 1f
        CompositionLocalProvider(LocalDensity provides Density(base.density * s, base.fontScale)) {
            Box(Modifier.size(wDp.dp, hDp.dp).clipToBounds()) { NodeView(node, phase, nowMs) }
        }
    }
}
