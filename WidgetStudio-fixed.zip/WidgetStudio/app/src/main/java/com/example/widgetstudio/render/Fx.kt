package com.example.widgetstudio.render

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import com.example.widgetstudio.core.Effect
import com.example.widgetstudio.core.IconKind
import com.example.widgetstudio.core.WidgetConfig
import com.example.widgetstudio.core.lerpColor
import com.example.widgetstudio.core.luminance
import com.example.widgetstudio.core.withAlpha
import com.example.widgetstudio.core.withAlphaInt
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/*
 * Reusable visual-effects system. Everything here is plain android.graphics so the exact same
 * code runs (a) into a cached Bitmap for the home-screen widget, (b) straight into a Compose canvas
 * for previews, and (c) into the live wallpaper. No BlurMaskFilter: glows are layered strokes and
 * radial gradients, which look identical on software bitmaps and hardware canvases.
 */

private const val TWO_PI = (2.0 * PI).toFloat()
private const val INK = 0xFF10131A.toInt()
private const val WHITE = 0xFFFFFFFF.toInt()
private fun white(a: Float) = WHITE.withAlpha(a)

internal fun pnt(color: Int = 0, style: Paint.Style = Paint.Style.FILL, sw: Float = 0f, cap: Paint.Cap = Paint.Cap.BUTT): Paint =
    Paint(Paint.ANTI_ALIAS_FLAG).also { it.color = color; it.style = style; it.strokeWidth = sw; it.strokeCap = cap }

/** Neon-style glow built from concentric translucent strokes. */
internal fun glowStroke(c: Canvas, path: Path, color: Int, glow: Float, d: Float, pulse: Float = 1f) {
    val p = pnt(style = Paint.Style.STROKE)
    p.strokeJoin = Paint.Join.ROUND
    for (i in 6 downTo 1) {
        p.strokeWidth = (1.2f + i * 1.5f) * d * (0.5f + glow)
        p.color = color.withAlpha(glow * pulse * 0.20f / (i * 0.55f + 0.45f))
        c.drawPath(path, p)
    }
}

// ================================================================================================
// Background: gradient + transparency + glass + light + neon + HUD + pulse
// ================================================================================================
data class BgStyle(
    val bg: Int, val bg2: Int, val gradient: Boolean, val angle: Int, val alpha: Float,
    val radius: Float, val glow: Float, val accent: Int, val effects: Set<Effect>
)

fun WidgetConfig.bgStyle() = BgStyle(bg, bg2, gradient, gradientAngle, alpha, radius, glow, accent, effects)

data class BgPainter(val s: BgStyle) : Painter {
    override fun paint(c: Canvas, w: Float, h: Float, d: Float, phase: Float) {
        val neon = Effect.NEON in s.effects
        val glass = Effect.GLASS in s.effects
        val pulse = if (Effect.PULSE in s.effects) 0.7f + 0.3f * sin(TWO_PI * phase) else 1f
        val inset = (if (neon) 2f + 6f * s.glow else 1f) * d
        val r = RectF(inset, inset, w - inset, h - inset)
        if (r.width() <= 2f || r.height() <= 2f) return
        val rad = min(s.radius * d, min(r.width(), r.height()) / 2f)
        val path = Path().apply { addRoundRect(r, rad, rad, Path.Direction.CW) }
        val a = (s.alpha.coerceIn(0f, 1f) * 255f).toInt()

        val base = pnt()
        if (s.gradient) {
            val ang = Math.toRadians(s.angle.toDouble())
            val dx = cos(ang).toFloat(); val dy = sin(ang).toFloat()
            val half = (abs(dx) * r.width() + abs(dy) * r.height()) / 2f
            base.shader = LinearGradient(
                r.centerX() - dx * half, r.centerY() - dy * half, r.centerX() + dx * half, r.centerY() + dy * half,
                s.bg.withAlphaInt(a), s.bg2.withAlphaInt(a), Shader.TileMode.CLAMP
            )
        } else base.color = s.bg.withAlphaInt(a)
        c.drawPath(path, base)

        c.save()
        c.clipPath(path)
        val big = max(r.width(), r.height())
        if (glass) {
            val g = pnt()
            g.shader = LinearGradient(0f, r.top, 0f, r.bottom, white(0.17f), white(0.03f), Shader.TileMode.CLAMP)
            c.drawPath(path, g)
            val gl = pnt()
            gl.shader = LinearGradient(0f, r.top, 0f, r.top + r.height() * 0.5f, white(0.12f), white(0f), Shader.TileMode.CLAMP)
            c.drawRect(r.left, r.top, r.right, r.top + r.height() * 0.5f, gl)
        }
        if (Effect.LIGHT in s.effects) {
            val x = r.left + r.width() * (0.5f + 0.35f * sin(TWO_PI * phase))
            val lg = pnt()
            lg.shader = RadialGradient(x, r.top, big * 0.9f, s.accent.withAlpha(0.14f + 0.30f * s.glow), s.accent.withAlpha(0f), Shader.TileMode.CLAMP)
            c.drawRect(r, lg)
        }
        if (s.glow > 0.02f) {
            val ag = pnt()
            ag.shader = RadialGradient(r.right, r.bottom, big * 0.75f, s.accent.withAlpha((0.05f + 0.22f * s.glow) * pulse), s.accent.withAlpha(0f), Shader.TileMode.CLAMP)
            c.drawRect(r, ag)
        }
        if (Effect.PULSE in s.effects && !neon) glowStroke(c, path, s.accent, s.glow * 0.8f, d, pulse)
        c.restore()

        val rim = pnt(style = Paint.Style.STROKE, sw = (if (glass) 1.2f else 0.8f) * d)
        rim.shader = LinearGradient(r.left, r.top, r.right, r.bottom, white(if (glass) 0.5f else 0.2f), white(0.04f), Shader.TileMode.CLAMP)
        c.drawPath(path, rim)

        if (neon) {
            glowStroke(c, path, s.accent, s.glow, d, pulse)
            c.drawPath(path, pnt(s.accent.withAlpha(0.95f), Paint.Style.STROKE, 1.4f * d))
        }
        if (Effect.HUD in s.effects) drawHud(c, r, rad, s.accent, d)
    }

    private fun drawHud(c: Canvas, r: RectF, rad: Float, accent: Int, d: Float) {
        val e = max(6f * d, rad * 0.35f)
        val len = 12f * d
        val p = pnt(accent.withAlpha(0.85f), Paint.Style.STROKE, 1.5f * d, Paint.Cap.ROUND)
        val l = r.left + e; val t = r.top + e; val rr = r.right - e; val b = r.bottom - e
        val path = Path()
        path.moveTo(l, t + len); path.lineTo(l, t); path.lineTo(l + len, t)
        path.moveTo(rr - len, t); path.lineTo(rr, t); path.lineTo(rr, t + len)
        path.moveTo(l, b - len); path.lineTo(l, b); path.lineTo(l + len, b)
        path.moveTo(rr - len, b); path.lineTo(rr, b); path.lineTo(rr, b - len)
        c.drawPath(path, p)
        if (r.width() > 130f * d) {
            val tp = pnt(accent.withAlpha(0.3f), Paint.Style.STROKE, 1f * d, Paint.Cap.ROUND)
            for (i in -7..7) {
                val x = r.centerX() + i * 4f * d
                val hh = if (i % 5 == 0) 3.5f * d else 1.8f * d
                c.drawLine(x, r.top + e * 0.55f, x, r.top + e * 0.55f + hh, tp)
            }
        }
    }
}

/** Generic rounded panel / pill / tile with optional neon edge. radiusDp < 0 => fully round. */
data class PanelPainter(
    val fill: Int, val fill2: Int, val radiusDp: Float,
    val stroke: Int = 0, val strokeDp: Float = 1f, val glowColor: Int = 0, val glow: Float = 0f
) : Painter {
    override fun paint(c: Canvas, w: Float, h: Float, d: Float, phase: Float) {
        val inset = (if (glow > 0f) 1f + 5f * glow else 0.5f) * d
        val r = RectF(inset, inset, w - inset, h - inset)
        if (r.width() <= 1f || r.height() <= 1f) return
        val rad = if (radiusDp < 0f) min(r.width(), r.height()) / 2f else min(radiusDp * d, min(r.width(), r.height()) / 2f)
        val p = pnt()
        p.shader = LinearGradient(0f, r.top, 0f, r.bottom, fill, fill2, Shader.TileMode.CLAMP)
        c.drawRoundRect(r, rad, rad, p)
        if (glow > 0f && glowColor != 0) {
            val path = Path().apply { addRoundRect(r, rad, rad, Path.Direction.CW) }
            glowStroke(c, path, glowColor, glow, d)
        }
        if (stroke != 0) c.drawRoundRect(r, rad, rad, pnt(stroke, Paint.Style.STROKE, strokeDp * d))
    }
}

/** Soft radial blob. Used under live TextClocks to fake neon text glow without redrawing text. */
data class GlowPainter(val color: Int, val intensity: Float) : Painter {
    override fun paint(c: Canvas, w: Float, h: Float, d: Float, phase: Float) {
        val p = pnt()
        val rad = max(w, h) / 2f
        p.shader = RadialGradient(w / 2f, h / 2f, rad, color.withAlpha(0.55f * intensity), color.withAlpha(0f), Shader.TileMode.CLAMP)
        c.save()
        c.scale(1f, h / w, w / 2f, h / 2f)
        c.drawCircle(w / 2f, h / 2f, rad, p)
        c.restore()
    }
}

// ================================================================================================
// Gauges: ring, liquid, cells / bar
// ================================================================================================
data class RingPainter(
    val pct: Int, val c1: Int, val c2: Int, val strokeDp: Float, val track: Int,
    val glow: Float = 0.5f, val segments: Int = 0
) : Painter {
    override fun paint(c: Canvas, w: Float, h: Float, d: Float, phase: Float) {
        val sw = strokeDp * d
        val pad = sw / 2f + glow * 3f * d
        val cx = w / 2f; val cy = h / 2f
        val rad = min(w, h) / 2f - pad
        if (rad <= 2f) return
        val oval = RectF(cx - rad, cy - rad, cx + rad, cy + rad)
        val p = pct.coerceIn(0, 100)
        if (segments > 0) {
            val step = 360f / segments
            val gapDeg = min(step * 0.3f, 8f)
            val lit = ceil(p / 100f * segments).toInt()
            val sp = pnt(style = Paint.Style.STROKE, sw = sw)
            for (i in 0 until segments) {
                sp.color = if (i < lit) lerpColor(c1, c2, i / max(1f, segments - 1f)) else track
                c.drawArc(oval, -90f + i * step + gapDeg / 2f, step - gapDeg, false, sp)
            }
            return
        }
        c.drawCircle(cx, cy, rad, pnt(track, Paint.Style.STROKE, sw))
        if (p <= 0) return
        val sweep = 360f * p / 100f
        if (glow > 0.02f) {
            for (i in 4 downTo 1) {
                val g = pnt(c1.withAlpha(glow * 0.16f / (i * 0.7f)), Paint.Style.STROKE, sw + i * 2.4f * d * (0.4f + glow), Paint.Cap.ROUND)
                c.drawArc(oval, -90f, sweep, false, g)
            }
        }
        val gp = pnt(style = Paint.Style.STROKE, sw = sw, cap = Paint.Cap.ROUND)
        val sg = SweepGradient(cx, cy, intArrayOf(c1, c2, c1), floatArrayOf(0f, p / 100f, 1f))
        sg.setLocalMatrix(Matrix().apply { postRotate(-90f, cx, cy) })
        gp.shader = sg
        c.drawArc(oval, -90f, sweep, false, gp)
    }
}

/** Liquid fill (battery / storage). Surface waves animate with [phase] in Live Preview; static on the home screen. */
data class LiquidPainter(
    val pct: Int, val c1: Int, val c2: Int, val rim: Int, val glow: Float = 0.5f,
    val shape: Int = 0, val cornerDp: Float = 18f
) : Painter {
    override fun paint(c: Canvas, w: Float, h: Float, d: Float, phase: Float) {
        val sw = 2f * d
        val inset = sw + glow * 3f * d
        val r = RectF(inset, inset, w - inset, h - inset)
        if (r.width() <= 4f || r.height() <= 4f) return
        val cont = Path()
        if (shape == 0) cont.addOval(r, Path.Direction.CW) else cont.addRoundRect(r, cornerDp * d, cornerDp * d, Path.Direction.CW)
        c.drawPath(cont, pnt(white(0.07f)))
        val p = pct.coerceIn(0, 100) / 100f
        val level = r.bottom - p * r.height()
        val amp = if (p in 0.02f..0.98f) 2.6f * d else 0f
        c.save()
        c.clipPath(cont)
        for (layer in 0..1) {
            val path = Path()
            val step = max(3f * d, r.width() / 40f)
            fun y(x: Float) = level + amp * sin(TWO_PI * (1.4f * (x - r.left) / r.width() + phase + layer * 0.35f))
            path.moveTo(r.left, r.bottom)
            path.lineTo(r.left, y(r.left))
            var x = r.left + step
            while (x < r.right) { path.lineTo(x, y(x)); x += step }
            path.lineTo(r.right, y(r.right))
            path.lineTo(r.right, r.bottom)
            path.close()
            val fp = pnt()
            val a = if (layer == 0) 0.5f else 0.95f
            fp.shader = LinearGradient(0f, level - amp, 0f, r.bottom, c1.withAlpha(a), c2.withAlpha(a), Shader.TileMode.CLAMP)
            c.drawPath(path, fp)
        }
        c.restore()
        if (glow > 0.02f) glowStroke(c, cont, rim, glow * 0.7f, d)
        c.drawPath(cont, pnt(rim.withAlpha(0.9f), Paint.Style.STROKE, sw))
    }
}

/** Segmented "battery cell" bar (segments > 0) or smooth glowing bar (segments == 0). */
data class CellsPainter(
    val pct: Int, val segments: Int, val c1: Int, val c2: Int, val track: Int,
    val radiusDp: Float = 3f, val glow: Float = 0f
) : Painter {
    override fun paint(c: Canvas, w: Float, h: Float, d: Float, phase: Float) {
        val pad = glow * 2f * d
        val p = pct.coerceIn(0, 100) / 100f
        val rad = min(radiusDp * d, (h - 2 * pad) / 2f)
        if (segments <= 0) {
            val tr = RectF(pad, pad, w - pad, h - pad)
            c.drawRoundRect(tr, rad, rad, pnt(track))
            if (p > 0f) {
                val fr = RectF(tr.left, tr.top, tr.left + max(tr.height(), tr.width() * p), tr.bottom)
                if (glow > 0f) {
                    for (i in 3 downTo 1) c.drawRoundRect(
                        RectF(fr.left - i * d, fr.top - i * d, fr.right + i * d, fr.bottom + i * d), rad + i * d, rad + i * d,
                        pnt(c1.withAlpha(glow * 0.14f))
                    )
                }
                val fp = pnt()
                fp.shader = LinearGradient(fr.left, 0f, max(fr.right, fr.left + 1f), 0f, c1, c2, Shader.TileMode.CLAMP)
                c.drawRoundRect(fr, rad, rad, fp)
            }
            return
        }
        val gap = 2.5f * d
        val sw = (w - gap * (segments - 1)) / segments
        val lit = ceil(p * segments).toInt()
        for (i in 0 until segments) {
            val x = i * (sw + gap)
            val rc = RectF(x, pad, x + sw, h - pad)
            val on = i < lit
            val fp = pnt(if (on) lerpColor(c1, c2, i / max(1f, segments - 1f)) else track)
            if (on && glow > 0f) c.drawRoundRect(RectF(rc.left - d, rc.top - d, rc.right + d, rc.bottom + d), rad + d, rad + d, pnt(fp.color.withAlpha(glow * 0.2f)))
            c.drawRoundRect(rc, rad, rad, fp)
        }
    }
}

/** Waveform visualiser. Bars are deterministic from [seed]; they animate with [phase] when [animated]. */
data class WavePainter(
    val seed: Int, val bars: Int, val c1: Int, val c2: Int, val minH: Float = 0.12f, val animated: Boolean = true
) : Painter {
    override fun paint(c: Canvas, w: Float, h: Float, d: Float, phase: Float) {
        if (bars < 2) return
        val slot = w / bars
        val bw = slot * 0.55f
        val p = pnt(style = Paint.Style.STROKE, sw = bw, cap = Paint.Cap.ROUND)
        val ph = if (animated) phase * TWO_PI else 0f
        for (i in 0 until bars) {
            val t = i / (bars - 1f)
            val env = sin(PI.toFloat() * t).pow(0.5f)
            val v = abs(sin(i * 0.9f + seed * 0.37f) * cos(i * 0.37f + seed + ph))
            val hh = (h * (minH + (1f - minH) * (0.25f + 0.75f * v) * env)).coerceIn(bw, h)
            val x = slot * (i + 0.5f)
            p.color = lerpColor(c1, c2, t)
            c.drawLine(x, h / 2f - (hh - bw) / 2f, x, h / 2f + (hh - bw) / 2f, p)
        }
    }
}

/** Half-circle sun path with a sun marker at [pct] (0..100) of the day; pct < 0 => below horizon. */
data class SunArcPainter(val pct: Int, val color: Int, val track: Int, val glow: Float = 0.5f) : Painter {
    override fun paint(c: Canvas, w: Float, h: Float, d: Float, phase: Float) {
        val sw = 2.2f * d
        val pad = 8f * d
        val rad = min((w - 2 * pad) / 2f, h - pad - sw)
        if (rad <= 4f) return
        val cx = w / 2f; val cy = h - pad
        val oval = RectF(cx - rad, cy - rad, cx + rad, cy + rad)
        c.drawLine(pad * 0.5f, cy, w - pad * 0.5f, cy, pnt(track, Paint.Style.STROKE, 1f * d))
        val dash = pnt(track, Paint.Style.STROKE, sw, Paint.Cap.ROUND)
        c.drawArc(oval, 180f, 180f, false, dash)
        if (pct >= 0) {
            val sweep = 180f * pct.coerceIn(0, 100) / 100f
            c.drawArc(oval, 180f, sweep, false, pnt(color.withAlpha(0.9f), Paint.Style.STROKE, sw, Paint.Cap.ROUND))
            val ang = Math.toRadians((180.0 + sweep))
            val sx = cx + rad * cos(ang).toFloat(); val sy = cy + rad * sin(ang).toFloat()
            for (i in 4 downTo 1) c.drawCircle(sx, sy, (4f + i * 2.2f) * d, pnt(color.withAlpha(glow * 0.12f)))
            c.drawCircle(sx, sy, 4.5f * d, pnt(color))
        }
    }
}

// ================================================================================================
// Icons (24-unit grid) and weather glyphs
// ================================================================================================
data class IconPainter(val kind: IconKind, val color: Int, val sw: Float = 2f) : Painter {
    override fun paint(c: Canvas, w: Float, h: Float, d: Float, phase: Float) {
        val s = min(w, h) / 24f
        c.save()
        c.translate((w - 24f * s) / 2f, (h - 24f * s) / 2f)
        c.scale(s, s)
        val f = pnt(color)
        val st = pnt(color, Paint.Style.STROKE, sw, Paint.Cap.ROUND).also { it.strokeJoin = Paint.Join.ROUND }
        fun poly(vararg v: Float, close: Boolean = true): Path = Path().also { p ->
            p.moveTo(v[0], v[1]); var i = 2
            while (i < v.size) { p.lineTo(v[i], v[i + 1]); i += 2 }
            if (close) p.close()
        }
        fun rr(l: Float, t: Float, r: Float, b: Float, rad: Float, paint: Paint) = c.drawRoundRect(RectF(l, t, r, b), rad, rad, paint)
        when (kind) {
            IconKind.HOME -> c.drawPath(poly(12f, 3f, 3f, 11f, 5.5f, 11f, 5.5f, 20f, 10f, 20f, 10f, 14f, 14f, 14f, 14f, 20f, 18.5f, 20f, 18.5f, 11f, 21f, 11f), f)
            IconKind.GRID -> { rr(3f, 3f, 10.5f, 10.5f, 2.2f, f); rr(13.5f, 3f, 21f, 10.5f, 2.2f, f); rr(3f, 13.5f, 10.5f, 21f, 2.2f, f); rr(13.5f, 13.5f, 21f, 21f, 2.2f, f) }
            IconKind.HEART, IconKind.HEART_O -> {
                val p = Path()
                p.moveTo(12f, 21f); p.cubicTo(5f, 15f, 3f, 11.5f, 3f, 8.5f); p.cubicTo(3f, 5.8f, 5f, 4f, 7.5f, 4f)
                p.cubicTo(9.4f, 4f, 11f, 5f, 12f, 6.6f); p.cubicTo(13f, 5f, 14.6f, 4f, 16.5f, 4f)
                p.cubicTo(19f, 4f, 21f, 5.8f, 21f, 8.5f); p.cubicTo(21f, 11.5f, 19f, 15f, 12f, 21f); p.close()
                c.drawPath(p, if (kind == IconKind.HEART) f else st)
            }
            IconKind.WIDGET -> { rr(3f, 3f, 11f, 11f, 2.2f, f); rr(13f, 3f, 21f, 8f, 2.2f, f); rr(13f, 10f, 21f, 21f, 2.2f, f); rr(3f, 13f, 11f, 21f, 2.2f, f) }
            IconKind.GEAR -> {
                c.drawCircle(12f, 12f, 5.5f, st)
                for (i in 0 until 8) {
                    val a = i * PI / 4
                    c.drawLine(12f + 8f * cos(a).toFloat(), 12f + 8f * sin(a).toFloat(), 12f + 10.5f * cos(a).toFloat(), 12f + 10.5f * sin(a).toFloat(), st)
                }
                c.drawCircle(12f, 12f, 1.8f, f)
            }
            IconKind.SEARCH -> { c.drawCircle(10.5f, 10.5f, 6.5f, st); c.drawLine(15.5f, 15.5f, 21f, 21f, st) }
            IconKind.PLUS -> { c.drawLine(12f, 4f, 12f, 20f, st); c.drawLine(4f, 12f, 20f, 12f, st) }
            IconKind.CHECK -> c.drawPath(poly(5f, 12.5f, 10f, 17.5f, 19f, 7f, close = false), st)
            IconKind.CLOSE -> { c.drawLine(6f, 6f, 18f, 18f, st); c.drawLine(18f, 6f, 6f, 18f, st) }
            IconKind.PLAY -> c.drawPath(poly(7f, 4f, 19f, 12f, 7f, 20f), f)
            IconKind.PAUSE -> { rr(6f, 4f, 10f, 20f, 1.5f, f); rr(14f, 4f, 18f, 20f, 1.5f, f) }
            IconKind.NEXT -> { c.drawPath(poly(5f, 5f, 15f, 12f, 5f, 19f), f); rr(16.5f, 5f, 19.5f, 19f, 1.2f, f) }
            IconKind.PREV -> { c.drawPath(poly(19f, 5f, 9f, 12f, 19f, 19f), f); rr(4.5f, 5f, 7.5f, 19f, 1.2f, f) }
            IconKind.BOLT -> c.drawPath(poly(13f, 2f, 4.5f, 13.5f, 10.5f, 13.5f, 9.5f, 22f, 19.5f, 9.5f, 13.5f, 9.5f), f)
            IconKind.BATTERY -> { rr(2.5f, 7f, 19f, 17f, 2.5f, st); rr(20f, 10f, 22f, 14f, 1f, f); rr(5f, 9.5f, 12f, 14.5f, 1f, f) }
            IconKind.CLOCK -> { c.drawCircle(12f, 12f, 9f, st); c.drawLine(12f, 12f, 12f, 6.5f, st); c.drawLine(12f, 12f, 16f, 14f, st) }
            IconKind.DIAL -> {
                c.drawCircle(12f, 12f, 9.5f, st)
                for (i in 0 until 4) { val a = i * PI / 2; c.drawLine(12f + 6.5f * cos(a).toFloat(), 12f + 6.5f * sin(a).toFloat(), 12f + 8f * cos(a).toFloat(), 12f + 8f * sin(a).toFloat(), st) }
                c.drawLine(12f, 12f, 12f, 7.5f, st); c.drawLine(12f, 12f, 15.5f, 12f, st)
            }
            IconKind.RADAR -> { c.drawCircle(12f, 12f, 9.5f, st); c.drawCircle(12f, 12f, 4.8f, st); c.drawLine(12f, 12f, 18.5f, 5.5f, st); c.drawCircle(12f, 12f, 1.3f, f) }
            IconKind.SUN -> {
                c.drawCircle(12f, 12f, 4.3f, f)
                for (i in 0 until 8) { val a = i * PI / 4; c.drawLine(12f + 7.4f * cos(a).toFloat(), 12f + 7.4f * sin(a).toFloat(), 12f + 9.8f * cos(a).toFloat(), 12f + 9.8f * sin(a).toFloat(), st) }
            }
            IconKind.MOON -> {
                val a = Path().apply { addCircle(12f, 12f, 8.5f, Path.Direction.CW) }
                val b = Path().apply { addCircle(16.5f, 9f, 7.5f, Path.Direction.CW) }
                a.op(b, Path.Op.DIFFERENCE); c.drawPath(a, f)
            }
            IconKind.CLOUD -> { c.drawCircle(8.5f, 14f, 4.2f, f); c.drawCircle(13.5f, 11f, 5.4f, f); c.drawCircle(17.8f, 15f, 3.6f, f); rr(8.5f, 13f, 17.8f, 18.6f, 1f, f) }
            IconKind.MUSIC -> { c.drawCircle(8f, 18f, 3f, f); c.drawLine(11f, 18f, 11f, 5f, st); c.drawLine(11f, 5f, 18f, 7.5f, st) }
            IconKind.CALENDAR -> { rr(3.5f, 5f, 20.5f, 20.5f, 3f, st); c.drawLine(3.5f, 10.5f, 20.5f, 10.5f, st); c.drawLine(8f, 3f, 8f, 7f, st); c.drawLine(16f, 3f, 16f, 7f, st) }
            IconKind.TIMER -> { c.drawCircle(12f, 13.5f, 8f, st); c.drawLine(9.5f, 2.8f, 14.5f, 2.8f, st); c.drawLine(12f, 13.5f, 12f, 9f, st) }
            IconKind.CHIP -> {
                rr(6.5f, 6.5f, 17.5f, 17.5f, 2f, st)
                for (i in 0 until 3) { val o = 9f + i * 3f; c.drawLine(o, 3f, o, 6.5f, st); c.drawLine(o, 17.5f, o, 21f, st); c.drawLine(3f, o, 6.5f, o, st); c.drawLine(17.5f, o, 21f, o, st) }
            }
            IconKind.STORAGE -> { rr(3.5f, 4f, 20.5f, 10.5f, 2.5f, st); rr(3.5f, 13.5f, 20.5f, 20f, 2.5f, st); c.drawCircle(7.5f, 7.2f, 1f, f); c.drawCircle(7.5f, 16.8f, 1f, f) }
            IconKind.DOT -> c.drawCircle(12f, 12f, 4.5f, f)
            IconKind.DIAMOND -> c.drawPath(poly(12f, 2.5f, 20.5f, 10f, 12f, 21.5f, 3.5f, 10f), st)
            IconKind.NOTE -> { rr(4.5f, 3.5f, 19.5f, 20.5f, 3f, st); c.drawLine(8f, 9f, 16f, 9f, st); c.drawLine(8f, 13f, 16f, 13f, st); c.drawLine(8f, 17f, 12f, 17f, st) }
            IconKind.WIFI -> {
                for (r in floatArrayOf(5f, 9f, 13f)) c.drawArc(RectF(12f - r, 19f - r, 12f + r, 19f + r), 225f, 90f, false, st)
                c.drawCircle(12f, 19f, 1.4f, f)
            }
            IconKind.BACK -> c.drawPath(poly(15f, 5f, 8f, 12f, 15f, 19f, close = false), st)
            IconKind.CHEVRON -> c.drawPath(poly(9f, 5f, 16f, 12f, 9f, 19f, close = false), st)
            IconKind.SPARKLE -> c.drawPath(poly(12f, 2f, 14.2f, 9.8f, 22f, 12f, 14.2f, 14.2f, 12f, 22f, 9.8f, 14.2f, 2f, 12f, 9.8f, 9.8f), f)
            IconKind.TRASH -> { c.drawLine(4f, 6.5f, 20f, 6.5f, st); rr(6f, 6.5f, 18f, 21f, 2f, st); c.drawLine(9.5f, 3f, 14.5f, 3f, st) }
            IconKind.EDIT -> c.drawPath(poly(4f, 20f, 5f, 15f, 16f, 4f, 20f, 8f, 9f, 19f), st)
            IconKind.EMPTY_BOX -> rr(4f, 4f, 20f, 20f, 5f, st)
        }
        c.restore()
    }
}

enum class WKind { CLEAR, NIGHT, PARTLY, CLOUD, FOG, RAIN, SNOW, STORM }

fun wKind(code: Int, isDay: Boolean): WKind = when (code) {
    0 -> if (isDay) WKind.CLEAR else WKind.NIGHT
    1, 2 -> WKind.PARTLY
    3 -> WKind.CLOUD
    45, 48 -> WKind.FOG
    51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82 -> WKind.RAIN
    71, 73, 75, 77, 85, 86 -> WKind.SNOW
    95, 96, 99 -> WKind.STORM
    else -> WKind.CLOUD
}

fun wLabel(code: Int): String = when (code) {
    0 -> "Clear"; 1 -> "Mostly clear"; 2 -> "Partly cloudy"; 3 -> "Overcast"; 45, 48 -> "Fog"
    51, 53, 55, 56, 57 -> "Drizzle"; 61, 63, 65, 66, 67 -> "Rain"; 71, 73, 75, 77 -> "Snow"
    80, 81, 82 -> "Showers"; 85, 86 -> "Snow showers"; 95, 96, 99 -> "Thunderstorm"; else -> "Cloudy"
}

data class WeatherPainter(val kind: WKind, val c1: Int, val c2: Int) : Painter {
    override fun paint(c: Canvas, w: Float, h: Float, d: Float, phase: Float) {
        val s = min(w, h) / 24f
        c.save(); c.translate((w - 24f * s) / 2f, (h - 24f * s) / 2f); c.scale(s, s)
        val sun = pnt(c1); val sunSt = pnt(c1, Paint.Style.STROKE, 1.7f, Paint.Cap.ROUND)
        val cl = pnt(c2); val clSt = pnt(c2.withAlpha(0.7f), Paint.Style.STROKE, 1.7f, Paint.Cap.ROUND)
        fun rays(cx: Float, cy: Float, r0: Float, r1: Float) {
            for (i in 0 until 8) { val a = i * PI / 4; c.drawLine(cx + r0 * cos(a).toFloat(), cy + r0 * sin(a).toFloat(), cx + r1 * cos(a).toFloat(), cy + r1 * sin(a).toFloat(), sunSt) }
        }
        fun cloud(cx: Float, cy: Float, k: Float) {
            c.drawCircle(cx - 4.2f * k, cy + 1.4f * k, 3.6f * k, cl); c.drawCircle(cx + 0.2f * k, cy - 1f * k, 4.8f * k, cl)
            c.drawCircle(cx + 4.6f * k, cy + 1.6f * k, 3.2f * k, cl)
            c.drawRoundRect(RectF(cx - 7.8f * k, cy + 1.2f * k, cx + 7.8f * k, cy + 5f * k), 1.8f * k, 1.8f * k, cl)
        }
        when (kind) {
            WKind.CLEAR -> { c.drawCircle(12f, 12f, 4.8f, sun); rays(12f, 12f, 7.6f, 10f) }
            WKind.NIGHT -> {
                val a = Path().apply { addCircle(12f, 12f, 8.5f, Path.Direction.CW) }
                a.op(Path().apply { addCircle(16.5f, 9f, 7.5f, Path.Direction.CW) }, Path.Op.DIFFERENCE); c.drawPath(a, sun)
            }
            WKind.PARTLY -> { c.drawCircle(16f, 8f, 3.6f, sun); rays(16f, 8f, 5.8f, 7.6f); cloud(11f, 14.5f, 0.85f) }
            WKind.CLOUD -> cloud(12f, 12.5f, 1.15f)
            WKind.FOG -> { cloud(12f, 9f, 0.9f); c.drawLine(5f, 17f, 19f, 17f, clSt); c.drawLine(7f, 20.5f, 17f, 20.5f, clSt) }
            WKind.RAIN -> { cloud(12f, 9f, 0.95f); for (x in floatArrayOf(7.5f, 12f, 16.5f)) c.drawLine(x, 16.5f, x - 1.6f, 21f, sunSt) }
            WKind.SNOW -> { cloud(12f, 9f, 0.95f); for (x in floatArrayOf(7.5f, 12f, 16.5f)) { c.drawCircle(x, 17f, 1.2f, sun); c.drawCircle(x - 0.8f, 21f, 1.2f, sun) } }
            WKind.STORM -> {
                cloud(12f, 8.5f, 0.95f)
                val b = Path(); b.moveTo(13f, 14f); b.lineTo(9f, 19.5f); b.lineTo(12f, 19.5f); b.lineTo(10.5f, 24f); b.lineTo(16f, 17.5f); b.lineTo(13f, 17.5f); b.close(); c.drawPath(b, sun)
            }
        }
        c.restore()
    }
}

// ================================================================================================
// Analog dial + hands, month grid, vinyl, synthwave sun, app icons
// ================================================================================================
private fun typeface(family: String) = Typeface.create(family, Typeface.NORMAL)

/** style 0 classic numerals, 1 minimal bars, 2 radar HUD. Hands are platform AnalogClock (see AnalogN). */
data class DialPainter(val style: Int, val color: Int, val accent: Int, val glow: Float, val family: String) : Painter {
    override fun paint(c: Canvas, w: Float, h: Float, d: Float, phase: Float) {
        val cx = w / 2f; val cy = h / 2f
        val r = min(w, h) / 2f - 2f * d - glow * 3f * d
        if (r < 8f) return
        when (style) {
            0 -> {
                val ring = Path().apply { addCircle(cx, cy, r, Path.Direction.CW) }
                if (glow > 0.05f) glowStroke(c, ring, accent, glow * 0.6f, d)
                c.drawPath(ring, pnt(color.withAlpha(0.9f), Paint.Style.STROKE, 1.6f * d))
                for (i in 0 until 60) {
                    val a = i * PI / 30; val major = i % 5 == 0
                    val r0 = if (major) r * 0.86f else r * 0.92f
                    c.drawLine(cx + r0 * cos(a).toFloat(), cy + r0 * sin(a).toFloat(), cx + r * 0.97f * cos(a).toFloat(), cy + r * 0.97f * sin(a).toFloat(),
                        pnt(color.withAlpha(if (major) 0.9f else 0.3f), Paint.Style.STROKE, (if (major) 1.6f else 0.8f) * d, Paint.Cap.ROUND))
                }
                val tp = pnt(color).also { it.textAlign = Paint.Align.CENTER; it.typeface = typeface(family); it.textSize = r * 0.19f }
                val off = -(tp.fontMetrics.ascent + tp.fontMetrics.descent) / 2f
                for (n in 1..12) {
                    val a = (n * 30 - 90) * PI / 180
                    c.drawText(n.toString(), cx + r * 0.7f * cos(a).toFloat(), cy + r * 0.7f * sin(a).toFloat() + off, tp)
                }
            }
            1 -> {
                for (i in 0 until 12) {
                    val a = i * PI / 6; val q = i % 3 == 0
                    c.drawLine(cx + r * (if (q) 0.8f else 0.88f) * cos(a).toFloat(), cy + r * (if (q) 0.8f else 0.88f) * sin(a).toFloat(),
                        cx + r * 0.97f * cos(a).toFloat(), cy + r * 0.97f * sin(a).toFloat(),
                        pnt(if (i == 0) accent else color.withAlpha(if (q) 0.9f else 0.45f), Paint.Style.STROKE, (if (q) 2.4f else 1.4f) * d, Paint.Cap.ROUND))
                }
            }
            else -> {
                for (k in floatArrayOf(1f, 0.72f, 0.44f)) c.drawCircle(cx, cy, r * k, pnt(accent.withAlpha(if (k == 1f) 0.8f else 0.28f), Paint.Style.STROKE, (if (k == 1f) 1.5f else 0.8f) * d))
                c.drawLine(cx - r, cy, cx + r, cy, pnt(accent.withAlpha(0.2f), Paint.Style.STROKE, 0.8f * d))
                c.drawLine(cx, cy - r, cx, cy + r, pnt(accent.withAlpha(0.2f), Paint.Style.STROKE, 0.8f * d))
                for (i in 0 until 60) {
                    val a = i * PI / 30; val major = i % 5 == 0
                    val r0 = r * (if (major) 0.9f else 0.95f)
                    c.drawLine(cx + r0 * cos(a).toFloat(), cy + r0 * sin(a).toFloat(), cx + r * cos(a).toFloat(), cy + r * sin(a).toFloat(),
                        pnt(color.withAlpha(if (major) 0.8f else 0.3f), Paint.Style.STROKE, 0.9f * d))
                }
                val tp = pnt(accent).also { it.textAlign = Paint.Align.CENTER; it.typeface = typeface("monospace"); it.textSize = r * 0.13f }
                val off = -(tp.fontMetrics.ascent + tp.fontMetrics.descent) / 2f
                val lab = arrayOf("N", "E", "S", "W")
                for (i in 0 until 4) { val a = (i * 90 - 90) * PI / 180; c.drawText(lab[i], cx + r * 0.8f * cos(a).toFloat(), cy + r * 0.8f * sin(a).toFloat() + off, tp) }
                val sweep = SweepGradient(cx, cy, intArrayOf(accent.withAlpha(0f), accent.withAlpha(0.35f * (0.4f + glow))), floatArrayOf(0.75f, 1f))
                sweep.setLocalMatrix(Matrix().apply { postRotate(phase * 360f - 90f + 40f, cx, cy) })
                c.drawCircle(cx, cy, r * 0.72f, pnt().also { it.shader = sweep })
            }
        }
    }
}

/** Same geometry as the vector hands in res/drawable (viewport 200: hour tip 48 / tail 108, minute tip 18 / tail 112). Preview only. */
fun drawHands(c: Canvas, size: Float, hour: Int, minute: Int, second: Int, color: Int) {
    val u = size / 200f
    val cx = size / 2f; val cy = size / 2f
    val hAng = ((hour % 12) + minute / 60f) * 30f
    val mAng = (minute + second / 60f) * 6f
    c.save(); c.rotate(hAng, cx, cy)
    c.drawLine(cx, cy + 8f * u, cx, cy - 52f * u, pnt(color, Paint.Style.STROKE, 7f * u, Paint.Cap.ROUND)); c.restore()
    c.save(); c.rotate(mAng, cx, cy)
    c.drawLine(cx, cy + 12f * u, cx, cy - 82f * u, pnt(color, Paint.Style.STROKE, 3.6f * u, Paint.Cap.ROUND)); c.restore()
    c.drawCircle(cx, cy, 5.5f * u, pnt(color))
}

data class MonthPainter(
    val offset: Int, val days: Int, val today: Int, val fg: Int, val accent: Int,
    val family: String, val sundayFirst: Boolean
) : Painter {
    override fun paint(c: Canvas, w: Float, h: Float, d: Float, phase: Float) {
        val weeks = ceil((offset + days) / 7f).toInt()
        val cw = w / 7f; val ch = h / (weeks + 1)
        val tp = pnt(fg).also { it.textAlign = Paint.Align.CENTER; it.typeface = typeface(family); it.textSize = min(cw, ch) * 0.46f }
        val off = -(tp.fontMetrics.ascent + tp.fontMetrics.descent) / 2f
        val head = if (sundayFirst) "SMTWTFS" else "MTWTFSS"
        val hp = pnt(accent.withAlpha(0.9f)).also { it.textAlign = Paint.Align.CENTER; it.typeface = typeface("sans-serif-medium"); it.textSize = min(cw, ch) * 0.38f }
        for (i in 0 until 7) c.drawText(head[i].toString(), cw * (i + 0.5f), ch * 0.5f + off, hp)
        val onAccent = if (luminance(accent) > 0.4f) INK else WHITE
        for (day in 1..days) {
            val idx = offset + day - 1
            val col = idx % 7; val rowI = idx / 7 + 1
            val x = cw * (col + 0.5f); val y = ch * (rowI + 0.5f)
            val weekend = if (sundayFirst) (col == 0 || col == 6) else (col >= 5)
            if (day == today) {
                c.drawCircle(x, y, min(cw, ch) * 0.46f, pnt(accent))
                tp.color = onAccent
            } else tp.color = fg.withAlpha(if (weekend) 0.55f else 0.92f)
            c.drawText(day.toString(), x, y + off, tp)
        }
    }
}

data class VinylPainter(val color: Int, val accent: Int, val spinning: Boolean, val glow: Float) : Painter {
    override fun paint(c: Canvas, w: Float, h: Float, d: Float, phase: Float) {
        val cx = w / 2f; val cy = h / 2f
        val r = min(w, h) / 2f - 2f * d - glow * 3f * d
        if (r < 6f) return
        val disc = Path().apply { addCircle(cx, cy, r, Path.Direction.CW) }
        if (glow > 0.05f) glowStroke(c, disc, accent, glow * 0.6f, d)
        c.drawCircle(cx, cy, r, pnt(0xFF0A0C12.toInt()))
        for (i in 1..7) c.drawCircle(cx, cy, r * (0.34f + i * 0.085f), pnt(white(0.05f), Paint.Style.STROKE, 0.8f * d))
        val rot = if (spinning) phase * 360f else 0f
        val sh = SweepGradient(cx, cy, intArrayOf(white(0f), white(0.16f), white(0f), white(0f), white(0.12f), white(0f)), floatArrayOf(0f, 0.08f, 0.2f, 0.5f, 0.58f, 0.7f))
        sh.setLocalMatrix(Matrix().apply { postRotate(rot, cx, cy) })
        c.drawCircle(cx, cy, r, pnt().also { it.shader = sh })
        c.drawCircle(cx, cy, r * 0.3f, pnt(accent))
        c.drawCircle(cx, cy, r * 0.3f, pnt(white(0.2f), Paint.Style.STROKE, 1f * d))
        c.drawCircle(cx, cy, r * 0.055f, pnt(0xFF0A0C12.toInt()))
    }
}

/** Retro sunset disc with scan-line gaps and a perspective grid floor. */
data class SynthPainter(val c1: Int, val c2: Int, val grid: Int, val glow: Float) : Painter {
    override fun paint(c: Canvas, w: Float, h: Float, d: Float, phase: Float) {
        val horizon = h * 0.62f
        val rad = min(w * 0.36f, horizon - 4f * d)
        val cx = w / 2f
        val cy = horizon - rad * 0.12f
        c.drawCircle(cx, cy, rad * 1.18f, pnt().also { it.shader = RadialGradient(cx, cy, rad * 1.18f, c1.withAlpha(0.28f * glow + 0.06f), c1.withAlpha(0f), Shader.TileMode.CLAMP) })
        val sunPaint = pnt().also { it.shader = LinearGradient(0f, cy - rad, 0f, cy + rad, c2, c1, Shader.TileMode.CLAMP) }
        val top = min(horizon, cy + rad * 0.05f)
        c.save(); c.clipRect(0f, 0f, w, top); c.drawCircle(cx, cy, rad, sunPaint); c.restore()
        var y = cy + rad * 0.05f
        for (i in 0 until 5) {
            val gapH = (1f + i * 0.5f) * d
            val bandH = rad * 0.17f - gapH
            if (bandH > 0f && y + gapH < horizon) {
                c.save(); c.clipRect(0f, y + gapH, w, min(y + gapH + bandH, horizon)); c.drawCircle(cx, cy, rad, sunPaint); c.restore()
            }
            y += rad * 0.17f
        }
        val lp = pnt(grid.withAlpha(0.7f), Paint.Style.STROKE, 1f * d)
        c.drawLine(0f, horizon, w, horizon, lp)
        for (i in 1..4) { val y = horizon + (h - horizon) * (i / 4f).pow(1.8f); c.drawLine(0f, y, w, y, lp) }
        for (i in -5..5) c.drawLine(cx + i * w * 0.03f, horizon, cx + i * w * 0.22f, h, lp)
    }
}

class AppIconPainter(val pkg: String, val bmp: Bitmap?, val shape: Int, val plate: Int) : Painter {
    override fun paint(c: Canvas, w: Float, h: Float, d: Float, phase: Float) {
        val side = min(w, h)
        val r = RectF((w - side) / 2f, (h - side) / 2f, (w + side) / 2f, (h + side) / 2f)
        val rad = when (shape) { 0 -> side * 0.28f; 1 -> side / 2f; 2 -> side * 0.08f; else -> 0f }
        val clip = Path().apply { addRoundRect(r, rad, rad, Path.Direction.CW) }
        c.save()
        if (shape != 3) {
            c.clipPath(clip)
            c.drawPath(clip, pnt(plate))
        }
        if (bmp != null) {
            val inner = if (shape == 3) r else RectF(r.left + side * 0.08f, r.top + side * 0.08f, r.right - side * 0.08f, r.bottom - side * 0.08f)
            c.drawBitmap(bmp, null, inner, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
        } else {
            c.drawPath(Path().apply { addCircle(r.centerX(), r.centerY(), side * 0.18f, Path.Direction.CW) }, pnt(white(0.35f)))
        }
        c.restore()
    }
    override fun equals(other: Any?) = other is AppIconPainter && other.pkg == pkg && other.bmp === bmp && other.shape == shape && other.plate == plate
    override fun hashCode() = (pkg.hashCode() * 31 + shape) * 31 + plate
}
