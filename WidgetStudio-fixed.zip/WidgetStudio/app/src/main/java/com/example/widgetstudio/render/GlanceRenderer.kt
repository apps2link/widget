package com.example.widgetstudio.render

import android.content.Context
import android.util.TypedValue
import android.widget.RemoteViews
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp
import androidx.glance.GlanceModifier
import androidx.glance.Image
import androidx.glance.ImageProvider
import androidx.glance.action.Action
import androidx.glance.action.actionParametersOf
import androidx.glance.action.clickable
import androidx.glance.appwidget.AndroidRemoteViews
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.ColumnScope
import androidx.glance.layout.ContentScale
import androidx.glance.layout.Row
import androidx.glance.layout.RowScope
import androidx.glance.layout.fillMaxHeight
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.width
import androidx.glance.ColorFilter
import androidx.glance.unit.ColorProvider
import androidx.compose.ui.graphics.Color
import com.example.widgetstudio.R
import com.example.widgetstudio.core.FontKey
import com.example.widgetstudio.util.Launch
import com.example.widgetstudio.widgets.KeyCodeKey
import com.example.widgetstudio.widgets.MediaKeyCallback
import com.example.widgetstudio.widgets.TaskIdKey
import com.example.widgetstudio.widgets.ToggleTaskCallback

class GEnv(val ctx: Context, val density: Float, val wDp: Float, val hDp: Float)

private fun textLayout(f: FontKey, multi: Boolean): Int = if (!multi) when (f) {
    FontKey.SANS -> R.layout.t_sans; FontKey.LIGHT -> R.layout.t_light; FontKey.THIN -> R.layout.t_thin
    FontKey.MEDIUM -> R.layout.t_medium; FontKey.BLACK -> R.layout.t_black; FontKey.CONDENSED -> R.layout.t_condensed
    FontKey.SERIF -> R.layout.t_serif; FontKey.MONO -> R.layout.t_mono
} else when (f) {
    FontKey.SANS -> R.layout.tm_sans; FontKey.LIGHT -> R.layout.tm_light; FontKey.THIN -> R.layout.tm_thin
    FontKey.MEDIUM -> R.layout.tm_medium; FontKey.BLACK -> R.layout.tm_black; FontKey.CONDENSED -> R.layout.tm_condensed
    FontKey.SERIF -> R.layout.tm_serif; FontKey.MONO -> R.layout.tm_mono
}

private fun clockLayout(f: FontKey): Int = when (f) {
    FontKey.SANS -> R.layout.c_sans; FontKey.LIGHT -> R.layout.c_light; FontKey.THIN -> R.layout.c_thin
    FontKey.MEDIUM -> R.layout.c_medium; FontKey.BLACK -> R.layout.c_black; FontKey.CONDENSED -> R.layout.c_condensed
    FontKey.SERIF -> R.layout.c_serif; FontKey.MONO -> R.layout.c_mono
}

/** Palette of the six self-ticking hand sets in res/layout/analog_*.xml. */
val HAND_COLORS = intArrayOf(0xFFFFFFFF.toInt(), 0xFF12151C.toInt(), 0xFF4DE1FF.toInt(), 0xFFFF4DDB.toInt(), 0xFFFFC857.toInt(), 0xFF9DFF6B.toInt())

fun nearestHand(color: Int): Int {
    var best = 0; var bd = Long.MAX_VALUE
    for (i in HAND_COLORS.indices) {
        val a = HAND_COLORS[i]
        val dr = ((a shr 16) and 255) - ((color shr 16) and 255)
        val dg = ((a shr 8) and 255) - ((color shr 8) and 255)
        val db = (a and 255) - (color and 255)
        val dist = (dr * dr + dg * dg + db * db).toLong()
        if (dist < bd) { bd = dist; best = i }
    }
    return best
}

private fun analogLayout(i: Int): Int = when (i) {
    0 -> R.layout.analog_white; 1 -> R.layout.analog_black; 2 -> R.layout.analog_cyan
    3 -> R.layout.analog_magenta; 4 -> R.layout.analog_amber; else -> R.layout.analog_lime
}

private fun action(env: GEnv, a: com.example.widgetstudio.render.Act): Action = when (a) {
    is Act.Media -> actionRunCallback<MediaKeyCallback>(actionParametersOf(KeyCodeKey to a.keyCode))
    is Act.ToggleTask -> actionRunCallback<ToggleTaskCallback>(actionParametersOf(TaskIdKey to a.id))
    else -> actionStartActivity(Launch.intent(env.ctx, a))
}

private fun mod(m: M, env: GEnv, rs: RowScope?, cs: ColumnScope?): GlanceModifier {
    var g: GlanceModifier = GlanceModifier
    if (m.fw) g = g.fillMaxWidth()
    if (m.fh) g = g.fillMaxHeight()
    m.w?.let { g = g.width(it.dp) }
    m.h?.let { g = g.height(it.dp) }
    if (m.weight) {
        if (rs != null) g = with(rs) { g.defaultWeight() }
        else if (cs != null) g = with(cs) { g.defaultWeight() }
    }
    if (m.pl + m.pt + m.pr + m.pb > 0f) g = g.padding(start = m.pl.dp, top = m.pt.dp, end = m.pr.dp, bottom = m.pb.dp)
    m.act?.let { g = g.clickable(action(env, it)) }
    return g
}

private fun al(a: A): Alignment = when (a) {
    A.TL -> Alignment.TopStart; A.T -> Alignment.TopCenter; A.TR -> Alignment.TopEnd
    A.L -> Alignment.CenterStart; A.C -> Alignment.Center; A.R -> Alignment.CenterEnd
    A.BL -> Alignment.BottomStart; A.B -> Alignment.BottomCenter; A.BR -> Alignment.BottomEnd
}
private fun hal(a: HA): Alignment.Horizontal = when (a) { HA.S -> Alignment.Start; HA.C -> Alignment.CenterHorizontally; HA.E -> Alignment.End }
private fun val_(a: VA): Alignment.Vertical = when (a) { VA.T -> Alignment.Top; VA.C -> Alignment.CenterVertically; VA.B -> Alignment.Bottom }

@Composable
fun GlanceNode(n: N, env: GEnv, rs: RowScope? = null, cs: ColumnScope? = null) {
    val gm = mod(n.m, env, rs, cs)
    when (n) {
        is BoxN -> Box(modifier = gm, contentAlignment = al(n.al)) { n.kids.forEach { GlanceNode(it, env) } }
        is ColN -> Column(modifier = gm, verticalAlignment = val_(n.va), horizontalAlignment = hal(n.ha)) {
            val scope = this
            n.kids.forEach { GlanceNode(it, env, cs = scope) }
        }
        is RowN -> Row(modifier = gm, horizontalAlignment = hal(n.ha), verticalAlignment = val_(n.va)) {
            val scope = this
            n.kids.forEach { GlanceNode(it, env, rs = scope) }
        }
        is TextN -> {
            val rv = RemoteViews(env.ctx.packageName, textLayout(n.font, n.lines > 1))
            rv.setTextViewText(R.id.tv, n.text)
            rv.setTextColor(R.id.tv, n.color)
            rv.setTextViewTextSize(R.id.tv, TypedValue.COMPLEX_UNIT_SP, n.sp)
            Box(modifier = gm) { AndroidRemoteViews(rv) }
        }
        is ClockN -> {
            val rv = RemoteViews(env.ctx.packageName, clockLayout(n.font))
            rv.setCharSequence(R.id.tv, "setFormat12Hour", n.fmt)
            rv.setCharSequence(R.id.tv, "setFormat24Hour", n.fmt)
            rv.setTextColor(R.id.tv, n.color)
            rv.setTextViewTextSize(R.id.tv, TypedValue.COMPLEX_UNIT_SP, n.sp)
            Box(modifier = gm) { AndroidRemoteViews(rv) }
        }
        is GfxN -> {
            val wDp = n.m.w ?: env.wDp
            val hDp = n.m.h ?: env.hDp
            val bmp = BitmapCache.get(n.p, wDp, hDp, env.density)
            Image(provider = ImageProvider(bmp), contentDescription = n.desc, modifier = gm, contentScale = ContentScale.FillBounds)
        }
        is VecN -> Image(
            provider = ImageProvider(n.res), contentDescription = null, modifier = gm,
            colorFilter = ColorFilter.tint(ColorProvider(Color(n.tint)))
        )
        is AnalogN -> {
            val bmp = BitmapCache.get(n.dial, n.sizeDp, n.sizeDp, env.density)
            val rv = RemoteViews(env.ctx.packageName, analogLayout(nearestHand(n.handColor)))
            Box(modifier = gm.width(n.sizeDp.dp).height(n.sizeDp.dp)) {
                Image(provider = ImageProvider(bmp), contentDescription = null, modifier = GlanceModifier.fillMaxWidth().fillMaxHeight(), contentScale = ContentScale.FillBounds)
                AndroidRemoteViews(rv, GlanceModifier.fillMaxWidth().fillMaxHeight())
            }
        }
    }
}
