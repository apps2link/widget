package com.example.widgetstudio.render

import android.graphics.Canvas
import com.example.widgetstudio.core.FontKey

/**
 * Tiny layout IR. A widget design is a pure function Ctx -> N. Two interpreters render it:
 *  - GlanceRenderer  -> real home-screen widget (RemoteViews via Glance)
 *  - ComposeRenderer -> in-app preview, live preview, library thumbnails
 * Both read the same tree and the same [Painter]s, which is what keeps preview and widget in sync.
 */
interface Painter {
    /** Draw into a (w x h) pixel canvas. [d] = pixels per dp. [phase] in 0..1 drives animation (0 on the home screen). */
    fun paint(c: Canvas, w: Float, h: Float, d: Float, phase: Float)
}

sealed class Act {
    data class App(val pkg: String, val fallbackUrl: String? = null) : Act()
    data object Dial : Act()
    data object OpenStudio : Act()
    data object Alarms : Act()
    data object Calendar : Act()
    data object MediaAccess : Act()
    data class Media(val keyCode: Int) : Act()
    data class ToggleTask(val id: String) : Act()
}

enum class A { TL, T, TR, L, C, R, BL, B, BR }
enum class HA { S, C, E }
enum class VA { T, C, B }

/** Modifier bag (all dp). */
data class M(
    val fw: Boolean = false, val fh: Boolean = false, val weight: Boolean = false,
    val w: Float? = null, val h: Float? = null,
    val pl: Float = 0f, val pt: Float = 0f, val pr: Float = 0f, val pb: Float = 0f,
    val act: Act? = null
) {
    fun pad(v: Float) = copy(pl = v, pt = v, pr = v, pb = v)
    fun pad(x: Float, y: Float) = copy(pl = x, pt = y, pr = x, pb = y)
    fun padding(l: Float = pl, t: Float = pt, r: Float = pr, b: Float = pb) = copy(pl = l, pt = t, pr = r, pb = b)
    fun size(w: Float, h: Float) = copy(w = w, h = h)
    fun click(a: Act?) = copy(act = a)
    companion object {
        val Fill = M(fw = true, fh = true)
        val FillW = M(fw = true)
        val FillH = M(fh = true)
        val Weight = M(weight = true)
    }
}

sealed class N { abstract val m: M }
class BoxN(val al: A, override val m: M, val kids: List<N>) : N()
class ColN(val ha: HA, val va: VA, override val m: M, val kids: List<N>) : N()
class RowN(val va: VA, val ha: HA, override val m: M, val kids: List<N>) : N()
class TextN(val text: String, val sp: Float, val color: Int, val font: FontKey, val lines: Int, override val m: M) : N()
/** Platform TextClock on the home screen: ticks by itself, zero background work. */
class ClockN(val fmt: String, val sp: Float, val color: Int, val font: FontKey, override val m: M) : N()
class GfxN(val p: Painter, val desc: String?, override val m: M) : N()
class VecN(val res: Int, val tint: Int, override val m: M) : N()
/** Platform AnalogClock hands (self-ticking) over a [dial] painted by us. Square, [sizeDp] on a side. */
class AnalogN(val sizeDp: Float, val dial: Painter, val handColor: Int, override val m: M) : N()

fun box(al: A = A.C, m: M = M(), vararg k: N): N = BoxN(al, m, k.toList())
fun col(ha: HA = HA.S, va: VA = VA.T, m: M = M(), vararg k: N): N = ColN(ha, va, m, k.toList())
fun row(va: VA = VA.C, ha: HA = HA.S, m: M = M(), vararg k: N): N = RowN(va, ha, m, k.toList())
fun gap(w: Float = 0f, h: Float = 0f): N = BoxN(A.C, M(w = w.coerceAtLeast(0.01f), h = h.coerceAtLeast(0.01f)), emptyList())
/** Fixed-size painted layer. */
fun gfx(p: Painter, w: Float, h: Float, desc: String? = null, m: M = M()): N = GfxN(p, desc, m.copy(w = w, h = h))
