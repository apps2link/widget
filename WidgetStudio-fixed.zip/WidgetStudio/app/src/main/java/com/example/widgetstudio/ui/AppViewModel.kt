package com.example.widgetstudio.ui

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.widgetstudio.core.*
import com.example.widgetstudio.data.DataProvider
import com.example.widgetstudio.data.WeatherRepo
import com.example.widgetstudio.designs.Design
import com.example.widgetstudio.designs.Registry
import com.example.widgetstudio.widgets.Pinner
import com.example.widgetstudio.widgets.Providers
import com.example.widgetstudio.widgets.Updater
import com.example.widgetstudio.work.Scheduler
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class Route {
    data object Home : Route()
    data class Library(val cat: Category? = null) : Route()
    data object Favorites : Route()
    data object MyWidgets : Route()
    data object Settings : Route()
    data object Editor : Route()
    data object Live : Route()
    data object Lab : Route()
    data class Demo(val demo: com.example.widgetstudio.ui.screens.Demo) : Route()
}

/** What the editor is doing: designing something new, editing an installed instance, or configuring from the picker. */
data class EditorState(val design: Design, val cfg: WidgetConfig, val instanceId: Int?, val configMode: Boolean)

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx: Context = app.applicationContext

    private fun <T> kotlinx.coroutines.flow.Flow<T>.state(init: T): StateFlow<T> = stateIn(viewModelScope, SharingStarted.Eagerly, init)
    val settings = Store.settings(ctx).state(Settings())
    val favorites = Store.favorites(ctx).state(emptySet())
    val recents = Store.recents(ctx).state(emptyList())
    val presets = Store.presets(ctx).state(emptyList())
    val tasks = Store.tasks(ctx).state(emptyList())
    val configs = Store.configsFlow(ctx).state(emptyMap())
    val pinned = Store.pinned(ctx).state(null)

    /** Set when this process is hosting the widget configuration activity. */
    var configWidgetId by mutableStateOf<Int?>(null)
    var configSize by mutableStateOf<WSize?>(null)

    // ---- navigation -----------------------------------------------------------------------------
    val stack = mutableStateListOf<Route>(Route.Home)
    fun push(r: Route) { stack.add(r) }
    fun pop(): Boolean = if (stack.size > 1) { stack.removeAt(stack.lastIndex); true } else false
    fun goRoot(r: Route) { stack.clear(); stack.add(r) }

    // ---- data for previews -----------------------------------------------------------------------
    var thumbData by mutableStateOf(DataProvider.sample())
        private set
    var installed by mutableStateOf<List<Providers.Installed>>(emptyList())
        private set

    fun refresh() {
        thumbData = DataProvider.sample()
        installed = Providers.installed(ctx)
    }

    // ---- editor -------------------------------------------------------------------------------------
    var editor by mutableStateOf<EditorState?>(null)
        private set
    var editorData by mutableStateOf(DataProvider.sample())
        private set
    var cityStatus by mutableStateOf("")
        private set
    var pinResult by mutableStateOf<Pinner.Result?>(null)
    private var dataJob: Job? = null

    private fun reloadData() {
        val cfg = editor?.cfg ?: return
        dataJob?.cancel()
        dataJob = viewModelScope.launch { editorData = DataProvider.forPreview(ctx, cfg) }
    }

    fun openNew(designId: String, preset: WidgetConfig? = null, configMode: Boolean = false) {
        val d = Registry.get(designId) ?: return
        val fixed = configSize?.takeIf { it in d.sizes }
        val base = preset?.takeIf { it.designId == designId } ?: Registry.defaultConfig(d, fixed ?: Registry.defaultSize(d))
        val cfg = if (fixed != null) base.copy(size = fixed) else base
        editor = EditorState(d, cfg, null, configMode)
        reloadData(); cityStatus = ""
        viewModelScope.launch { Store.pushRecent(ctx, designId) }
        if (stack.lastOrNull() != Route.Editor) push(Route.Editor)
    }

    fun openInstance(id: Int) {
        val cfg = configs.value[id] ?: return
        val d = Registry.get(cfg.designId) ?: return
        editor = EditorState(d, cfg, id, false)
        reloadData(); cityStatus = ""
        push(Route.Editor)
    }

    /** Config-activity entry: reconfigure a widget that already has a stored config. */
    fun openExisting(id: Int, cfg: WidgetConfig) {
        val d = Registry.get(cfg.designId) ?: return
        editor = EditorState(d, cfg, id, true)
        reloadData()
    }

    fun update(f: (WidgetConfig) -> WidgetConfig) {
        val e = editor ?: return
        val next = f(e.cfg)
        editor = e.copy(cfg = next)
        if (next.extras["city"] != e.cfg.extras["city"] || next.extras["apps"] != e.cfg.extras["apps"]) reloadData()
    }

    fun changeSize(size: WSize) = update { it.copy(size = size) }

    fun resetStyle() {
        val e = editor ?: return
        val base = Registry.defaultConfig(e.design, e.cfg.size)
        editor = e.copy(cfg = base.copy(extras = e.cfg.extras)) // keep the user's data (city, apps, dates)
    }

    fun toggleFavorite(id: String) { viewModelScope.launch { Store.toggleFavorite(ctx, id) } }

    fun savePreset(name: String) {
        val cfg = editor?.cfg ?: return
        viewModelScope.launch { Store.savePreset(ctx, Preset(name.trim().ifEmpty { "My design" }, cfg)) }
    }
    fun deletePreset(name: String) { viewModelScope.launch { Store.deletePreset(ctx, name) } }

    /** "Add to Home Screen": requestPinAppWidget with the current configuration preserved. */
    fun addToHome() {
        val cfg = editor?.cfg ?: return
        viewModelScope.launch {
            Store.pushRecent(ctx, cfg.designId)
            pinResult = Pinner.request(ctx, cfg)
        }
    }

    fun saveInstance(onDone: () -> Unit = {}) {
        val e = editor ?: return
        val id = e.instanceId ?: return
        viewModelScope.launch {
            Store.saveConfig(ctx, id, e.cfg)
            Updater.refreshIds(ctx, listOf(id))
            Scheduler.sync(ctx)
            onDone()
        }
    }

    // ---- data helpers used by the editor --------------------------------------------------------------
    fun fetchCity(city: String) {
        cityStatus = "Looking up…"
        viewModelScope.launch {
            val w = WeatherRepo.refresh(ctx, city)
            cityStatus = if (w == null) "Couldn't find or reach \"$city\". Check the spelling and your connection." else "Found ${w.city}. Weather will refresh automatically."
            reloadData()
            Updater.refreshNeeding(ctx, setOf(Need.WEATHER))
            Scheduler.sync(ctx)
        }
    }

    fun addTask(text: String) {
        if (text.isBlank()) return
        viewModelScope.launch {
            Store.setTasks(ctx, tasks.value + TaskItem(System.nanoTime().toString(), text.trim(), false))
            Updater.refreshNeeding(ctx, setOf(Need.TASKS)); reloadData()
        }
    }
    fun deleteTask(id: String) {
        viewModelScope.launch { Store.setTasks(ctx, tasks.value.filter { it.id != id }); Updater.refreshNeeding(ctx, setOf(Need.TASKS)); reloadData() }
    }
    fun toggleTask(id: String) {
        viewModelScope.launch { Store.toggleTask(ctx, id); Updater.refreshNeeding(ctx, setOf(Need.TASKS)); reloadData() }
    }

    fun refreshAllWidgets() { viewModelScope.launch { Updater.refreshAll(ctx) } }
    fun reloadPreviewData() = reloadData()

    // ---- settings ----------------------------------------------------------------------------------------
    fun setUpdateMode(v: Int) { viewModelScope.launch { Store.setUpdateMode(ctx, v); Scheduler.sync(ctx) } }
    fun setFahrenheit(v: Boolean) { viewModelScope.launch { Store.setFahrenheit(ctx, v); Updater.refreshAll(ctx); reloadData() } }
    fun setReducedMotion(v: Boolean) {
        ctx.getSharedPreferences("ws_wallpaper", Context.MODE_PRIVATE).edit().putBoolean("reduced", v).apply()
        viewModelScope.launch { Store.setReducedMotion(ctx, v) }
    }
    fun wallpaperTheme(): Int = ctx.getSharedPreferences("ws_wallpaper", Context.MODE_PRIVATE).getInt("theme", 0)
    fun setWallpaperTheme(v: Int) { ctx.getSharedPreferences("ws_wallpaper", Context.MODE_PRIVATE).edit().putInt("theme", v).apply() }
}
