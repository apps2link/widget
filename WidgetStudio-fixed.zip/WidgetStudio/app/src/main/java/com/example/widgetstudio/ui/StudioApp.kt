package com.example.widgetstudio.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.widgetstudio.core.IconKind
import com.example.widgetstudio.ui.components.AmbientBackground
import com.example.widgetstudio.ui.components.IconView
import com.example.widgetstudio.ui.components.glass
import com.example.widgetstudio.ui.effects.AuroraBackground
import com.example.widgetstudio.ui.screens.*
import com.example.widgetstudio.ui.theme.Ws

private fun isTab(r: Route) = r is Route.Home || r is Route.Library || r is Route.Favorites || r is Route.MyWidgets || r is Route.Settings

@Composable
fun StudioApp(vm: AppViewModel, onApplyConfig: () -> Unit, onCancelConfig: () -> Unit) {
    val settings by vm.settings.collectAsState()
    val pinned by vm.pinned.collectAsState()
    val ctx = LocalContext.current
    val configMode = vm.configWidgetId != null
    val route = vm.stack.last()

    BackHandler(enabled = vm.stack.size > 1 || configMode) { if (!vm.pop() && configMode) onCancelConfig() }

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, ev -> if (ev == Lifecycle.Event.ON_RESUME) vm.refresh() }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    val opened = remember { System.currentTimeMillis() }
    LaunchedEffect(pinned) {
        val p = pinned
        if (p != null && p.at > opened) { Toast.makeText(ctx, "Added to your home screen ✓", Toast.LENGTH_SHORT).show(); vm.refresh() }
    }

    AmbientBackground(settings.reducedMotion) {
        AnimatedContent(
            targetState = route,
            transitionSpec = { (fadeIn(tween(280)) + slideInVertically(tween(320)) { it / 28 }) togetherWith fadeOut(tween(160)) },
            label = "route"
        ) { r ->
            when (r) {
                Route.Home -> HomeScreen(vm)
                is Route.Library -> LibraryScreen(vm, r.cat, configMode)
                Route.Favorites -> FavoritesScreen(vm)
                Route.MyWidgets -> MyWidgetsScreen(vm)
                Route.Settings -> SettingsScreen(vm)
                Route.Editor -> EditorScreen(vm, onApplyConfig)
                Route.Live -> LivePreviewScreen(vm)
                Route.Lab -> AuroraBackground { GalleryScreen(onOpen = { vm.push(Route.Demo(it)) }) }
                is Route.Demo -> AuroraBackground {
                    val back = { vm.pop(); Unit }
                    when (r.demo) {
                        Demo.CLOCK -> ClockScreen(back)
                        Demo.WEATHER -> WeatherScreen(back)
                        Demo.PILLS -> PillsScreen(back)
                        Demo.HUD -> HudScreen(back)
                        Demo.RING -> RingScreen(back)
                    }
                }
            }
        }
        if (isTab(route) && !configMode) BottomBar(route, vm, Modifier.align(Alignment.BottomCenter))
        PinDialog(vm)
    }
}

@Composable
private fun BottomBar(current: Route, vm: AppViewModel, modifier: Modifier) {
    val tabs = listOf<Triple<Route, String, IconKind>>(
        Triple(Route.Home, "Home", IconKind.HOME), Triple(Route.Library(), "Library", IconKind.GRID),
        Triple(Route.Favorites, "Favorites", IconKind.HEART_O), Triple(Route.MyWidgets, "My Widgets", IconKind.WIDGET),
        Triple(Route.Settings, "Settings", IconKind.GEAR)
    )
    Row(modifier.navigationBarsPadding().padding(horizontal = 14.dp, vertical = 12.dp).fillMaxWidth().glass(30.dp).padding(6.dp)) {
        tabs.forEach { (route, label, icon) ->
            val sel = route::class == current::class
            Column(
                Modifier.weight(1f).clickable { vm.goRoot(route) }.padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                IconView(if (sel && icon == IconKind.HEART_O) IconKind.HEART else icon, 22.dp, if (sel) Ws.Cyan else Ws.TextDim)
                Text(label, color = if (sel) Ws.Cyan else Ws.TextDim, style = TextStyle(fontSize = 10.sp, fontWeight = FontWeight.Medium), maxLines = 1)
            }
        }
    }
}
