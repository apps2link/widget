package com.example.widgetstudio.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.widgetstudio.core.IconKind
import com.example.widgetstudio.core.hexOf
import com.example.widgetstudio.core.hsv
import com.example.widgetstudio.core.toHsv
import com.example.widgetstudio.render.IconPainter
import com.example.widgetstudio.ui.theme.Ws
import kotlinx.coroutines.delay

@Composable
fun rememberNow(tickMs: Long): Long {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(tickMs) { while (true) { delay(tickMs); now = System.currentTimeMillis() } }
    return now
}

/** Soft aurora wash behind every screen. Static when reduced motion is on. */
@Composable
fun AmbientBackground(reduced: Boolean, content: @Composable BoxScope.() -> Unit) {
    val t = rememberInfiniteTransition(label = "ambient")
    val p = t.animateFloat(0f, 1f, infiniteRepeatable(tween(if (reduced) 100_000 else 22_000, easing = LinearEasing), RepeatMode.Reverse), label = "p")
    Box(Modifier.fillMaxSize().background(Ws.Bg)) {
        Canvas(Modifier.fillMaxSize()) {
            val k = p.value
            val w = size.width; val h = size.height
            fun blob(cx: Float, cy: Float, r: Float, c: Color) =
                drawCircle(Brush.radialGradient(listOf(c, Color.Transparent), center = androidx.compose.ui.geometry.Offset(cx, cy), radius = r), radius = r, center = androidx.compose.ui.geometry.Offset(cx, cy))
            blob(w * (0.15f + 0.25f * k), h * 0.12f, w * 0.85f, Ws.Violet.copy(alpha = 0.22f))
            blob(w * (0.9f - 0.3f * k), h * (0.35f + 0.1f * k), w * 0.8f, Ws.Cyan.copy(alpha = 0.14f))
            blob(w * 0.3f, h * (0.95f - 0.15f * k), w * 0.9f, Ws.Magenta.copy(alpha = 0.10f))
        }
        content()
    }
}

fun Modifier.glass(radius: Dp = 22.dp): Modifier {
    val s = RoundedCornerShape(radius)
    return this.clip(s)
        .background(Brush.verticalGradient(listOf(Ws.GlassTop, Ws.GlassBottom)), s)
        .border(1.dp, Brush.linearGradient(listOf(Ws.GlassBorderA, Ws.GlassBorderB)), s)
}

@Composable
fun IconView(kind: IconKind, size: Dp = 22.dp, color: Color = Ws.Text, modifier: Modifier = Modifier) {
    val argb = color.toArgb()
    Canvas(modifier.size(size)) {
        drawIntoCanvas { IconPainter(kind, argb).paint(it.nativeCanvas, this.size.width, this.size.height, density, 0f) }
    }
}

@Composable
fun H1(text: String, modifier: Modifier = Modifier) =
    Text(text, modifier, color = Ws.Text, style = TextStyle(fontSize = 30.sp, fontWeight = FontWeight.Light))

@Composable
fun H2(text: String, modifier: Modifier = Modifier) =
    Text(text, modifier, color = Ws.Text, style = TextStyle(fontSize = 18.sp, fontWeight = FontWeight.Medium))

@Composable
fun Dim(text: String, modifier: Modifier = Modifier, size: Int = 13) =
    Text(text, modifier, color = Ws.TextDim, style = TextStyle(fontSize = size.sp))

@Composable
fun NeonButton(text: String, modifier: Modifier = Modifier, icon: IconKind? = null, enabled: Boolean = true, onClick: () -> Unit) {
    val s = RoundedCornerShape(18.dp)
    Box(
        modifier.clip(s).background(if (enabled) Ws.AccentBrush else Brush.linearGradient(listOf(Color(0x33FFFFFF), Color(0x22FFFFFF))), s)
            .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 20.dp, vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (icon != null) IconView(icon, 20.dp, Color(0xFF05060B))
            Text(text, color = Color(0xFF05060B), style = TextStyle(fontSize = 15.sp, fontWeight = FontWeight.SemiBold))
        }
    }
}

@Composable
fun GhostButton(text: String, modifier: Modifier = Modifier, icon: IconKind? = null, onClick: () -> Unit) {
    Box(modifier.glass(16.dp).clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 12.dp), contentAlignment = Alignment.Center) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (icon != null) IconView(icon, 18.dp, Ws.Text)
            Text(text, color = Ws.Text, style = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.Medium))
        }
    }
}

@Composable
fun WsChip(text: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier, fontFamily: androidx.compose.ui.text.font.FontFamily? = null) {
    val s = RoundedCornerShape(50)
    val m = if (selected) modifier.clip(s).background(Ws.Cyan.copy(alpha = 0.16f), s).border(BorderStroke(1.dp, Ws.AccentBrush), s)
    else modifier.glass(50.dp)
    Box(m.clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp), contentAlignment = Alignment.Center) {
        Text(text, color = if (selected) Ws.Cyan else Ws.Text, style = TextStyle(fontSize = 13.sp, fontFamily = fontFamily, fontWeight = FontWeight.Medium))
    }
}

@Composable
fun SwitchRow(label: String, checked: Boolean, hint: String? = null, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(label, color = Ws.Text, style = TextStyle(fontSize = 15.sp))
            if (hint != null) Dim(hint, size = 12)
        }
        Switch(checked, onChange, colors = SwitchDefaults.colors(checkedTrackColor = Ws.Cyan, checkedThumbColor = Ws.Bg, uncheckedTrackColor = Color(0x33FFFFFF), uncheckedThumbColor = Ws.TextDim, uncheckedBorderColor = Color.Transparent))
    }
}

@Composable
fun WsSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, valueText: String, onChange: (Float) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Row { Text(label, color = Ws.Text, style = TextStyle(fontSize = 14.sp), modifier = Modifier.weight(1f)); Dim(valueText) }
        Slider(value, onChange, valueRange = range, colors = SliderDefaults.colors(thumbColor = Ws.Cyan, activeTrackColor = Ws.Cyan, inactiveTrackColor = Color(0x22FFFFFF)))
    }
}

@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) =
    Text(text.uppercase(), modifier.padding(top = 14.dp, bottom = 6.dp), color = Ws.TextDim, style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.2.sp))

@Composable
fun ColorRow(colors: List<Int>, selected: Int, onPick: (Int) -> Unit, onCustom: () -> Unit) {
    androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 4.dp)) {
        items(colors.size) { i ->
            val c = colors[i]
            val sel = c == selected
            Box(Modifier.size(34.dp).clip(CircleShape).background(Color(c)).border(if (sel) 2.5.dp else 1.dp, if (sel) Color.White else Color(0x44FFFFFF), CircleShape).clickable { onPick(c) })
        }
        item {
            Box(Modifier.size(34.dp).clip(CircleShape).background(Brush.sweepGradient(listOf(Color.Red, Color.Yellow, Color.Green, Color.Cyan, Color.Blue, Color.Magenta, Color.Red))).border(1.dp, Color(0x44FFFFFF), CircleShape).clickable(onClick = onCustom))
        }
    }
}

@Composable
fun ColorPickerDialog(initial: Int, onDismiss: () -> Unit, onPick: (Int) -> Unit) {
    val hv = remember { toHsv(initial) }
    var h by remember { mutableStateOf(hv[0]) }
    var s by remember { mutableStateOf(hv[1]) }
    var v by remember { mutableStateOf(hv[2]) }
    val col = hsv(h, s, v) or (0xFF shl 24)
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = Ws.Surface,
        title = { Text("Custom colour", color = Ws.Text) },
        text = {
            Column {
                Box(Modifier.fillMaxWidth().height(48.dp).clip(RoundedCornerShape(14.dp)).background(Color(col)))
                Dim(hexOf(col), Modifier.padding(top = 6.dp))
                WsSlider("Hue", h, 0f..360f, "${h.toInt()}°") { h = it }
                WsSlider("Saturation", s, 0f..1f, "${(s * 100).toInt()}%") { s = it }
                WsSlider("Brightness", v, 0f..1f, "${(v * 100).toInt()}%") { v = it }
            }
        },
        confirmButton = { TextButton({ onPick(col) }) { Text("Apply", color = Ws.Cyan) } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel", color = Ws.TextDim) } }
    )
}
