package com.example.widgetstudio.ui.effects

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/** Slowly drifting colour blobs behind everything (aurora / mesh gradient). */
@Composable
fun AuroraBackground(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val transition = rememberInfiniteTransition(label = "aurora")
    val p by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(16000, easing = LinearEasing)),
        label = "aurora-phase"
    )
    Box(modifier.fillMaxSize().background(Color(0xFF07090F))) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val a = p * 2f * PI.toFloat()
            fun blob(color: Color, cx: Float, cy: Float, r: Float) {
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(color.copy(alpha = 0.5f), Color.Transparent),
                        center = Offset(cx, cy),
                        radius = r
                    ),
                    radius = r,
                    center = Offset(cx, cy)
                )
            }
            blob(Color(0xFF4F6BFF), w * (0.25f + 0.2f * sin(a)), h * (0.2f + 0.1f * cos(a)), w * 0.9f)
            blob(Color(0xFFB04BFF), w * (0.8f + 0.15f * cos(a)), h * (0.55f + 0.12f * sin(a)), w * 0.8f)
            blob(Color(0xFF14D6B4), w * (0.4f + 0.25f * sin(a + 2f)), h * (0.9f + 0.05f * cos(a)), w * 0.9f)
        }
        ParticleField(Modifier.fillMaxSize(), count = 36)
        content()
    }
}

private class Particle(val x: Float, val y: Float, val speed: Float, val radius: Float, val phase: Float)

/** Floating dust / bokeh particles. Redraws only (no recomposition) every frame. */
@Composable
fun ParticleField(
    modifier: Modifier = Modifier,
    count: Int = 40,
    color: Color = Color.White
) {
    val particles = remember(count) {
        List(count) {
            Particle(
                x = Random.nextFloat(),
                y = Random.nextFloat(),
                speed = Random.nextFloat() * 0.03f + 0.01f,
                radius = Random.nextFloat() * 2.4f + 0.8f,
                phase = Random.nextFloat() * 6.28f
            )
        }
    }
    var time by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            androidx.compose.runtime.withFrameNanos { now ->
                if (last != 0L) time += (now - last) / 1_000_000_000f
                last = now
            }
        }
    }
    Canvas(modifier) {
        val t = time
        particles.forEach { p ->
            val y = (((p.y - t * p.speed) % 1f) + 1f) % 1f
            val x = p.x + sin(t * 0.6f + p.phase) * 0.02f
            val alpha = (0.2f + 0.3f * sin(t * 1.2f + p.phase)).coerceIn(0.05f, 0.6f)
            drawCircle(color.copy(alpha = alpha), p.radius.dp.toPx(), Offset(x * size.width, y * size.height))
        }
    }
}

/** Frosted-glass card: translucent gradient, light rim, springy press animation. */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(32.dp),
    onClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.95f else 1f,
        animationSpec = spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium),
        label = "press"
    )
    var m = modifier
        .graphicsLayer { scaleX = scale; scaleY = scale }
        .clip(shape)
        .background(Brush.verticalGradient(listOf(Color.White.copy(0.14f), Color.White.copy(0.05f))))
        .border(
            1.dp,
            Brush.linearGradient(listOf(Color.White.copy(0.5f), Color.White.copy(0.05f))),
            shape
        )
    if (onClick != null) {
        m = m.clickable(interactionSource = interaction, indication = null, onClick = onClick)
    }
    Box(m, content = content)
}
