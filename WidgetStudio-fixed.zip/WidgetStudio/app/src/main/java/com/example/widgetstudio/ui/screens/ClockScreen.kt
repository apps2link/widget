package com.example.widgetstudio.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle as JTextStyle
import java.util.Locale

@Composable
fun ClockScreen(onBack: () -> Unit) {
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = LocalDateTime.now()
            delay(200)
        }
    }
    DemoScaffold("ساعات Pill و Flip", onBack) {
        Column(
            Modifier.verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(28.dp)
        ) {
            FlipClock(now)
            PillClock(now)
        }
    }
}

@Composable
private fun FlipClock(now: LocalDateTime) {
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val dw = minOf(56.dp, (maxWidth - 64.dp) / 6)
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(5.dp, Alignment.CenterHorizontally),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val parts = listOf(now.hour, now.minute, now.second)
            parts.forEachIndexed { i, v ->
                FlipDigit(v / 10, dw)
                FlipDigit(v % 10, dw)
                if (i < 2) Text(":", color = Color.White.copy(0.7f), fontSize = (dw.value * 0.8f).sp)
            }
        }
    }
}

@Composable
private fun FlipDigit(value: Int, width: Dp) {
    val shape = RoundedCornerShape(width / 4)
    Box(
        Modifier
            .size(width, width * 1.45f)
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0xFF2A2F3C), Color(0xFF14171F))))
            .border(1.dp, Color.White.copy(0.14f), shape),
        contentAlignment = Alignment.Center
    ) {
        AnimatedContent(
            targetState = value,
            transitionSpec = {
                (slideInVertically(tween(450)) { -it } + fadeIn(tween(450))) togetherWith
                    (slideOutVertically(tween(450)) { it } + fadeOut(tween(300)))
            },
            label = "digit"
        ) { v ->
            Text(
                v.toString(),
                color = Color.White,
                fontSize = (width.value * 0.95f).sp,
                fontWeight = FontWeight.Light
            )
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(Color.Black.copy(0.65f)))
    }
}

@Composable
private fun PillClock(now: LocalDateTime) {
    val beige = Color(0xFFE6DFD0)
    val dayName = now.dayOfWeek.getDisplayName(JTextStyle.FULL, Locale.getDefault())
    val date = now.format(DateTimeFormatter.ofPattern("d MMM yyyy"))
    val outer = RoundedCornerShape(75.dp)

    Box(
        Modifier
            .fillMaxWidth()
            .height(150.dp)
            .clip(outer)
            .background(Brush.verticalGradient(listOf(Color(0xFF1E2430), Color(0xFF0C0F16))))
            .border(1.dp, Color.White.copy(0.15f), outer)
            .padding(10.dp)
    ) {
        Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(65.dp))
                    .background(beige),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(dayName, color = Color.Black.copy(0.45f), fontSize = 13.sp)
                    AnimatedContent(
                        targetState = now.hour,
                        transitionSpec = {
                            (slideInVertically(tween(500)) { -it } + fadeIn(tween(500))) togetherWith
                                (slideOutVertically(tween(500)) { it } + fadeOut(tween(300)))
                        },
                        label = "hour"
                    ) { h ->
                        Text(
                            "%02d".format(h),
                            color = Color.Black,
                            fontSize = 58.sp,
                            fontWeight = FontWeight.Light
                        )
                    }
                    Text(date, color = Color.Black.copy(0.55f), fontSize = 11.sp)
                }
            }
            Spacer(Modifier.width(8.dp))
            Box(Modifier.size(130.dp), contentAlignment = Alignment.Center) {
                Box(Modifier.fillMaxSize().clip(CircleShape).background(Color.Black))
                SecondsRing(Modifier.fillMaxSize().padding(4.dp))
                AnimatedContent(
                    targetState = now.minute,
                    transitionSpec = {
                        (slideInVertically(tween(500)) { it } + fadeIn(tween(500))) togetherWith
                            (slideOutVertically(tween(500)) { -it } + fadeOut(tween(300)))
                    },
                    label = "minute"
                ) { m ->
                    Text(
                        "%02d".format(m),
                        color = Color.White,
                        fontSize = 48.sp,
                        fontWeight = FontWeight.Light
                    )
                }
            }
        }
    }
}

/** Smooth seconds sweep: redraws every frame without recomposing. */
@Composable
private fun SecondsRing(modifier: Modifier) {
    var frame by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        while (true) withFrameNanos { frame = it }
    }
    Canvas(modifier) {
        val tick = frame
        if (tick == -1L) return@Canvas
        val t = LocalTime.now()
        val sec = t.second + t.nano / 1_000_000_000f
        val sweep = sec / 60f * 360f
        val sw = 5.dp.toPx()
        val topLeft = Offset(sw / 2, sw / 2)
        val arcSize = Size(size.width - sw, size.height - sw)
        drawArc(Color.White.copy(0.08f), -90f, 360f, false, topLeft, arcSize, style = Stroke(sw))
        drawArc(
            Color(0xFF7C9CFF), -90f, sweep, false, topLeft, arcSize,
            style = Stroke(sw, cap = StrokeCap.Round)
        )
    }
}
