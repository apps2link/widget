package com.example.widgetstudio.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.widgetstudio.core.IconKind
import com.example.widgetstudio.core.WSize
import com.example.widgetstudio.designs.Design
import com.example.widgetstudio.designs.Registry
import com.example.widgetstudio.render.WidgetPreview
import com.example.widgetstudio.ui.AppViewModel
import com.example.widgetstudio.ui.components.*
import com.example.widgetstudio.ui.theme.Ws

enum class Backdrop(val label: String, val brush: Brush) {
    DARK("Dark", Brush.verticalGradient(listOf(Color(0xFF0A0F1E), Color(0xFF1B1030)))),
    LIGHT("Light", Brush.verticalGradient(listOf(Color(0xFFEFE9DC), Color(0xFFB4CFE6)))),
    PHOTO("Photo", Brush.linearGradient(listOf(Color(0xFF1F6F8B), Color(0xFFE07A5F), Color(0xFF3D405B))))
}

/** A real rendering of the design (same layout IR the home-screen widget uses) at its true dp size. */
@Composable
fun DesignThumb(design: Design, vm: AppViewModel, modifier: Modifier = Modifier, maxH: Dp = Dp.Unspecified, size: WSize? = null) {
    val sz = size ?: Registry.defaultSize(design)
    val cfg = remember(design.id, sz) { Registry.defaultConfig(design, sz) }
    val data = vm.thumbData
    val node = remember(cfg, data) { design.node(cfg, sz.wDp, sz.hDp, data) }
    val phase = remember { mutableStateOf(0f) }
    val now = rememberNow(20_000)
    WidgetPreview(node, sz.wDp, sz.hDp, phase, now, modifier, maxH)
}

@Composable
fun DesignCard(design: Design, vm: AppViewModel, favorite: Boolean, modifier: Modifier = Modifier, thumbHeight: Dp = 120.dp, onClick: () -> Unit) {
    Column(modifier.glass(24.dp).clickable(onClick = onClick).padding(10.dp)) {
        Box(Modifier.fillMaxWidth().height(thumbHeight).clip(RoundedCornerShape(16.dp)).background(Backdrop.PHOTO.brush), contentAlignment = Alignment.Center) {
            DesignThumb(design, vm, Modifier.padding(8.dp), maxH = thumbHeight - 16.dp)
            Box(Modifier.align(Alignment.TopEnd).padding(4.dp).clip(RoundedCornerShape(50)).clickable { vm.toggleFavorite(design.id) }.padding(6.dp)) {
                IconView(if (favorite) IconKind.HEART else IconKind.HEART_O, 18.dp, if (favorite) Ws.Magenta else Color.White)
            }
        }
        Text(design.name, Modifier.padding(top = 8.dp), color = Ws.Text, style = TextStyle(fontSize = 15.sp, fontWeight = FontWeight.Medium), maxLines = 1)
        Dim("${design.cat.title} · " + design.sizes.joinToString(" ") { sizeTag(it) }, size = 11)
    }
}

fun sizeTag(s: WSize): String = when (s) { WSize.SMALL -> "S"; WSize.STRIP -> "1×4"; WSize.MEDIUM -> "M"; WSize.LARGE -> "L" }

@Composable
fun ScreenTitle(title: String, subtitle: String? = null, trailing: @Composable () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { H1(title); if (subtitle != null) Dim(subtitle) }
        trailing()
    }
}

@Composable
fun EmptyState(icon: IconKind, title: String, body: String, modifier: Modifier = Modifier, action: (@Composable () -> Unit)? = null) {
    Column(modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(72.dp).glass(36.dp), contentAlignment = Alignment.Center) { IconView(icon, 30.dp, Ws.Cyan) }
        Spacer(Modifier.height(14.dp))
        H2(title)
        Dim(body, Modifier.padding(top = 4.dp, bottom = 16.dp))
        action?.invoke()
    }
}
