@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.example.widgetstudio.ui.screens

import android.Manifest
import android.content.Intent
import android.graphics.Typeface
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.widgetstudio.core.*
import com.example.widgetstudio.data.DataProvider
import com.example.widgetstudio.designs.Field
import com.example.widgetstudio.designs.Registry
import com.example.widgetstudio.render.WidgetPreview
import com.example.widgetstudio.ui.AppViewModel
import com.example.widgetstudio.ui.Route
import com.example.widgetstudio.ui.components.*
import com.example.widgetstudio.ui.theme.Ws
import com.example.widgetstudio.widgets.Pinner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset

private val BG_COLORS = listOf(0xFF0B0F1A, 0xFF05060B, 0xFF1A1D24, 0xFF132A4A, 0xFF2A1630, 0xFF03100B, 0xFF241608, 0xFF1B1030, 0xFFEDE7DA, 0xFFFFFFFF, 0xFF9FB4FF).map { it.toInt() }
private val ACCENTS = listOf(0xFF4DE1FF, 0xFF9B6BFF, 0xFFFF4DDB, 0xFFFF6B6B, 0xFFFFC857, 0xFF9DFF6B, 0xFF5CFFB0, 0xFFFFFFFF, 0xFFE6DFD0).map { it.toInt() }

private class Theme(val name: String, val bg: Long, val bg2: Long, val accent: Long, val alpha: Float = 0.9f)
private val THEMES = listOf(
    Theme("Midnight", 0xFF0B0F1A, 0xFF1B2440, 0xFF4DE1FF), Theme("Aurora", 0xFF0F1B2E, 0xFF2B1B4A, 0xFF9B6BFF),
    Theme("Sunset", 0xFF2A1630, 0xFF0F0A1E, 0xFFFFB347), Theme("Forest", 0xFF03100B, 0xFF072016, 0xFF5CFFB0),
    Theme("Rose", 0xFF150810, 0xFF2A0F22, 0xFFFF6B9D), Theme("Paper", 0xFFEDE7DA, 0xFFD6CDB8, 0xFFFF6B6B),
    Theme("Ice glass", 0xFF9FB4FF, 0xFF6B7CFF, 0xFFFFFFFF, 0.32f)
)

private enum class ColorTarget { BG, BG2, ACCENT }

@Composable
fun EditorScreen(vm: AppViewModel, onApplyConfig: () -> Unit) {
    val e = vm.editor ?: return
    val ctx = LocalContext.current
    val favs by vm.favorites.collectAsState()
    var tab by remember { mutableIntStateOf(0) }
    var backdrop by remember { mutableStateOf(Backdrop.DARK) }
    var showSave by remember { mutableStateOf(false) }
    var colorTarget by remember { mutableStateOf<ColorTarget?>(null) }
    val cfg = e.cfg
    val design = e.design
    val node = remember(cfg, vm.editorData) { design.node(cfg, cfg.size.wDp, cfg.size.hDp, vm.editorData) }
    val phase = remember { mutableStateOf(0f) }
    val now = rememberNow(1000)

    Column(Modifier.fillMaxSize().statusBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.clickable { vm.pop() }.padding(10.dp)) { IconView(IconKind.BACK, 24.dp) }
            Column(Modifier.weight(1f)) { H2(design.name); Dim(design.cat.title, size = 12) }
            Box(Modifier.clickable { vm.toggleFavorite(design.id) }.padding(10.dp)) {
                IconView(if (design.id in favs) IconKind.HEART else IconKind.HEART_O, 24.dp, if (design.id in favs) Ws.Magenta else Ws.Text)
            }
            Box(Modifier.clickable { vm.push(Route.Live) }.padding(10.dp)) { IconView(IconKind.PLAY, 24.dp, Ws.Cyan) }
        }
        Box(Modifier.padding(horizontal = 16.dp).fillMaxWidth().height(230.dp).clip(RoundedCornerShape(26.dp)).background(backdrop.brush), contentAlignment = Alignment.Center) {
            WidgetPreview(node, cfg.size.wDp, cfg.size.hDp, phase, now, Modifier.padding(18.dp), maxHeight = 190.dp)
            Row(Modifier.align(Alignment.BottomStart).padding(10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Backdrop.entries.forEach { b -> WsChip(b.label, backdrop == b, { backdrop = b }) }
            }
            if (vm.editorData.weatherIsSample && Need.WEATHER in design.needs)
                Box(Modifier.align(Alignment.TopStart).padding(10.dp).clip(RoundedCornerShape(50)).background(Color(0xAA000000)).padding(horizontal = 10.dp, vertical = 4.dp)) { Text("Sample data · set a city in Data", color = Color.White, style = TextStyle(fontSize = 11.sp)) }
        }
        if (design.sizes.size > 1 && !e.configMode) Row(Modifier.padding(horizontal = 16.dp, vertical = 10.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            design.sizes.forEach { s -> WsChip(s.label, cfg.size == s, { vm.changeSize(s) }) }
        }
        Row(Modifier.padding(horizontal = 16.dp, vertical = 4.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Style", "Text", "Layout", "Effects", "Data").forEachIndexed { i, t -> WsChip(t, tab == i, { tab = i }) }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 6.dp)) {
            when (tab) {
                0 -> StyleTab(vm, cfg) { colorTarget = it }
                1 -> TextTab(vm, cfg)
                2 -> LayoutTab(vm, e.design.layouts, cfg)
                3 -> EffectsTab(vm, e.design.effects, cfg)
                else -> DataTab(vm, e.design.fields, cfg)
            }
            Spacer(Modifier.height(24.dp))
        }
        Row(Modifier.fillMaxWidth().background(Ws.Bg.copy(alpha = 0.9f)).navigationBarsPadding().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            when {
                e.configMode -> NeonButton("Apply to widget", Modifier.weight(1f), IconKind.CHECK) { onApplyConfig() }
                e.instanceId != null -> NeonButton("Save changes", Modifier.weight(1f), IconKind.CHECK) {
                    vm.saveInstance { vm.refresh(); Toast.makeText(ctx, "Widget updated", Toast.LENGTH_SHORT).show(); vm.pop() }
                }
                else -> {
                    GhostButton("Save preset") { showSave = true }
                    NeonButton("Add to Home Screen", Modifier.weight(1f), IconKind.WIDGET) { vm.addToHome() }
                }
            }
        }
    }

    colorTarget?.let { t ->
        val initial = when (t) { ColorTarget.BG -> cfg.bg; ColorTarget.BG2 -> cfg.bg2; ColorTarget.ACCENT -> cfg.accent }
        ColorPickerDialog(initial, { colorTarget = null }) { c ->
            vm.update { when (t) { ColorTarget.BG -> it.copy(bg = c); ColorTarget.BG2 -> it.copy(bg2 = c); ColorTarget.ACCENT -> it.copy(accent = c) } }
            colorTarget = null
        }
    }
    if (showSave) {
        var name by remember { mutableStateOf(design.name) }
        AlertDialog(
            onDismissRequest = { showSave = false }, containerColor = Ws.Surface,
            title = { Text("Save preset", color = Ws.Text) },
            text = { WsTextField(name, "Preset name") { name = it } },
            confirmButton = { TextButton({ vm.savePreset(name); showSave = false; Toast.makeText(ctx, "Preset saved", Toast.LENGTH_SHORT).show() }) { Text("Save", color = Ws.Cyan) } },
            dismissButton = { TextButton({ showSave = false }) { Text("Cancel", color = Ws.TextDim) } }
        )
    }
}

// ================================================================================================ tabs
@Composable
private fun StyleTab(vm: AppViewModel, cfg: WidgetConfig, pick: (ColorTarget) -> Unit) {
    SectionLabel("Quick themes")
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(THEMES, key = { it.name }) { t ->
            WsChip(t.name, false, { vm.update { it.copy(bg = t.bg.toInt(), bg2 = t.bg2.toInt(), accent = t.accent.toInt(), gradient = true, alpha = t.alpha) } })
        }
    }
    SectionLabel("Background")
    ColorRow(BG_COLORS, cfg.bg, { c -> vm.update { it.copy(bg = c) } }) { pick(ColorTarget.BG) }
    SwitchRow("Gradient", cfg.gradient) { g -> vm.update { it.copy(gradient = g) } }
    if (cfg.gradient) {
        ColorRow(BG_COLORS, cfg.bg2, { c -> vm.update { it.copy(bg2 = c) } }) { pick(ColorTarget.BG2) }
        WsSlider("Gradient angle", cfg.gradientAngle.toFloat(), 0f..360f, "${cfg.gradientAngle}°") { a -> vm.update { it.copy(gradientAngle = a.toInt()) } }
    }
    WsSlider("Background opacity", cfg.alpha, 0f..1f, "${(cfg.alpha * 100).toInt()}%") { a -> vm.update { it.copy(alpha = a) } }
    WsSlider("Corner radius", cfg.radius, 0f..44f, "${cfg.radius.toInt()} dp") { r -> vm.update { it.copy(radius = r) } }
    SectionLabel("Accent & glow")
    ColorRow(ACCENTS, cfg.accent, { c -> vm.update { it.copy(accent = c) } }) { pick(ColorTarget.ACCENT) }
    WsSlider("Glow intensity", cfg.glow, 0f..1f, "${(cfg.glow * 100).toInt()}%") { g -> vm.update { it.copy(glow = g) } }
}

@Composable
private fun TextTab(vm: AppViewModel, cfg: WidgetConfig) {
    SectionLabel("Typeface")
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FontKey.entries.forEach { f ->
            WsChip(f.label, cfg.font == f, { vm.update { it.copy(font = f) } }, fontFamily = remember(f) { FontFamily(Typeface.create(f.family, Typeface.NORMAL)) })
        }
    }
    WsSlider("Font size", cfg.fontScale, 0.6f..1.6f, "${(cfg.fontScale * 100).toInt()}%") { s -> vm.update { it.copy(fontScale = s) } }
    SectionLabel("Text colour")
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { TextMode.entries.forEach { m -> WsChip(m.label, cfg.textMode == m, { vm.update { it.copy(textMode = m) } }) } }
    Dim("Auto picks light or dark text from the background. Transparent widgets assume a dark wallpaper; switch to Dark for light wallpapers.", Modifier.padding(top = 8.dp), 12)
}

@Composable
private fun LayoutTab(vm: AppViewModel, layouts: List<String>, cfg: WidgetConfig) {
    if (layouts.isNotEmpty()) {
        SectionLabel("Layout")
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            layouts.forEachIndexed { i, l -> WsChip(l, cfg.layout == i, { vm.update { it.copy(layout = i) } }) }
        }
    }
    SectionLabel("Icon style")
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        IconStyle.entries.forEach { s -> WsChip(s.label, cfg.iconStyle == s, { vm.update { it.copy(iconStyle = s) } }) }
    }
    Dim("Icon style shapes app icons in shortcut widgets.", Modifier.padding(top = 6.dp), 12)
    GhostButton("Reset styling to design defaults", Modifier.padding(top = 18.dp)) { vm.resetStyle() }
}

@Composable
private fun EffectsTab(vm: AppViewModel, available: List<Effect>, cfg: WidgetConfig) {
    SectionLabel("Visual effects")
    available.forEach { fx ->
        SwitchRow(fx.label, cfg.has(fx), fx.hint) { on -> vm.update { it.copy(effects = if (on) it.effects + fx else it.effects - fx) } }
    }
    Dim("Android home-screen widgets can't animate continuously. Effects are drawn into the widget and refresh on events. Open Live Preview (▶ top right) or the live wallpaper to see them move.", Modifier.padding(top = 10.dp), 12)
}

@Composable
private fun DataTab(vm: AppViewModel, fields: List<Field>, cfg: WidgetConfig) {
    if (fields.isEmpty()) { Dim("This design has no extra data options.", Modifier.padding(top = 12.dp)); return }
    fields.forEach { f ->
        when (f) {
            is Field.Toggle -> SwitchRow(f.label, cfg.flag(f.key, f.def)) { v -> vm.update { it.withFlag(f.key, v) } }
            is Field.Str -> { SectionLabel(f.label); WsTextField(cfg.str(f.key, f.def), f.hint.ifEmpty { f.label }, multiline = f.multiline) { v -> vm.update { it.with(f.key, v) } } }
            is Field.Choice -> { SectionLabel(f.label); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { f.options.forEachIndexed { i, o -> WsChip(o, cfg.idx(f.key, f.def) == i, { vm.update { it.with(f.key, i.toString()) } }) } } }
            is Field.DateF -> DateField(f, cfg) { v -> vm.update { it.with(f.key, v) } }
            is Field.Apps -> AppsField(f, cfg) { v -> vm.update { it.with(f.key, v) } }
            is Field.Special -> when (f.kind) {
                "tasks" -> TasksField(vm)
                "weather" -> WeatherField(vm, cfg)
                "media" -> MediaField()
                "calendar" -> CalendarField(vm)
            }
        }
    }
}

@Composable
fun WsTextField(value: String, hint: String, modifier: Modifier = Modifier, multiline: Boolean = false, onChange: (String) -> Unit) {
    Box(modifier.fillMaxWidth().glass(14.dp).padding(14.dp)) {
        BasicTextField(
            value, onChange, Modifier.fillMaxWidth(), singleLine = !multiline, minLines = if (multiline) 3 else 1,
            textStyle = TextStyle(color = Ws.Text, fontSize = 15.sp), cursorBrush = SolidColor(Ws.Cyan),
            decorationBox = { inner -> if (value.isEmpty()) Text(hint, color = Ws.TextDim, style = TextStyle(fontSize = 15.sp)); inner() }
        )
    }
}

@Composable
private fun DateField(f: Field.DateF, cfg: WidgetConfig, onPick: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    SectionLabel(f.label)
    Row(Modifier.fillMaxWidth().glass(14.dp).clickable { open = true }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        IconView(IconKind.CALENDAR, 20.dp, Ws.Cyan); Spacer(Modifier.width(10.dp))
        Text(cfg.str(f.key, LocalDate.now().toString()), color = Ws.Text, style = TextStyle(fontSize = 15.sp))
    }
    if (open) {
        val init = runCatching { LocalDate.parse(cfg.str(f.key)).atStartOfDay().toInstant(ZoneOffset.UTC).toEpochMilli() }.getOrNull()
        val st = rememberDatePickerState(initialSelectedDateMillis = init)
        DatePickerDialog(
            onDismissRequest = { open = false },
            confirmButton = { TextButton({ st.selectedDateMillis?.let { onPick(Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate().toString()) }; open = false }) { Text("OK") } },
            dismissButton = { TextButton({ open = false }) { Text("Cancel") } }
        ) { DatePicker(state = st) }
    }
}

@Composable
private fun AppsField(f: Field.Apps, cfg: WidgetConfig, onChange: (String) -> Unit) {
    val ctx = LocalContext.current
    var open by remember { mutableStateOf(false) }
    val sel = cfg.str(f.key).split(",").filter { it.isNotBlank() }
    SectionLabel("${f.label} (${sel.size}/${f.max})")
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        sel.forEach { p -> WsChip(DataProvider.appLabel(ctx, p) ?: p, true, { onChange(sel.filter { it != p }.joinToString(",")) }) }
    }
    GhostButton("Choose apps", Modifier.padding(top = 8.dp), IconKind.GRID) { open = true }
    if (open) {
        val apps by produceState<List<DataProvider.LaunchableApp>>(emptyList()) { value = withContext(Dispatchers.IO) { DataProvider.launchableApps(ctx) } }
        var picked by remember { mutableStateOf(sel) }
        AlertDialog(
            onDismissRequest = { open = false }, containerColor = Ws.Surface,
            title = { Text("Choose up to ${f.max} apps", color = Ws.Text) },
            text = {
                LazyColumn(Modifier.heightIn(max = 380.dp)) {
                    items(apps, key = { it.pkg }) { a ->
                        val on = a.pkg in picked
                        Row(Modifier.fillMaxWidth().clickable { picked = if (on) picked - a.pkg else if (picked.size < f.max) picked + a.pkg else picked }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(on, null, colors = CheckboxDefaults.colors(checkedColor = Ws.Cyan))
                            Text(a.label, color = Ws.Text)
                        }
                    }
                }
            },
            confirmButton = { TextButton({ onChange(picked.joinToString(",")); open = false }) { Text("Done", color = Ws.Cyan) } },
            dismissButton = { TextButton({ open = false }) { Text("Cancel", color = Ws.TextDim) } }
        )
    }
}

@Composable
private fun TasksField(vm: AppViewModel) {
    val tasks by vm.tasks.collectAsState()
    var text by remember { mutableStateOf("") }
    SectionLabel("Tasks (shared by all task widgets)")
    tasks.forEach { t ->
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.clickable { vm.toggleTask(t.id) }.padding(4.dp)) { IconView(if (t.done) IconKind.CHECK else IconKind.EMPTY_BOX, 22.dp, if (t.done) Ws.Mint else Ws.TextDim) }
            Text(t.text, Modifier.weight(1f).padding(start = 8.dp), color = if (t.done) Ws.TextDim else Ws.Text)
            Box(Modifier.clickable { vm.deleteTask(t.id) }.padding(6.dp)) { IconView(IconKind.TRASH, 20.dp, Ws.TextDim) }
        }
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        WsTextField(text, "Add a task", Modifier.weight(1f)) { text = it }
        Spacer(Modifier.width(8.dp))
        NeonButton("Add") { vm.addTask(text); text = "" }
    }
}

@Composable
private fun WeatherField(vm: AppViewModel, cfg: WidgetConfig) {
    SectionLabel("City")
    WsTextField(cfg.str("city"), "e.g. Cairo") { v -> vm.update { it.with("city", v) } }
    Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        NeonButton("Save & fetch", enabled = cfg.str("city").isNotBlank()) { vm.fetchCity(cfg.str("city")) }
        Dim(vm.cityStatus, Modifier.padding(start = 12.dp).weight(1f), 12)
    }
    Dim("No location permission needed. Forecast data from Open-Meteo, refreshed in the background.", Modifier.padding(top = 6.dp), 12)
}

@Composable
private fun MediaField() {
    val ctx = LocalContext.current
    SectionLabel("Now-playing info")
    Dim(if (DataProvider.mediaAccessEnabled(ctx)) "Notification access is enabled. Titles update when playback changes." else "Optional. Enable notification access for Widget Studio to show the current track. Play/pause/skip buttons work without it.")
    GhostButton("Open access settings", Modifier.padding(top = 8.dp)) { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
}

@Composable
private fun CalendarField(vm: AppViewModel) {
    val ctx = LocalContext.current
    var ok by remember { mutableStateOf(DataProvider.hasCalendar(ctx)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok = it; vm.reloadPreviewData(); vm.refreshAllWidgets() }
    SectionLabel("Calendar access")
    Dim(if (ok) "Granted. Upcoming events from all your calendars are shown." else "Needed to list your upcoming events. Nothing leaves your device.")
    if (!ok) GhostButton("Grant access", Modifier.padding(top = 8.dp)) { launcher.launch(Manifest.permission.READ_CALENDAR) }
}

/** Shown after "Add to Home Screen" when the launcher can't (or didn't) pin directly. */
@Composable
fun PinDialog(vm: AppViewModel) {
    val r = vm.pinResult ?: return
    val e = vm.editor
    val ctx = LocalContext.current
    if (r == Pinner.Result.REQUESTED) {
        LaunchedEffect(r) { Toast.makeText(ctx, "Confirm in your launcher to place the widget", Toast.LENGTH_LONG).show(); vm.pinResult = null }
        return
    }
    val sizeLabel = e?.cfg?.size?.label ?: "widget"
    AlertDialog(
        onDismissRequest = { vm.pinResult = null }, containerColor = Ws.Surface,
        title = { Text(if (r == Pinner.Result.UNSUPPORTED) "Your launcher can't pin widgets" else "The launcher didn't accept the request", color = Ws.Text) },
        text = {
            Column {
                Text("Your design is saved and will be applied automatically when you add it manually (valid for 30 minutes):", color = Ws.Text)
                Spacer(Modifier.height(10.dp))
                Dim("1. Long-press an empty spot on your home screen.\n2. Tap Widgets.\n3. Find Widget Studio and drag “$sizeLabel” onto the screen.\n4. If a chooser appears, just confirm; no setup needed.")
            }
        },
        confirmButton = { TextButton({ vm.pinResult = null }) { Text("Got it", color = Ws.Cyan) } }
    )
}
