package com.example.widgetstudio.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.widgetstudio.ui.effects.GlassCard
import kotlinx.coroutines.delay

enum class Demo(val title: String, val subtitle: String, val emoji: String, val tint: Color) {
    CLOCK("ساعات Pill و Flip", "أرقام تنقلب وحلقة ثواني متحركة", "🕰", Color(0xFFE6DFD0)),
    WEATHER("الطقس الزجاجي", "مشاهد متغيرة وضباب وأرقام تعدّ تصاعدياً", "🌲", Color(0xFF6FCF97)),
    PILLS("أزرار الاختصارات", "مفاتيح تنزلق وتفتح انستجرام وواتساب والاتصال", "💊", Color(0xFF7C9CFF)),
    HUD("لوحة HUD", "بوصلة حقيقية وعداد سرعة بإبرة نابضة", "🧭", Color(0xFFFFC857)),
    RING("حلقة التطبيقات", "تطبيقات تدور حول الساعة وتنفجر عند اللمس", "🪐", Color(0xFFFF7A90))
}

@Composable
fun GalleryScreen(onOpen: (Demo) -> Unit) {
    val t = rememberInfiniteTransition(label = "title")
    val x by t.animateFloat(
        initialValue = 0f,
        targetValue = 600f,
        animationSpec = infiniteRepeatable(tween(2800, easing = LinearEasing), RepeatMode.Restart),
        label = "shimmer"
    )
    val brush = Brush.linearGradient(
        colors = listOf(Color(0xFF9FB4FF), Color.White, Color(0xFFE6DFD0), Color(0xFF9FB4FF)),
        start = Offset(x, 0f),
        end = Offset(x + 300f, 120f),
        tileMode = TileMode.Mirror
    )

    LazyColumn(
        Modifier.statusBarsPadding().navigationBarsPadding(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column(Modifier.padding(top = 12.dp, bottom = 8.dp)) {
                Text(
                    "Widget Studio",
                    style = TextStyle(brush = brush, fontSize = 38.sp, fontWeight = FontWeight.Light)
                )
                Text("ودجات وتصاميم متحركة", color = Color.White.copy(0.65f), fontSize = 15.sp)
            }
        }
        itemsIndexed(Demo.entries) { index, demo -> GalleryCard(index, demo) { onOpen(demo) } }
        item {
            GlassCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp)) {
                    Text("📌 ضيف الودجات على الشاشة الرئيسية", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "اضغط مطولاً على الشاشة الرئيسية ← Widgets ← Widget Studio، واختر Pill Clock أو Shortcut Pills.",
                        color = Color.White.copy(0.7f),
                        fontSize = 13.sp,
                        lineHeight = 20.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun GalleryCard(index: Int, demo: Demo, onClick: () -> Unit) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(120L + index * 110L)
        visible = true
    }
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(550)) + slideInVertically(tween(550)) { it / 3 }
    ) {
        val breathe = rememberInfiniteTransition(label = "breathe")
        val s by breathe.animateFloat(
            initialValue = 1f,
            targetValue = 1.1f,
            animationSpec = infiniteRepeatable(tween(1800 + index * 250), RepeatMode.Reverse),
            label = "scale"
        )
        GlassCard(Modifier.fillMaxWidth(), onClick = onClick) {
            Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(58.dp).scale(s).background(demo.tint.copy(0.22f), CircleShape),
                    contentAlignment = Alignment.Center
                ) { Text(demo.emoji, fontSize = 28.sp) }
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(demo.title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(4.dp))
                    Text(demo.subtitle, color = Color.White.copy(0.65f), fontSize = 13.sp)
                }
            }
        }
    }
}
