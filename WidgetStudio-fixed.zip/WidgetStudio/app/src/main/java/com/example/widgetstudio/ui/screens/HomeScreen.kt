package com.example.widgetstudio.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.widgetstudio.core.Category
import com.example.widgetstudio.core.IconKind
import com.example.widgetstudio.designs.Registry
import com.example.widgetstudio.ui.AppViewModel
import com.example.widgetstudio.ui.Route
import com.example.widgetstudio.ui.components.*
import com.example.widgetstudio.ui.theme.Ws
import com.example.widgetstudio.wallpaper.openLiveWallpaperPicker

@Composable
fun HomeScreen(vm: AppViewModel) {
    val recents by vm.recents.collectAsState()
    val favs by vm.favorites.collectAsState()
    val ctx = LocalContext.current
    LazyColumn(Modifier.fillMaxSize().statusBarsPadding(), contentPadding = PaddingValues(top = 8.dp, bottom = 130.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Row(Modifier.padding(horizontal = 20.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(44.dp).clip(CircleShape).background(Ws.AccentBrush), contentAlignment = Alignment.Center) { IconView(IconKind.SPARKLE, 22.dp, Ws.Bg) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) { H2("Widget Studio"); Dim("${Registry.all.size} designs · ${Category.entries.size} categories") }
                Box(Modifier.glass(50.dp).clickable { vm.goRoot(Route.Library()) }.padding(12.dp)) { IconView(IconKind.SEARCH, 20.dp) }
            }
        }
        item { Text("Design your home screen.", Modifier.padding(horizontal = 20.dp), color = Ws.Text, style = TextStyle(fontSize = 34.sp, fontWeight = FontWeight.Light, lineHeight = 40.sp)) }
        item { SectionHeader("Featured") }
        item {
            LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                items(Registry.featured(), key = { it.id }) { d ->
                    Column(Modifier.width(290.dp).glass(28.dp).clickable { vm.openNew(d.id) }.padding(12.dp)) {
                        Box(Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(20.dp)).background(Backdrop.PHOTO.brush), contentAlignment = Alignment.Center) {
                            DesignThumb(d, vm, Modifier.padding(10.dp), maxH = 130.dp)
                        }
                        Text(d.name, Modifier.padding(top = 10.dp), color = Ws.Text, style = TextStyle(fontSize = 18.sp, fontWeight = FontWeight.Medium))
                        Dim(d.tag)
                        Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Dim(d.cat.title, Modifier.weight(1f), 12)
                            NeonButton("Customise", icon = IconKind.WIDGET) { vm.openNew(d.id) }
                        }
                    }
                }
            }
        }
        item { SectionHeader("Browse by category") }
        item {
            LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(Category.entries.toList(), key = { it.name }) { c ->
                    Row(Modifier.glass(18.dp).clickable { vm.goRoot(Route.Library(c)) }.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconView(c.icon, 18.dp, Ws.Cyan); Spacer(Modifier.width(8.dp))
                        Text(c.title, color = Ws.Text, style = TextStyle(fontSize = 13.sp, fontWeight = FontWeight.Medium))
                    }
                }
            }
        }
        val rec = recents.mapNotNull { Registry.get(it) }
        if (rec.isNotEmpty()) {
            item { SectionHeader("Recently used") }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(rec, key = { it.id }) { d -> DesignCard(d, vm, d.id in favs, Modifier.width(190.dp), 100.dp) { vm.openNew(d.id) } }
                }
            }
        }
        item { SectionHeader("Beyond widgets") }
        item {
            Row(Modifier.padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                FeatureTile("Live Wallpaper", "Truly animated, battery-aware", IconKind.SPARKLE, Modifier.weight(1f)) { openLiveWallpaperPicker(ctx) }
                FeatureTile("Live Lab", "Animated interactive demos", IconKind.RADAR, Modifier.weight(1f)) { vm.push(Route.Lab) }
            }
        }
    }
}

@Composable
private fun SectionHeader(text: String) = Box(Modifier.padding(horizontal = 20.dp, vertical = 4.dp)) { H2(text) }

@Composable
private fun FeatureTile(title: String, sub: String, icon: IconKind, modifier: Modifier, onClick: () -> Unit) {
    Column(modifier.glass(22.dp).clickable(onClick = onClick).padding(16.dp)) {
        IconView(icon, 24.dp, Ws.Violet)
        Text(title, Modifier.padding(top = 10.dp), color = Ws.Text, style = TextStyle(fontSize = 15.sp, fontWeight = FontWeight.Medium))
        Dim(sub, size = 12)
    }
}
