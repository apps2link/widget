package com.example.widgetstudio.ui.screens

import android.content.Context
import android.graphics.Paint
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.widgetstudio.ui.effects.GlassCard
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

private val Gold = Color(0xFFE8B86D)

@Composable
fun HudScreen(onBack: () -> Unit) {
    val heading = rememberHeading()
    val norm = ((heading % 360f) + 360f) % 360f
    val dirs = listOf("N", "NE", "E", "SE", "S", "SW", "W", "NW")
    val dir = dirs[((norm + 22.5f) / 45f).toInt() % 8]

    var target by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        while (true) {
            target = Random.nextInt(20, 181).toFloat()
            delay(2200)
        }
    }
    val speed by animateFloatAsState(
        target, spring(Spring.DampingRatioLowBouncy, Spring.StiffnessVeryLow), label = "speed"
    )

    DemoScaffold("لوحة HUD", onBack) {
        Column(
            Modifier.verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            GlassCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    CompassDial(heading, Modifier.fillMaxWidth().aspectRatio(1f))
                    Text(
                        "${norm.toInt()}°  $dir",
                        color = Gold, fontSize = 28.sp, fontWeight = FontWeight.Light
                    )
                }
            }
            GlassCard(Modifier.fillMaxWidth()) {
                Box(Modifier.padding(16.dp)) {
                    SpeedGauge(speed, Modifier.fillMaxWidth().aspectRatio(1f))
                    Column(
                        Modifier.align(Alignment.BottomCenter),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            "${speed.toInt()}", color = Color.White,
                            fontSize = 48.sp, fontWeight = FontWeight.Light
                        )
                        Text("km/h  (demo)", color = Color.White.copy(0.6f), fontSize = 13.sp)
                    }
                }
            }
        }
    }
}

/** Real compass via rotation-vector sensor; auto-sweeps in demo mode if no sensor exists. */
@Composable
private fun rememberHeading(): Float {
    val ctx = LocalContext.current
    var raw by remember { mutableFloatStateOf(0f) }
    var hasSensor by remember { mutableStateOf(true) }

    DisposableEffect(Unit) {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensor = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        if (sensor == null) {
            hasSensor = false
            onDispose { }
        } else {
            var last = Float.NaN
            val listener = object : SensorEventListener {
                override fun onSensorChanged(e: SensorEvent) {
                    val m = FloatArray(9)
                    SensorManager.getRotationMatrixFromVector(m, e.values)
                    val o = FloatArray(3)
                    SensorManager.getOrientation(m, o)
                    val deg = ((Math.toDegrees(o[0].toDouble()) + 360.0) % 360.0).toFloat()
                    if (last.isNaN()) {
                        raw = deg
                    } else {
                        var d = deg - last
                        if (d > 180f) d -= 360f
                        if (d < -180f) d += 360f
                        raw += d
                    }
                    last = deg
                }
                override fun onAccuracyChanged(s: Sensor?, a: Int) {}
            }
            sm.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_GAME)
            onDispose { sm.unregisterListener(listener) }
        }
    }

    val smooth by animateFloatAsState(raw, tween(120, easing = LinearEasing), label = "heading")
    val t = rememberInfiniteTransition(label = "demo-heading")
    val demo by t.animateFloat(0f, 360f, infiniteRepeatable(tween(18000, easing = LinearEasing)), label = "demo")
    return if (hasSensor) smooth else demo
}

@Composable
private fun CompassDial(heading: Float, modifier: Modifier) {
    Canvas(modifier) {
        val c = center
        val r = size.minDimension / 2f * 0.94f
        drawCircle(Color.White.copy(0.05f), r, c)
        drawCircle(Gold.copy(0.5f), r, c, style = Stroke(1.5.dp.toPx()))
        drawCircle(Gold.copy(0.2f), r * 0.55f, c, style = Stroke(1.dp.toPx()))

        rotate(-heading, c) {
            for (deg in 0 until 360 step 5) {
                val major = deg % 90 == 0
                val mid = deg % 30 == 0
                val len = when {
                    major -> 22.dp.toPx()
                    mid -> 14.dp.toPx()
                    else -> 7.dp.toPx()
                }
                val a = Math.toRadians(deg - 90.0)
                val s = Offset(c.x + (r - len) * cos(a).toFloat(), c.y + (r - len) * sin(a).toFloat())
                val e = Offset(c.x + r * cos(a).toFloat(), c.y + r * sin(a).toFloat())
                drawLine(
                    if (major) Gold else Color.White.copy(0.55f), s, e,
                    strokeWidth = if (major) 3.dp.toPx() else 1.5.dp.toPx()
                )
            }
            val paint = Paint().apply {
                isAntiAlias = true
                textAlign = Paint.Align.CENTER
                textSize = 22.sp.toPx()
                isFakeBoldText = true
            }
            drawIntoCanvas { canvas ->
                listOf("N" to 0, "E" to 90, "S" to 180, "W" to 270).forEach { (txt, deg) ->
                    val a = Math.toRadians(deg - 90.0)
                    val rr = r - 46.dp.toPx()
                    val px = c.x + rr * cos(a).toFloat()
                    val py = c.y + rr * sin(a).toFloat()
                    paint.color = if (txt == "N") 0xFFFF5252.toInt() else 0xFFFFFFFF.toInt()
                    canvas.nativeCanvas.save()
                    canvas.nativeCanvas.rotate(deg.toFloat(), px, py)
                    canvas.nativeCanvas.drawText(txt, px, py + paint.textSize / 3f, paint)
                    canvas.nativeCanvas.restore()
                }
            }
        }

        // fixed needle (does not rotate)
        val w = 10.dp.toPx()
        val north = Path().apply {
            moveTo(c.x, c.y - r * 0.5f); lineTo(c.x - w, c.y); lineTo(c.x + w, c.y); close()
        }
        val south = Path().apply {
            moveTo(c.x, c.y + r * 0.5f); lineTo(c.x - w, c.y); lineTo(c.x + w, c.y); close()
        }
        drawPath(north, Color(0xFFFF5252))
        drawPath(south, Color.White.copy(0.55f))
        drawCircle(Color.Black, 6.dp.toPx(), c)
        drawCircle(Gold, 3.dp.toPx(), c)
    }
}

@Composable
private fun SpeedGauge(speed: Float, modifier: Modifier) {
    Canvas(modifier) {
        val c = center
        val r = size.minDimension * 0.4f
        val sw = 14.dp.toPx()
        val topLeft = Offset(c.x - r, c.y - r)
        val arcSize = Size(2 * r, 2 * r)
        val frac = (speed / 200f).coerceIn(0f, 1f)

        drawArc(
            Color.White.copy(0.1f), 135f, 270f, false, topLeft, arcSize,
            style = Stroke(sw, cap = StrokeCap.Round)
        )
        rotate(135f, c) {
            drawArc(
                brush = Brush.sweepGradient(
                    colorStops = arrayOf(
                        0f to Color(0xFF4DD0E1), 0.375f to Color(0xFFFFC857),
                        0.75f to Color(0xFFFF5252), 1f to Color(0xFFFF5252)
                    ),
                    center = c
                ),
                startAngle = 0f, sweepAngle = 270f * frac, useCenter = false,
                topLeft = topLeft, size = arcSize,
                style = Stroke(sw, cap = StrokeCap.Round)
            )
        }
        for (i in 0..20) {
            val a = Math.toRadians(135.0 + 270.0 * i / 20.0)
            val len = if (i % 5 == 0) 14.dp.toPx() else 7.dp.toPx()
            val r1 = r - sw - 6.dp.toPx()
            drawLine(
                Color.White.copy(0.6f),
                Offset(c.x + r1 * cos(a).toFloat(), c.y + r1 * sin(a).toFloat()),
                Offset(c.x + (r1 - len) * cos(a).toFloat(), c.y + (r1 - len) * sin(a).toFloat()),
                strokeWidth = 2.dp.toPx()
            )
        }
        val na = Math.toRadians(135.0 + 270.0 * frac)
        val nr = r - sw - 22.dp.toPx()
        drawLine(
            Color(0xFFFF5252), c,
            Offset(c.x + nr * cos(na).toFloat(), c.y + nr * sin(na).toFloat()),
            strokeWidth = 4.dp.toPx(), cap = StrokeCap.Round
        )
        drawCircle(Color.Black, 9.dp.toPx(), c)
        drawCircle(Color(0xFFFF5252), 4.dp.toPx(), c)
    }
}
