package com.example.widgetstudio.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.widgetstudio.core.Category
import com.example.widgetstudio.core.IconKind
import com.example.widgetstudio.designs.Registry
import com.example.widgetstudio.ui.AppViewModel
import com.example.widgetstudio.ui.Route
import com.example.widgetstudio.ui.components.*
import com.example.widgetstudio.ui.theme.Ws

@Composable
fun LibraryScreen(vm: AppViewModel, initial: Category?, pickMode: Boolean) {
    var query by remember { mutableStateOf("") }
    var cat by remember(initial) { mutableStateOf(initial) }
    val favs by vm.favorites.collectAsState()
    val list = Registry.search(query).filter { (cat == null || it.cat == cat) && (vm.configSize == null || vm.configSize in it.sizes) }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        ScreenTitle(if (pickMode) "Choose a design" else "Widget Library", "${list.size} designs")
        Row(Modifier.padding(horizontal = 20.dp).fillMaxWidth().glass(18.dp).padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconView(IconKind.SEARCH, 18.dp, Ws.TextDim)
            Spacer(Modifier.width(10.dp))
            BasicTextField(
                query, { query = it }, Modifier.weight(1f), singleLine = true,
                textStyle = TextStyle(color = Ws.Text, fontSize = 15.sp), cursorBrush = SolidColor(Ws.Cyan),
                decorationBox = { inner -> if (query.isEmpty()) Text("Search clocks, weather, neon…", color = Ws.TextDim, style = TextStyle(fontSize = 15.sp)); inner() }
            )
            if (query.isNotEmpty()) Box(Modifier.clickable { query = "" }) { IconView(IconKind.CLOSE, 16.dp, Ws.TextDim) }
        }
        LazyRow(contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item { WsChip("All", cat == null, { cat = null }) }
            items(Category.entries.toList(), key = { it.name }) { c -> WsChip(c.title, cat == c, { cat = c }) }
        }
        if (list.isEmpty()) EmptyState(IconKind.SEARCH, "No matches", "Try a different word or clear the category filter.")
        else DesignGrid(vm, list.map { it }, favs, Modifier.weight(1f))
    }
}

@Composable
fun DesignGrid(vm: AppViewModel, list: List<com.example.widgetstudio.designs.Design>, favs: Set<String>, modifier: Modifier = Modifier) {
    LazyVerticalGrid(
        GridCells.Fixed(2), modifier, contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 130.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(list, key = { it.id }) { d -> DesignCard(d, vm, d.id in favs) { vm.openNew(d.id, configMode = vm.configWidgetId != null) } }
    }
}

@Composable
fun FavoritesScreen(vm: AppViewModel) {
    val favs by vm.favorites.collectAsState()
    val list = Registry.all.filter { it.id in favs }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        ScreenTitle("Favorites", if (list.isEmpty()) "Tap the heart on any design" else "${list.size} saved")
        if (list.isEmpty()) EmptyState(IconKind.HEART_O, "Nothing here yet", "Hearts you add in the library show up here for quick access.") {
            NeonButton("Browse library", icon = IconKind.GRID) { vm.goRoot(Route.Library()) }
        } else DesignGrid(vm, list, favs, Modifier.weight(1f))
    }
}
