package com.example.widgetstudio.ui.screens

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.widgetstudio.core.IconKind
import com.example.widgetstudio.render.WidgetPreview
import com.example.widgetstudio.ui.AppViewModel
import com.example.widgetstudio.ui.components.*
import com.example.widgetstudio.ui.theme.Ws

/**
 * Full-screen interactive preview. This is where pulse, light sweep, liquid waves, waveforms and the
 * radar sweep actually animate (phase 0..1 drives the same painters the widget uses).
 * Standard home-screen widgets can't do this, so we don't pretend they can.
 */
@Composable
fun LivePreviewScreen(vm: AppViewModel) {
    val e = vm.editor ?: return
    val cfg = e.cfg
    val t = rememberInfiniteTransition(label = "live")
    val phase = t.animateFloat(0f, 1f, infiniteRepeatable(tween(6000, easing = LinearEasing), RepeatMode.Restart), label = "phase")
    val drift = t.animateFloat(0f, 1f, infiniteRepeatable(tween(14000, easing = LinearEasing), RepeatMode.Reverse), label = "drift")
    val now = rememberNow(1000)
    val node = remember(cfg, vm.editorData) { e.design.node(cfg, cfg.size.wDp, cfg.size.hDp, vm.editorData) }
    Box(Modifier.fillMaxSize()) {
        Canvas(Modifier.fillMaxSize()) {
            val k = drift.value
            drawRect(Brush.linearGradient(listOf(Color(0xFF0A1030), Color(0xFF2A0F3F), Color(0xFF0B4A5A)), Offset(size.width * k, 0f), Offset(size.width * (1f - k), size.height)))
        }
        WidgetPreview(node, cfg.size.wDp, cfg.size.hDp, phase, now, Modifier.align(Alignment.Center).padding(horizontal = 24.dp), maxHeight = 420.dp)
        Row(Modifier.statusBarsPadding().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.glass(50.dp).clickable { vm.pop() }.padding(12.dp)) { IconView(IconKind.CLOSE, 20.dp) }
            Spacer(Modifier.width(12.dp)); H2("Live Preview")
        }
        Column(Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(24.dp).glass(20.dp).padding(14.dp)) {
            Dim("Effects animate here only. On the home screen the same widget redraws on events and periodic updates to protect your battery.", size = 12)
        }
    }
}
