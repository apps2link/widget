package com.example.widgetstudio.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.widgetstudio.core.Data
import com.example.widgetstudio.core.IconKind
import com.example.widgetstudio.core.Preset
import com.example.widgetstudio.core.WidgetConfig
import com.example.widgetstudio.data.DataProvider
import com.example.widgetstudio.designs.Registry
import com.example.widgetstudio.render.WidgetPreview
import com.example.widgetstudio.ui.AppViewModel
import com.example.widgetstudio.ui.Route
import com.example.widgetstudio.ui.components.*
import com.example.widgetstudio.ui.theme.Ws
import com.example.widgetstudio.widgets.Pinner
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope

@Composable
fun MyWidgetsScreen(vm: AppViewModel) {
    val configs by vm.configs.collectAsState()
    val presets by vm.presets.collectAsState()
    val live = vm.installed.filter { configs.containsKey(it.id) }
    LazyColumn(Modifier.fillMaxSize().statusBarsPadding(), contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 130.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            ScreenTitle("My Widgets", "${live.size} on your home screen") {
                Box(Modifier.glass(50.dp).clickable { vm.refresh(); vm.refreshAllWidgets() }.padding(12.dp)) { IconView(IconKind.SPARKLE, 20.dp, Ws.Cyan) }
            }
        }
        if (live.isEmpty()) item {
            EmptyState(IconKind.WIDGET, "No widgets yet", "Design one and press Add to Home Screen. It will appear here so you can fine-tune it any time.") {
                NeonButton("Open library", icon = IconKind.GRID) { vm.goRoot(Route.Library()) }
            }
        }
        items(live, key = { it.id }) { inst ->
            val cfg = configs[inst.id] ?: return@items
            val design = Registry.get(cfg.designId) ?: return@items
            InstanceCard(vm, inst.id, cfg, design.name, design.cat.title)
        }
        item { SectionLabel("Saved presets") }
        if (presets.isEmpty()) item { Dim("Use “Save preset” in the editor to keep a look you like and reuse it later.") }
        items(presets, key = { it.name }) { p -> PresetRow(vm, p) }
    }
}

@Composable
private fun InstanceCard(vm: AppViewModel, id: Int, cfg: WidgetConfig, name: String, cat: String) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val data by produceState<Data>(vm.thumbData, cfg) { value = DataProvider.forPreview(ctx, cfg) }
    val design = Registry.get(cfg.designId)!!
    val node = remember(cfg, data) { design.node(cfg, cfg.size.wDp, cfg.size.hDp, data) }
    val phase = remember { mutableStateOf(0f) }
    val now = rememberNow(20_000)
    Column(Modifier.fillMaxWidth().glass(26.dp).padding(14.dp)) {
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Backdrop.PHOTO.brush).padding(12.dp), contentAlignment = Alignment.Center) {
            WidgetPreview(node, cfg.size.wDp, cfg.size.hDp, phase, now, Modifier, maxHeight = 170.dp)
        }
        Text(name, Modifier.padding(top = 10.dp), color = Ws.Text, style = TextStyle(fontSize = 17.sp, fontWeight = FontWeight.Medium))
        Dim("$cat · ${cfg.size.label} · widget #$id", size = 12)
        Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            NeonButton("Edit", Modifier.weight(1f), IconKind.EDIT) { vm.openInstance(id) }
            GhostButton("Duplicate", Modifier.weight(1f), IconKind.PLUS) { scope.launch { vm.pinResult = Pinner.request(ctx, cfg) } }
        }
    }
}

@Composable
private fun PresetRow(vm: AppViewModel, p: Preset) {
    val design = Registry.get(p.config.designId) ?: return
    Row(Modifier.fillMaxWidth().glass(20.dp).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(p.name, color = Ws.Text, style = TextStyle(fontSize = 15.sp, fontWeight = FontWeight.Medium))
            Dim("${design.name} · ${p.config.size.label}", size = 12)
        }
        GhostButton("Use") { vm.openNew(design.id, p.config) }
        Spacer(Modifier.width(8.dp))
        Box(Modifier.clickable { vm.deletePreset(p.name) }.padding(8.dp)) { IconView(IconKind.TRASH, 20.dp, Ws.TextDim) }
    }
}
