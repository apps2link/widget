package com.example.widgetstudio.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.BiasAlignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.widgetstudio.R
import com.example.widgetstudio.util.Launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun PillsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    DemoScaffold("أزرار الاختصارات", onBack) {
        Column(verticalArrangement = Arrangement.spacedBy(18.dp)) {
            TogglePill(
                label = "Instagram", iconRes = R.drawable.ic_ig,
                knob = Color(0xFF6F8CA3), track = Color(0xFF2E3A48), accent = Color(0xFF8E5CFF),
                knobStartsRight = false
            ) { Launch.start(ctx, Launch.appIntent(ctx, "com.instagram.android", "https://instagram.com")) }

            TogglePill(
                label = "WhatsApp", iconRes = R.drawable.ic_wa,
                knob = Color(0xFF3A3D57), track = Color(0xFF232B35), accent = Color(0xFF25D366),
                knobStartsRight = true, badge = 0
            ) { Launch.start(ctx, Launch.appIntent(ctx, "com.whatsapp", "https://wa.me")) }

            TogglePill(
                label = "Call", iconRes = R.drawable.ic_call,
                knob = Color(0xFF1A1A2E), track = Color(0xFF14151F), accent = Color(0xFF4DD0E1),
                knobStartsRight = false
            ) { Launch.start(ctx, Launch.dialerIntent()) }
        }
        Text(
            "المس المفتاح — ينزلق ثم يفتح التطبيق",
            color = Color.White.copy(0.55f), fontSize = 13.sp,
            modifier = Modifier.padding(top = 24.dp)
        )
    }
}

@Composable
private fun TogglePill(
    label: String,
    iconRes: Int,
    knob: Color,
    track: Color,
    accent: Color,
    knobStartsRight: Boolean,
    badge: Int? = null,
    onToggled: () -> Unit
) {
    var on by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val restBias = if (knobStartsRight) 1f else -1f
    val bias by animateFloatAsState(
        targetValue = if (on) -restBias else restBias,
        animationSpec = spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessLow),
        label = "bias"
    )
    val trackColor by animateColorAsState(if (on) accent.copy(0.55f) else track, tween(400), label = "track")
    val labelAlpha by animateFloatAsState(if (on) 0.35f else 1f, tween(300), label = "alpha")
    val spin by animateFloatAsState(if (on) 360f else 0f, tween(600), label = "spin")

    val pulseT = rememberInfiniteTransition(label = "pulse")
    val pulse by pulseT.animateFloat(
        1f, 1.25f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "pulse"
    )

    Box(
        Modifier
            .fillMaxWidth()
            .height(92.dp)
            .clip(CircleShape)
            .background(trackColor)
            .border(1.dp, Color.White.copy(0.18f), CircleShape)
            .clickable(enabled = !on) {
                on = true
                scope.launch {
                    delay(450)
                    onToggled()
                    delay(800)
                    on = false
                }
            }
    ) {
        Text(
            label,
            color = Color.White.copy(labelAlpha),
            fontSize = 22.sp,
            fontWeight = FontWeight.Light,
            modifier = Modifier
                .align(if (knobStartsRight) Alignment.CenterStart else Alignment.CenterEnd)
                .padding(horizontal = 36.dp)
        )
        Box(
            Modifier
                .padding(8.dp)
                .size(76.dp)
                .align(BiasAlignment(bias, 0f))
        ) {
            Box(
                Modifier.fillMaxWidth().height(76.dp).clip(CircleShape).background(knob),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    painterResource(iconRes), contentDescription = label, tint = Color.White,
                    modifier = Modifier.size(34.dp).graphicsLayer { rotationZ = spin }
                )
            }
            if (badge != null) {
                Box(
                    Modifier.align(Alignment.TopEnd).size(22.dp).scale(pulse)
                        .background(Color(0xFFE53935), CircleShape),
                    contentAlignment = Alignment.Center
                ) { Text("$badge", color = Color.White, fontSize = 11.sp) }
            }
        }
    }
}
