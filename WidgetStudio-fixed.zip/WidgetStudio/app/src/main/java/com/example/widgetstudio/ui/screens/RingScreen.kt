package com.example.widgetstudio.ui.screens

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.widgetstudio.ui.effects.GlassCard
import kotlinx.coroutines.delay
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

private data class RingApp(val emoji: String, val color: Color)

private val apps = listOf(
    RingApp("📞", Color(0xFF2ECC71)), RingApp("📷", Color(0xFF8E8E93)),
    RingApp("🌐", Color(0xFFFF7043)), RingApp("🎵", Color(0xFF1DB954)),
    RingApp("💬", Color(0xFF4A90E2)), RingApp("🧭", Color(0xFFE8B86D)),
    RingApp("⚙️", Color(0xFF5C6BC0)), RingApp("🗺", Color(0xFFEF5350))
)

@Composable
fun RingScreen(onBack: () -> Unit) {
    var expanded by remember { mutableStateOf(true) }
    val factor by animateFloatAsState(
        if (expanded) 1f else 0f,
        spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessLow),
        label = "expand"
    )
    val orbit = rememberInfiniteTransition(label = "orbit")
    val rot by orbit.animateFloat(0f, 360f, infiniteRepeatable(tween(40000, easing = LinearEasing)), label = "rot")
    val time by produceState("") {
        while (true) {
            value = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"))
            delay(1000)
        }
    }

    DemoScaffold("حلقة التطبيقات", onBack) {
        BoxWithConstraints(Modifier.fillMaxWidth().weight(1f)) {
            val density = LocalDensity.current
            val radius = with(density) { (minOf(maxWidth, maxHeight) / 2 - 38.dp).toPx() }

            Canvas(Modifier.fillMaxSize()) {
                rotate(-rot * 0.5f, center) {
                    drawCircle(
                        Color.White.copy(0.18f), radius * factor.coerceAtLeast(0.01f), center,
                        style = Stroke(
                            1.5.dp.toPx(),
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 14f))
                        )
                    )
                }
            }

            apps.forEachIndexed { i, app ->
                Box(
                    Modifier
                        .align(Alignment.Center)
                        .offset {
                            val a = Math.toRadians((rot + i * 360.0 / apps.size) - 90.0)
                            IntOffset(
                                (cos(a) * radius * factor).roundToInt(),
                                (sin(a) * radius * factor).roundToInt()
                            )
                        }
                        .graphicsLayer {
                            alpha = factor.coerceIn(0f, 1f)
                            val s = 0.4f + 0.6f * factor
                            scaleX = s; scaleY = s
                        }
                        .size(62.dp)
                        .clip(RoundedCornerShape(22.dp))
                        .background(app.color.copy(0.85f)),
                    contentAlignment = Alignment.Center
                ) { Text(app.emoji, fontSize = 28.sp) }
            }

            GlassCard(
                Modifier.align(Alignment.Center).size(150.dp),
                shape = CircleShape,
                onClick = { expanded = !expanded }
            ) {
                Text(
                    time,
                    color = Color.White,
                    fontSize = 40.sp,
                    fontWeight = FontWeight.Light,
                    modifier = Modifier.align(Alignment.Center)
                )
            }
        }
        Text(
            "المس الساعة لتجميع التطبيقات أو نشرها",
            color = Color.White.copy(0.55f), fontSize = 13.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
    }
}
