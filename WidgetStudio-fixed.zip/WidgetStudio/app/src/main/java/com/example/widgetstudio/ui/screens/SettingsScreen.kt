package com.example.widgetstudio.ui.screens

import android.Manifest
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.widgetstudio.core.IconKind
import com.example.widgetstudio.data.DataProvider
import com.example.widgetstudio.ui.AppViewModel
import com.example.widgetstudio.ui.components.*
import com.example.widgetstudio.ui.theme.Ws
import com.example.widgetstudio.wallpaper.openLiveWallpaperPicker

@Composable
fun SettingsScreen(vm: AppViewModel) {
    val s by vm.settings.collectAsState()
    val ctx = LocalContext.current
    var wp by remember { mutableIntStateOf(vm.wallpaperTheme()) }
    var calendarOk by remember { mutableStateOf(DataProvider.hasCalendar(ctx)) }
    val calLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { calendarOk = it; vm.refreshAllWidgets() }
    val pinSupported = remember { AppWidgetManager.getInstance(ctx).isRequestPinAppWidgetSupported }

    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(bottom = 130.dp)) {
        ScreenTitle("Settings", "Battery, data and permissions")
        Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Card("Update frequency") {
                Dim("Home-screen widgets never redraw continuously. Clocks tick by themselves; everything else refreshes on system events plus a background job at this pace.")
                Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Battery saver", "Balanced", "Frequent").forEachIndexed { i, l -> WsChip(l, s.updateMode == i, { vm.setUpdateMode(i) }) }
                }
                Dim(when (s.updateMode) { 0 -> "Live data every 60 min · weather every 2 h"; 2 -> "Live data every 15 min · weather every 30 min"; else -> "Live data every 30 min · weather every 60 min" }, Modifier.padding(top = 8.dp), 12)
            }
            Card("Units & motion") {
                SwitchRow("Temperature in °F", s.fahrenheit) { vm.setFahrenheit(it) }
                SwitchRow("Reduce motion", s.reducedMotion, "Calms the app background and lowers the live wallpaper frame rate") { vm.setReducedMotion(it) }
            }
            Card("Live wallpaper") {
                Dim("The only place with continuous animation. It pauses whenever the screen is off or covered.")
                Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Aurora", "Particles", "Neon grid").forEachIndexed { i, l -> WsChip(l, wp == i, { wp = i; vm.setWallpaperTheme(i) }) }
                }
                NeonButton("Set live wallpaper", Modifier.padding(top = 12.dp), IconKind.SPARKLE) { openLiveWallpaperPicker(ctx) }
            }
            Card("Permissions (all optional)") {
                PermRow("Calendar for Agenda widgets", calendarOk, "Grant") { calLauncher.launch(Manifest.permission.READ_CALENDAR) }
                PermRow("Media info for music widgets", DataProvider.mediaAccessEnabled(ctx), "Open settings") { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            }
            Card("Your launcher") {
                Text(if (pinSupported) "Direct pinning is supported. “Add to Home Screen” places widgets for you." else "This launcher can't pin widgets directly. Use the manual steps shown after pressing “Add to Home Screen”; your design is kept for 30 minutes.", color = Ws.Text)
            }
            Card("About") { Dim("Widget Studio 2.0 · Glance, DataStore, WorkManager. Weather by Open-Meteo.") }
        }
    }
}

@Composable
private fun Card(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().glass(22.dp).padding(16.dp)) { H2(title); Spacer(Modifier.height(6.dp)); content() }
}

@Composable
private fun PermRow(label: String, ok: Boolean, action: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(label, color = Ws.Text); Dim(if (ok) "Enabled" else "Not enabled", size = 12) }
        if (!ok) GhostButton(action, onClick = onClick) else IconView(IconKind.CHECK, 22.dp, Ws.Mint)
    }
}
