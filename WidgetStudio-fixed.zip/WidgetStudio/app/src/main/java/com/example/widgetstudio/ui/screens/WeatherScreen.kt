package com.example.widgetstudio.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.widgetstudio.ui.effects.ParticleField
import kotlin.math.PI
import kotlin.math.sin

private data class Scene(
    val name: String, val emoji: String, val temp: Int, val humidity: Int, val wind: Int,
    val top: Color, val bottom: Color, val fog: Color, val date: String
)

private val scenes = listOf(
    Scene("Forest", "🌲", 16, 85, 4, Color(0xFF2B3D33), Color(0xFF070C09), Color(0xFFB8D8C0), "30 July"),
    Scene("Desert", "☀️", 38, 12, 7, Color(0xFFFFB35C), Color(0xFF4A2314), Color(0xFFFFE2B8), "14 August"),
    Scene("Night Sea", "🌙", 21, 70, 9, Color(0xFF16325F), Color(0xFF02050C), Color(0xFF9DB7E8), "2 November")
)

@Composable
fun WeatherScreen(onBack: () -> Unit) {
    var idx by remember { mutableIntStateOf(0) }
    val s = scenes[idx]
    val top by animateColorAsState(s.top, tween(900), label = "top")
    val bottom by animateColorAsState(s.bottom, tween(900), label = "bottom")
    val temp by animateIntAsState(s.temp, tween(1200), label = "temp")
    val hum by animateFloatAsState(s.humidity / 100f, tween(1200), label = "hum")

    val inf = rememberInfiniteTransition(label = "weather")
    val drift by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(18000, easing = LinearEasing)), label = "drift")
    val sway by inf.animateFloat(
        -8f, 8f, infiniteRepeatable(tween(1400), RepeatMode.Reverse), label = "sway"
    )

    DemoScaffold("الطقس الزجاجي", onBack) {
        Box(
            Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(36.dp))
                .background(Brush.verticalGradient(listOf(top, bottom)))
                .clickable { idx = (idx + 1) % scenes.size }
        ) {
            // drifting fog bands
            Canvas(Modifier.fillMaxSize()) {
                val a = drift * 2f * PI.toFloat()
                for (i in 0..2) {
                    val cx = size.width * (0.3f + 0.4f * i + 0.2f * sin(a + i))
                    val cy = size.height * (0.25f + 0.25f * i)
                    drawCircle(
                        Brush.radialGradient(
                            listOf(s.fog.copy(alpha = 0.22f), Color.Transparent),
                            center = Offset(cx, cy), radius = size.width * 0.7f
                        ),
                        radius = size.width * 0.7f, center = Offset(cx, cy)
                    )
                }
            }
            ParticleField(Modifier.fillMaxSize(), count = 45, color = s.fog)

            val pillShape = RoundedCornerShape(85.dp)
            Column(
                Modifier
                    .align(Alignment.Center)
                    .width(170.dp)
                    .height(340.dp)
                    .clip(pillShape)
                    .background(Brush.verticalGradient(listOf(Color.White.copy(0.2f), Color.White.copy(0.06f))))
                    .border(1.dp, Color.White.copy(0.3f), pillShape)
                    .padding(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    Modifier.size(130.dp).clip(CircleShape).background(Color.Black.copy(0.25f)),
                    contentAlignment = Alignment.Center
                ) {
                    AnimatedContent(
                        targetState = s.emoji,
                        transitionSpec = {
                            (scaleIn(tween(500)) + fadeIn(tween(500))) togetherWith
                                (scaleOut(tween(300)) + fadeOut(tween(300)))
                        },
                        label = "emoji"
                    ) { e -> Text(e, fontSize = 60.sp) }
                }
                Spacer(Modifier.height(12.dp))
                Text("weather", color = Color.White.copy(0.6f), fontSize = 13.sp)
                Text(s.name, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Light)
                Text(s.date, color = Color.White.copy(0.55f), fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Chip("🌡 $temp°C")
                    Chip("💧 ${(hum * 100).toInt()}%")
                }
                Spacer(Modifier.height(12.dp))
                Text(
                    "💨 ${s.wind} m/s",
                    color = Color.White.copy(0.7f),
                    fontSize = 14.sp,
                    modifier = Modifier.graphicsLayer { rotationZ = sway }
                )
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(
            "المس المشهد لتغييره",
            color = Color.White.copy(0.55f),
            fontSize = 13.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
    }
}

@Composable
private fun Chip(text: String) {
    Box(
        Modifier.clip(CircleShape).background(Color.White.copy(0.14f))
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) { Text(text, color = Color.White, fontSize = 13.sp) }
}
