package com.example.widgetstudio.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

@Composable
fun WidgetStudioTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF9FB4FF),
            background = Color(0xFF07090F),
            surface = Color(0xFF0F131C)
        ),
        content = content
    )
}
