package com.example.widgetstudio.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/** Design tokens for the Widget Studio app chrome (premium dark, glass surfaces, controlled neon). */
object Ws {
    val Bg = Color(0xFF05060B)
    val Surface = Color(0xFF0D1018)
    val Cyan = Color(0xFF4DE1FF)
    val Violet = Color(0xFF9B6BFF)
    val Magenta = Color(0xFFFF4DDB)
    val Mint = Color(0xFF5CFFB0)
    val Amber = Color(0xFFFFC857)
    val Text = Color(0xFFF2F5FF)
    val TextDim = Color(0xFF9AA3B8)
    val GlassTop = Color.White.copy(alpha = 0.10f)
    val GlassBottom = Color.White.copy(alpha = 0.035f)
    val GlassBorderA = Color.White.copy(alpha = 0.26f)
    val GlassBorderB = Color.White.copy(alpha = 0.04f)
    val AccentBrush: Brush get() = Brush.linearGradient(listOf(Cyan, Violet))
    val HotBrush: Brush get() = Brush.linearGradient(listOf(Violet, Magenta))
}

@Composable
fun WidgetStudioTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Ws.Cyan, secondary = Ws.Violet, tertiary = Ws.Magenta,
            background = Ws.Bg, surface = Ws.Surface, onSurface = Ws.Text, onBackground = Ws.Text
        ),
        content = content
    )
}
