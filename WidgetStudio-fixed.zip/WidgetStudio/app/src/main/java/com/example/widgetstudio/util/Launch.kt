package com.example.widgetstudio.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.Settings
import android.widget.Toast
import com.example.widgetstudio.MainActivity
import com.example.widgetstudio.render.Act

object Launch {
    /** Launch intent for an installed app, or a web fallback. */
    fun appIntent(context: Context, pkg: String, fallbackUrl: String): Intent {
        val i = context.packageManager.getLaunchIntentForPackage(pkg)
            ?: Intent(Intent.ACTION_VIEW, Uri.parse(fallbackUrl))
        return i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    fun dialerIntent(): Intent =
        Intent(Intent.ACTION_DIAL).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    /** Intent for a widget click target (used by Glance actionStartActivity). */
    fun intent(ctx: Context, a: Act): Intent = when (a) {
        is Act.App -> appIntent(ctx, a.pkg, a.fallbackUrl ?: "https://play.google.com/store/apps/details?id=${a.pkg}")
        Act.Dial -> dialerIntent()
        Act.OpenStudio -> Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        Act.Alarms -> Intent(AlarmClock.ACTION_SHOW_ALARMS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        Act.Calendar -> Intent(Intent.ACTION_VIEW, CalendarContract.CONTENT_URI.buildUpon().appendPath("time").appendPath(System.currentTimeMillis().toString()).build())
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        Act.MediaAccess -> Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        is Act.Media, is Act.ToggleTask -> Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    fun start(context: Context, intent: Intent) {
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Can't open this app", Toast.LENGTH_SHORT).show()
        }
    }
}
