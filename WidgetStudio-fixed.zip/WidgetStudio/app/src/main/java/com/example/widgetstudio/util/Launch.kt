package com.example.widgetstudio.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

object Launch {
    /** Launch intent for an installed app, or a web fallback. */
    fun appIntent(context: Context, pkg: String, fallbackUrl: String): Intent {
        val i = context.packageManager.getLaunchIntentForPackage(pkg)
            ?: Intent(Intent.ACTION_VIEW, Uri.parse(fallbackUrl))
        return i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    fun dialerIntent(): Intent =
        Intent(Intent.ACTION_DIAL).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun start(context: Context, intent: Intent) {
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Can't open this app", Toast.LENGTH_SHORT).show()
        }
    }
}
