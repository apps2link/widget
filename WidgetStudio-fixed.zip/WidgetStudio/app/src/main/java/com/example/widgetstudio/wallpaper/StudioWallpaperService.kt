package com.example.widgetstudio.wallpaper

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import com.example.widgetstudio.render.SynthPainter
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.random.Random

/**
 * Optional live wallpaper — the one place with genuinely continuous animation.
 * Battery rules: frames are only drawn while visible, capped at 24 fps (12 fps with "Reduce motion"),
 * and the loop is fully stopped when the wallpaper is hidden or the surface is destroyed.
 */
class StudioWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = StudioEngine()

    private inner class StudioEngine : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private val prefs = getSharedPreferences("ws_wallpaper", MODE_PRIVATE)
        private var visible = false
        private var w = 0; private var h = 0
        private var xOff = 0.5f
        private val rnd = Random(7)
        private val stars = Array(90) { floatArrayOf(rnd.nextFloat(), rnd.nextFloat(), 0.2f + rnd.nextFloat() * 0.8f) }
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val frame = object : Runnable {
            override fun run() {
                draw()
                if (visible) handler.postDelayed(this, if (prefs.getBoolean("reduced", false)) 83L else 42L)
            }
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height); w = width; h = height; draw()
        }
        override fun onVisibilityChanged(v: Boolean) {
            visible = v; handler.removeCallbacks(frame)
            if (v) handler.post(frame)
        }
        override fun onSurfaceDestroyed(holder: SurfaceHolder) { visible = false; handler.removeCallbacks(frame); super.onSurfaceDestroyed(holder) }
        override fun onDestroy() { visible = false; handler.removeCallbacks(frame); super.onDestroy() }
        override fun onOffsetsChanged(x: Float, y: Float, xs: Float, ys: Float, xp: Int, yp: Int) { xOff = x }

        private fun draw() {
            if (w == 0 || h == 0) return
            val holder = surfaceHolder
            val c: Canvas = (try { holder.lockHardwareCanvas() } catch (e: Exception) { null }) ?: holder.lockCanvas() ?: return
            try {
                val t = SystemClock.uptimeMillis() / 1000f
                c.drawColor(0xFF05060B.toInt())
                when (prefs.getInt("theme", 0)) {
                    1 -> { aurora(c, t, 0.7f); particles(c, t) }
                    2 -> neon(c, t)
                    else -> aurora(c, t, 1f)
                }
            } finally { holder.unlockCanvasAndPost(c) }
        }

        private fun blob(c: Canvas, cx: Float, cy: Float, r: Float, color: Int) {
            p.shader = RadialGradient(cx, cy, r, color, color and 0x00FFFFFF, Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, r, p); p.shader = null
        }

        private fun aurora(c: Canvas, t: Float, k: Float) {
            val par = (xOff - 0.5f) * w * 0.12f
            val a = (t / 11f) * 2f * PI.toFloat()
            blob(c, w * (0.3f + 0.2f * sin(a)) + par, h * (0.25f + 0.08f * cos(a * 0.7f)), w * 0.95f, Color.argb((70 * k).toInt(), 155, 107, 255))
            blob(c, w * (0.8f - 0.2f * cos(a * 0.8f)) + par * 1.5f, h * (0.55f + 0.1f * sin(a)), w * 0.85f, Color.argb((55 * k).toInt(), 77, 225, 255))
            blob(c, w * (0.4f + 0.15f * cos(a * 0.5f)) + par * 0.6f, h * (0.9f - 0.08f * sin(a * 0.9f)), w * 1.0f, Color.argb((40 * k).toInt(), 255, 77, 219))
        }

        private fun particles(c: Canvas, t: Float) {
            val par = (xOff - 0.5f) * w * 0.08f
            for (s in stars) {
                val y = ((s[1] - t * 0.012f * s[2]) % 1f + 1f) % 1f
                val tw = 0.5f + 0.5f * sin(t * 1.3f * s[2] + s[0] * 20f)
                p.color = Color.argb((60 + 150 * tw * s[2]).toInt().coerceIn(0, 255), 255, 255, 255)
                c.drawCircle(s[0] * w + par * s[2], y * h, (0.8f + 2.2f * s[2]) * resources.displayMetrics.density * 0.6f, p)
            }
        }

        private fun neon(c: Canvas, t: Float) {
            SynthPainter(0xFFFF4DDB.toInt(), 0xFFFFC857.toInt(), 0xFF4DE1FF.toInt(), 0.8f).paint(c, w.toFloat(), h.toFloat(), resources.displayMetrics.density, 0f)
            val horizon = h * 0.62f
            val k = (t * 0.25f) % 1f
            p.style = Paint.Style.STROKE; p.strokeWidth = resources.displayMetrics.density; p.color = Color.argb(120, 77, 225, 255)
            val y = horizon + (h - horizon) * (k * k)
            c.drawLine(0f, y, w.toFloat(), y, p)
            p.style = Paint.Style.FILL
        }
    }
}
