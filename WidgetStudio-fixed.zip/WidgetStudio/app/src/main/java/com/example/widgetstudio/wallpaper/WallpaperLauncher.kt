package com.example.widgetstudio.wallpaper

import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.Toast

/** Opens the system "set live wallpaper" preview for Widget Studio Live. */
fun openLiveWallpaperPicker(ctx: Context) {
    val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
        .putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, ComponentName(ctx, StudioWallpaperService::class.java))
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try { ctx.startActivity(i) } catch (e: Exception) {
        try { ctx.startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e2: Exception) { Toast.makeText(ctx, "This device can't set live wallpapers", Toast.LENGTH_LONG).show() }
    }
}
