package com.example.widgetstudio.widgets

import android.content.Context
import android.media.AudioManager
import android.view.KeyEvent
import androidx.glance.GlanceId
import androidx.glance.action.ActionParameters
import androidx.glance.appwidget.action.ActionCallback
import com.example.widgetstudio.core.Need
import com.example.widgetstudio.core.Store

val KeyCodeKey = ActionParameters.Key<Int>("keycode")
val TaskIdKey = ActionParameters.Key<String>("task_id")

/** Transport buttons: dispatch a media key to whatever session is active. Needs no permission. */
class MediaKeyCallback : ActionCallback {
    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
        val code = parameters[KeyCodeKey] ?: return
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }
}

class ToggleTaskCallback : ActionCallback {
    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
        val id = parameters[TaskIdKey] ?: return
        Store.toggleTask(context, id)
        Updater.refreshNeeding(context, setOf(Need.TASKS))
    }
}
