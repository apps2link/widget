package com.example.widgetstudio.widgets

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.widgetstudio.core.Store
import com.example.widgetstudio.core.WidgetConfig
import com.example.widgetstudio.work.Scheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * "Add to Home Screen". The chosen configuration is stored as *pending* for the size's provider before
 * the pin request; the new instance claims it atomically (in provideGlance, in the config activity, or
 * in the pin callback — whichever runs first). That also makes the manual "add from the widget picker"
 * fallback keep the design the user just built.
 */
object Pinner {
    enum class Result { REQUESTED, UNSUPPORTED, FAILED }
    const val ACTION = "com.example.widgetstudio.PIN_RESULT"

    suspend fun request(ctx: Context, cfg: WidgetConfig): Result {
        Store.setPending(ctx, cfg)
        val awm = AppWidgetManager.getInstance(ctx)
        if (!awm.isRequestPinAppWidgetSupported) return Result.UNSUPPORTED
        val cb = PendingIntent.getBroadcast(
            ctx, cfg.size.ordinal, Intent(ctx, PinResultReceiver::class.java).setAction(ACTION),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        )
        return if (awm.requestPinAppWidget(Providers.component(ctx, cfg.size), null, cb)) Result.REQUESTED else Result.FAILED
    }
}

class PinResultReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
        if (id == AppWidgetManager.INVALID_APPWIDGET_ID) return
        val pr = goAsync()
        CoroutineScope(Dispatchers.Default).launch {
            try {
                ConfigResolver.resolve(context, id) // binds the pending config if nobody has yet
                Store.setPinned(context, id)
                Updater.refreshIds(context, listOf(id))
                Scheduler.sync(context)
            } finally { pr.finish() }
        }
    }
}
