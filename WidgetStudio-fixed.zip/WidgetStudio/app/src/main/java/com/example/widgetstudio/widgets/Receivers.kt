package com.example.widgetstudio.widgets

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import com.example.widgetstudio.core.Store
import com.example.widgetstudio.core.WSize
import com.example.widgetstudio.work.Scheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

abstract class StudioReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = StudioWidget()

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        super.onDeleted(context, appWidgetIds)
        val pr = goAsync()
        CoroutineScope(Dispatchers.Default).launch {
            try {
                appWidgetIds.forEach { Store.deleteConfig(context, it) }
                Scheduler.sync(context)
            } finally { pr.finish() }
        }
    }

    override fun onEnabled(context: Context) {
        super.onEnabled(context)
        val pr = goAsync()
        CoroutineScope(Dispatchers.Default).launch { try { Scheduler.sync(context) } finally { pr.finish() } }
    }

    override fun onDisabled(context: Context) {
        super.onDisabled(context)
        val pr = goAsync()
        CoroutineScope(Dispatchers.Default).launch { try { Scheduler.sync(context) } finally { pr.finish() } }
    }
}

class SmallReceiver : StudioReceiver()
class StripReceiver : StudioReceiver()
class MediumReceiver : StudioReceiver()
class LargeReceiver : StudioReceiver()

object Providers {
    private val classes: Map<WSize, Class<out StudioReceiver>> = mapOf(
        WSize.SMALL to SmallReceiver::class.java, WSize.STRIP to StripReceiver::class.java,
        WSize.MEDIUM to MediumReceiver::class.java, WSize.LARGE to LargeReceiver::class.java
    )

    fun component(ctx: Context, size: WSize): ComponentName = ComponentName(ctx, classes.getValue(size))

    fun sizeOf(className: String?): WSize? = classes.entries.firstOrNull { it.value.name == className }?.key

    data class Installed(val id: Int, val size: WSize)

    /** Every widget instance of ours that currently exists on a home screen. */
    fun installed(ctx: Context): List<Installed> {
        val awm = AppWidgetManager.getInstance(ctx)
        return classes.flatMap { (size, cls) -> awm.getAppWidgetIds(ComponentName(ctx, cls)).map { Installed(it, size) } }
    }
}
