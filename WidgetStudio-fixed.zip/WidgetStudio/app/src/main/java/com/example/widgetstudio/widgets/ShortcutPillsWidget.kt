package com.example.widgetstudio.widgets

import android.content.Context
import android.content.Intent
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.ColorFilter
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.GlanceTheme
import androidx.glance.Image
import androidx.glance.ImageProvider
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.size
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.example.widgetstudio.R
import com.example.widgetstudio.util.Launch

/** Three toggle-style pills: Instagram, WhatsApp and Call. */
class ShortcutPillsWidget : GlanceAppWidget() {
    override val sizeMode = SizeMode.Exact

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val ig = Launch.appIntent(context, "com.instagram.android", "https://instagram.com")
        val wa = Launch.appIntent(context, "com.whatsapp", "https://wa.me")
        val call = Launch.dialerIntent()
        provideContent {
            GlanceTheme {
                Column(
                    GlanceModifier.fillMaxSize().padding(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    PillRow(
                        GlanceModifier.defaultWeight(), "Instagram", R.drawable.ic_ig,
                        R.drawable.bg_pill_slate, R.drawable.bg_circle_slate_blue, knobRight = false, intent = ig
                    )
                    Spacer(GlanceModifier.height(6.dp))
                    PillRow(
                        GlanceModifier.defaultWeight(), "WhatsApp", R.drawable.ic_wa,
                        R.drawable.bg_pill_slate, R.drawable.bg_circle_navy, knobRight = true, intent = wa
                    )
                    Spacer(GlanceModifier.height(6.dp))
                    PillRow(
                        GlanceModifier.defaultWeight(), "Call", R.drawable.ic_call,
                        R.drawable.bg_pill_glass_dark, R.drawable.bg_circle_black, knobRight = false, intent = call
                    )
                }
            }
        }
    }
}

class ShortcutPillsReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = ShortcutPillsWidget()
}

@Composable
private fun PillRow(
    modifier: GlanceModifier,
    label: String,
    iconRes: Int,
    trackRes: Int,
    knobRes: Int,
    knobRight: Boolean,
    intent: Intent
) {
    val textStyle = TextStyle(
        color = ColorProvider(Color.White),
        fontSize = 17.sp,
        fontWeight = FontWeight.Medium
    )
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(ImageProvider(trackRes))
            .clickable(actionStartActivity(intent)),
        contentAlignment = Alignment.Center
    ) {
        Row(
            GlanceModifier.fillMaxSize().padding(horizontal = 6.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (!knobRight) {
                Knob(iconRes, knobRes)
                Spacer(GlanceModifier.width(14.dp))
                Text(label, style = textStyle)
            } else {
                Text(label, style = textStyle, modifier = GlanceModifier.defaultWeight().padding(start = 20.dp))
                Knob(iconRes, knobRes)
            }
        }
    }
}

@Composable
private fun Knob(iconRes: Int, knobRes: Int) {
    Box(
        GlanceModifier.size(46.dp).background(ImageProvider(knobRes)),
        contentAlignment = Alignment.Center
    ) {
        Image(
            provider = ImageProvider(iconRes),
            contentDescription = null,
            colorFilter = ColorFilter.tint(ColorProvider(Color.White)),
            modifier = GlanceModifier.size(24.dp)
        )
    }
}
