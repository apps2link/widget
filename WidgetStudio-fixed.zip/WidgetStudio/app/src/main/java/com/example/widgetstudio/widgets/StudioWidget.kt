package com.example.widgetstudio.widgets

import android.appwidget.AppWidgetManager
import android.content.Context
import androidx.compose.runtime.Composable
import androidx.glance.GlanceId
import androidx.glance.LocalSize
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetManager
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.provideContent
import com.example.widgetstudio.core.Data
import com.example.widgetstudio.core.Store
import com.example.widgetstudio.core.WSize
import com.example.widgetstudio.core.WidgetConfig
import com.example.widgetstudio.data.DataProvider
import com.example.widgetstudio.designs.Ctx
import com.example.widgetstudio.designs.Design
import com.example.widgetstudio.designs.Registry
import com.example.widgetstudio.render.GEnv
import com.example.widgetstudio.render.GlanceNode

/**
 * One GlanceAppWidget for every design. The design + all styling come from the per-instance config
 * stored under the real appWidgetId, so two widgets of the same design can look completely different.
 */
class StudioWidget : GlanceAppWidget() {
    override val sizeMode: SizeMode = SizeMode.Exact

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val awId = GlanceAppWidgetManager(context).getAppWidgetId(id)
        val cfg = ConfigResolver.resolve(context, awId)
        val design = Registry.get(cfg.designId) ?: Registry.fallback(cfg.size)
        val data = DataProvider.load(context, design.needs, cfg)
        provideContent { StudioContent(context, design, cfg, data) }
    }
}

@Composable
private fun StudioContent(ctx: Context, design: Design, cfg: WidgetConfig, data: Data) {
    val s = LocalSize.current
    val w = if (s.width.value > 1f) s.width.value else cfg.size.wDp
    val h = if (s.height.value > 1f) s.height.value else cfg.size.hDp
    val node = design.build(Ctx(cfg, w, h, data))
    GlanceNode(node, GEnv(ctx, ctx.resources.displayMetrics.density, w, h))
}

object ConfigResolver {
    fun sizeOf(ctx: Context, appWidgetId: Int): WSize {
        val cls = AppWidgetManager.getInstance(ctx).getAppWidgetInfo(appWidgetId)?.provider?.className
        return Providers.sizeOf(cls) ?: WSize.MEDIUM
    }

    /** Stored config → else the pending config from "Add to Home Screen" → else the size's default design. */
    suspend fun resolve(ctx: Context, appWidgetId: Int): WidgetConfig {
        Store.config(ctx, appWidgetId)?.let { return it }
        val size = sizeOf(ctx, appWidgetId)
        Store.claimPending(ctx, size, appWidgetId)?.let { return it }
        val cfg = Registry.defaultConfig(Registry.fallback(size), size)
        Store.saveConfig(ctx, appWidgetId, cfg)
        return cfg
    }
}
