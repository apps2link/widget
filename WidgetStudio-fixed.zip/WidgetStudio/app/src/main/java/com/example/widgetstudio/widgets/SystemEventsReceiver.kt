package com.example.widgetstudio.widgets

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.widgetstudio.core.Need
import com.example.widgetstudio.work.Scheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/** Event-driven refresh for the few system broadcasts Android still delivers to manifest receivers. */
class SystemEventsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        val pr = goAsync()
        CoroutineScope(Dispatchers.Default).launch {
            try {
                when (action) {
                    Intent.ACTION_BATTERY_LOW, Intent.ACTION_BATTERY_OKAY, Intent.ACTION_POWER_CONNECTED, Intent.ACTION_POWER_DISCONNECTED ->
                        Updater.refreshNeeding(context, setOf(Need.BATTERY))
                    Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED -> { Scheduler.sync(context); Updater.refreshAll(context) }
                    else -> Updater.refreshAll(context) // date / time / timezone / locale change
                }
            } finally { pr.finish() }
        }
    }
}
