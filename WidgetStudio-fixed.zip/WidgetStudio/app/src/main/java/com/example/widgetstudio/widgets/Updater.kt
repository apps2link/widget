package com.example.widgetstudio.widgets

import android.content.Context
import androidx.glance.appwidget.GlanceAppWidgetManager
import com.example.widgetstudio.core.Need
import com.example.widgetstudio.core.Store
import com.example.widgetstudio.designs.Registry

/** Central, targeted refresh. Only instances whose design actually uses the changed data are redrawn. */
object Updater {
    suspend fun refreshIds(ctx: Context, ids: Collection<Int>) {
        val gm = GlanceAppWidgetManager(ctx)
        for (id in ids) runCatching { StudioWidget().update(ctx, gm.getGlanceIdBy(id)) }
    }

    suspend fun refreshAll(ctx: Context) = refreshIds(ctx, Providers.installed(ctx).map { it.id })

    suspend fun refreshNeeding(ctx: Context, needs: Set<Need>) {
        val cfgs = Store.allConfigs(ctx)
        val ids = Providers.installed(ctx).map { it.id }.filter { id ->
            val d = cfgs[id]?.let { Registry.get(it.designId) } ?: return@filter false
            d.needs.any { it in needs }
        }
        refreshIds(ctx, ids)
    }
}
