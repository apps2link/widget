package com.example.widgetstudio.widgets

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.lifecycle.lifecycleScope
import com.example.widgetstudio.core.Store
import com.example.widgetstudio.ui.AppViewModel
import com.example.widgetstudio.ui.Route
import com.example.widgetstudio.ui.StudioApp
import com.example.widgetstudio.ui.theme.WidgetStudioTheme
import com.example.widgetstudio.work.Scheduler
import kotlinx.coroutines.launch

/**
 * Launched by the launcher when a widget is added from the system picker, and when the user
 * reconfigures one. If a design was just built in the app ("pending"), it is applied silently;
 * otherwise the user picks and customises a design right here.
 */
class WidgetConfigActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()
    private var awId = AppWidgetManager.INVALID_APPWIDGET_ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        awId = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
        setResult(Activity.RESULT_CANCELED, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, awId))
        if (awId == AppWidgetManager.INVALID_APPWIDGET_ID) { finish(); return }

        lifecycleScope.launch {
            val size = ConfigResolver.sizeOf(this@WidgetConfigActivity, awId)
            val existing = Store.config(this@WidgetConfigActivity, awId)
            if (existing == null && Store.claimPending(this@WidgetConfigActivity, size, awId) != null) {
                Updater.refreshIds(this@WidgetConfigActivity, listOf(awId)); Scheduler.sync(applicationContext); finishOk(); return@launch
            }
            vm.configWidgetId = awId
            vm.configSize = size
            if (existing != null) {
                vm.openExisting(awId, existing)
                vm.goRoot(Route.Editor)
            } else vm.goRoot(Route.Library())
            setContent { WidgetStudioTheme { StudioApp(vm, onApplyConfig = { apply() }, onCancelConfig = { finish() }) } }
        }
    }

    private fun apply() {
        val cfg = vm.editor?.cfg ?: return
        lifecycleScope.launch {
            Store.saveConfig(applicationContext, awId, cfg.copy(size = vm.configSize ?: cfg.size))
            Updater.refreshIds(applicationContext, listOf(awId))
            Scheduler.sync(applicationContext)
            finishOk()
        }
    }

    private fun finishOk() {
        setResult(Activity.RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, awId))
        finish()
    }
}
