package com.example.widgetstudio.work

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.example.widgetstudio.core.Need
import com.example.widgetstudio.core.Store
import com.example.widgetstudio.data.WeatherRepo
import com.example.widgetstudio.designs.Registry
import com.example.widgetstudio.widgets.Providers
import com.example.widgetstudio.widgets.Updater
import java.util.concurrent.TimeUnit

class RefreshWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val app = applicationContext
        if (inputData.getString("kind") == "weather") {
            val cfgs = Store.allConfigs(app)
            val installed = Providers.installed(app).map { it.id }.toSet()
            val cities = cfgs.filterKeys { it in installed }.values
                .filter { Registry.get(it.designId)?.needs?.contains(Need.WEATHER) == true }
                .map { it.str("city") }.filter { it.isNotBlank() }.distinct()
            val ok = cities.map { WeatherRepo.refresh(app, it) != null }
            Updater.refreshNeeding(app, setOf(Need.WEATHER))
            if (ok.isNotEmpty() && ok.none { it }) return Result.retry()
        } else {
            Updater.refreshNeeding(app, setOf(Need.BATTERY, Need.SYSTEM, Need.AGENDA, Need.PERIODIC))
        }
        return Result.success()
    }
}

/**
 * Schedules the minimum background work the installed widgets need, and nothing else:
 * no widgets using a data source => that job is cancelled. Periods scale with the user's update mode.
 */
object Scheduler {
    private const val WEATHER = "ws_weather"
    private const val LIVE = "ws_live"

    suspend fun sync(ctx: Context) {
        val app = ctx.applicationContext
        val wm = WorkManager.getInstance(app)
        val installed = Providers.installed(app).map { it.id }.toSet()
        val needs = Store.allConfigs(app).filterKeys { it in installed }.values
            .flatMap { Registry.get(it.designId)?.needs ?: emptySet() }.toSet()
        val mult = when (Store.getSettings(app).updateMode) { 0 -> 4f; 2 -> 1f; else -> 2f } // x15 min

        if (Need.WEATHER in needs) {
            val minutes = (mult * 30L).toLong().coerceAtLeast(30L)
            val req = PeriodicWorkRequestBuilder<RefreshWorker>(minutes, TimeUnit.MINUTES)
                .setInputData(workDataOf("kind" to "weather"))
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).setRequiresBatteryNotLow(true).build())
                .build()
            wm.enqueueUniquePeriodicWork(WEATHER, ExistingPeriodicWorkPolicy.UPDATE, req)
        } else wm.cancelUniqueWork(WEATHER)

        if (needs.any { it == Need.BATTERY || it == Need.SYSTEM || it == Need.AGENDA || it == Need.PERIODIC }) {
            val minutes = (mult * 15L).toLong().coerceAtLeast(15L)
            val req = PeriodicWorkRequestBuilder<RefreshWorker>(minutes, TimeUnit.MINUTES)
                .setInputData(workDataOf("kind" to "live"))
                .setConstraints(Constraints.Builder().setRequiresBatteryNotLow(true).build())
                .build()
            wm.enqueueUniquePeriodicWork(LIVE, ExistingPeriodicWorkPolicy.UPDATE, req)
        } else wm.cancelUniqueWork(LIVE)
    }
}
