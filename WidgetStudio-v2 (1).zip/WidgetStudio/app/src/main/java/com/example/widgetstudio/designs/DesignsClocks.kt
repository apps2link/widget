package com.example.widgetstudio.designs

import com.example.widgetstudio.core.*
import com.example.widgetstudio.render.*
import kotlin.math.max
import kotlin.math.min

private val ALL = WSize.entries.toList()
private val GLASS_NEON = setOf(Effect.GLASS)

private val aurora = Design(
    id = "dc_aurora", name = "Aurora Time", tag = "Big time with a soft date line", cat = Category.DIGITAL,
    sizes = ALL, layouts = listOf("Centered", "Left aligned"), featured = true,
    fields = listOf(Field.Toggle("h24", "24-hour clock", false), Field.Toggle("date", "Show date", true), Field.Toggle("ampm", "AM/PM", false)),
    preset = { it.copy(effects = setOf(Effect.GLASS, Effect.LIGHT), glow = 0.6f) }
) { c ->
    val fmt = c.tf + if (!c.h24 && c.cfg.flag("ampm", false)) " a" else ""
    val big = min(c.h * 0.5f, c.w * 0.29f)
    val date = c.cfg.flag("date", true)
    val ha = if (c.cfg.layout == 1) HA.S else HA.C
    if (c.size == WSize.STRIP) {
        c.root(Act.Alarms, 8f, row(VA.C, HA.S, M.Fill, c.C(fmt, c.h * 0.55f), spacer(), if (date) c.C("EEE d MMM", c.h * 0.3f, 0.75f) else gap()))
    } else {
        c.root(
            Act.Alarms, 10f,
            col(
                ha, VA.C, M.Fill,
                c.C(fmt, big),
                if (date) c.C("EEEE, d MMMM", big * 0.27f, 0.75f, m = M(pt = 2f)) else gap(),
                if (date && c.size == WSize.LARGE) gfx(PanelPainter(c.acc, c.acc2, -1), min(c.w * 0.4f, 120f), 4f, m = M(pt = 0f).padding(t = 12f)) else gap()
            )
        )
    }
}

private val pill = Design(
    id = "dc_pill", name = "Pill Duo", tag = "Beige day pill + minutes disc", cat = Category.DIGITAL,
    sizes = listOf(WSize.MEDIUM, WSize.LARGE), layouts = listOf("Pill left", "Pill right"),
    fields = listOf(Field.Toggle("h24", "24-hour clock", false)),
    effects = listOf(Effect.GLASS, Effect.NEON, Effect.LIGHT, Effect.PULSE),
    preset = { it.copy(accent = 0xFFE6DFD0.toInt(), bg = 0xFF1A1D24.toInt(), bg2 = 0xFF000000.toInt(), font = FontKey.MEDIUM, glow = 0.15f, effects = setOf(Effect.GLASS)) }
) { c ->
    val pad = 8f
    val hh = min(c.h - 2 * pad, c.w * 0.5f)
    val gapW = 8f
    val pw = c.w - 2 * pad - hh - gapW
    val ink = 0xFF101010.toInt()
    val hours = if (c.h24) "HH" else "hh"
    val s = hh / 98f
    val pillNode = BoxN(
        A.C, M(w = pw, h = hh),
        listOf(
            gfx(PanelPainter(c.acc, lerpColor(c.acc, 0xFFFFFFFF.toInt(), 0.2f), -1), pw, hh),
            col(
                HA.C, VA.C, M.Fill,
                c.C("EEEE", 12f * s, 0.8f, color = ink),
                c.C(hours, 56f * s, color = ink),
                c.C("d MMM yyyy", 11f * s, 0.8f, color = ink)
            )
        )
    )
    val disc = BoxN(
        A.C, M(w = hh, h = hh),
        listOf(
            gfx(PanelPainter(c.cfg.bg2.opaque(), c.cfg.bg2.opaque(), -1, stroke = 0x33FFFFFF, strokeDp = 1f), hh, hh),
            c.C("mm", 36f * s, color = 0xFFFFFFFF.toInt())
        )
    )
    c.root(Act.Alarms, pad, if (c.cfg.layout == 0) row(VA.C, HA.S, M.Fill, pillNode, gap(gapW), disc) else row(VA.C, HA.S, M.Fill, disc, gap(gapW), pillNode))
}

private val stack = Design(
    id = "dc_stack", name = "Stacked", tag = "Hours over minutes, two-tone", cat = Category.DIGITAL,
    sizes = listOf(WSize.SMALL, WSize.MEDIUM, WSize.LARGE),
    layouts = listOf("Accent minutes", "Outlined bar"),
    fields = listOf(Field.Toggle("h24", "24-hour clock", false), Field.Toggle("date", "Show date", true)),
    preset = { it.copy(font = FontKey.BLACK, effects = setOf(Effect.GLASS, Effect.NEON), glow = 0.4f) }
) { c ->
    val big = min(c.h * 0.34f, c.w * 0.34f)
    c.root(
        Act.Alarms, 10f,
        col(
            HA.C, VA.C, M.Fill,
            c.C(if (c.h24) "HH" else "hh", big, font = c.cfg.font),
            if (c.cfg.layout == 1) gfx(PanelPainter(c.acc, c.acc2, -1), big * 1.4f, 3f, m = M().padding(t = 2f, b = 2f)) else gap(),
            c.C("mm", big, color = c.acc),
            if (c.cfg.flag("date", true) && c.size != WSize.SMALL) c.C("EEE, d MMM", big * 0.3f, 0.7f, m = M(pt = 4f)) else gap()
        )
    )
}

// ------------------------------------------------------------------------------------------------ analog
private fun analogBody(c: Ctx, style: Int): N {
    val pad = 8f
    val handColor = if (c.cfg.flag("accentHands", false)) c.acc else c.fg
    fun dial(s: Float): N = AnalogN(s, DialPainter(style, c.fg, c.acc, c.cfg.glow, c.cfg.font.family), handColor, M())
    return when (c.size) {
        WSize.MEDIUM, WSize.STRIP -> {
            val s = min(c.h - 2 * pad, c.w * 0.5f)
            row(
                VA.C, HA.S, M.Fill, dial(s), gap(12f),
                col(HA.S, VA.C, M.Weight.copy(fh = true), c.C(if (c.h24) "HH:mm" else "h:mm", s * 0.34f), c.C("EEEE", s * 0.14f, 0.8f), c.C("d MMMM", s * 0.14f, 0.55f))
            )
        }
        WSize.LARGE -> col(HA.C, VA.C, M.Fill, dial(min(c.w - 2 * pad, c.h - 2 * pad - 44f)), c.C("EEEE, d MMMM", 15f, 0.8f, m = M(pt = 8f)))
        else -> col(HA.C, VA.C, M.Fill, dial(min(c.w, c.h) - 2 * pad))
    }
}

private val analogFields = listOf(Field.Toggle("h24", "24-hour clock (side text)", false), Field.Toggle("accentHands", "Hands use accent colour", false))

private val classic = Design(
    id = "an_classic", name = "Classic Dial", tag = "Numerals, minute track, glowing rim", cat = Category.ANALOG,
    sizes = listOf(WSize.SMALL, WSize.MEDIUM, WSize.LARGE), fields = analogFields, featured = true,
    effects = listOf(Effect.GLASS, Effect.NEON, Effect.LIGHT, Effect.PULSE),
    preset = { it.copy(font = FontKey.SERIF, glow = 0.45f, effects = setOf(Effect.GLASS)) }
) { c -> c.root(Act.Alarms, 4f, analogBody(c, 0)) }

private val minimalAnalog = Design(
    id = "an_minimal", name = "Minimal Hands", tag = "Twelve bars, nothing else", cat = Category.ANALOG,
    sizes = listOf(WSize.SMALL, WSize.MEDIUM, WSize.LARGE), fields = analogFields,
    preset = { it.copy(font = FontKey.LIGHT, accent = 0xFFFFC857.toInt(), bg = 0xFF111111.toInt(), bg2 = 0xFF1C1C1E.toInt(), effects = emptySet(), glow = 0.2f) }
) { c -> c.root(Act.Alarms, 4f, analogBody(c, 1)) }

private val radar = Design(
    id = "an_radar", name = "Radar Dial", tag = "HUD compass dial with sweep", cat = Category.ANALOG,
    sizes = listOf(WSize.SMALL, WSize.MEDIUM, WSize.LARGE), fields = analogFields,
    preset = { it.copy(font = FontKey.MONO, accent = 0xFF5CFFB0.toInt(), bg = 0xFF04110C.toInt(), bg2 = 0xFF081E16.toInt(), effects = setOf(Effect.HUD, Effect.NEON), glow = 0.55f) }
) { c -> c.root(Act.Alarms, 4f, analogBody(c, 2)) }

// ------------------------------------------------------------------------------------------------ minimalist
private val minTime = Design(
    id = "mn_time", name = "Just Time", tag = "Only the time. Transparent by default", cat = Category.MINIMAL,
    sizes = listOf(WSize.SMALL, WSize.STRIP, WSize.MEDIUM), layouts = listOf("Centered", "Left"),
    fields = listOf(Field.Toggle("h24", "24-hour clock", false)),
    effects = emptyList(),
    preset = { it.copy(alpha = 0f, glow = 0f, effects = emptySet(), textMode = TextMode.LIGHT, font = FontKey.THIN, radius = 0f) }
) { c ->
    val big = min(c.h * 0.62f, c.w * 0.3f)
    c.root(Act.Alarms, 6f, col(if (c.cfg.layout == 1) HA.S else HA.C, VA.C, M.Fill, c.C(c.tf, big)))
}

private val minDate = Design(
    id = "mn_date", name = "Quiet Date", tag = "Giant thin day number", cat = Category.MINIMAL,
    sizes = listOf(WSize.SMALL, WSize.MEDIUM), needs = setOf(Need.DATE),
    effects = emptyList(),
    preset = { it.copy(alpha = 0f, glow = 0f, effects = emptySet(), textMode = TextMode.LIGHT, font = FontKey.THIN, radius = 0f) }
) { c ->
    val big = min(c.h * 0.62f, c.w * 0.5f)
    c.root(
        Act.Calendar, 6f,
        if (c.size == WSize.MEDIUM) row(VA.C, HA.C, M.Fill, c.C("d", big), gap(14f), col(HA.S, VA.C, M(), c.C("EEEE", big * 0.3f), c.C("MMMM yyyy", big * 0.2f, 0.65f)))
        else col(HA.C, VA.C, M.Fill, c.C("d", big), c.C("EEEE", big * 0.2f, 0.85f), c.C("MMM", big * 0.15f, 0.6f))
    )
}

private val minLine = Design(
    id = "mn_line", name = "Thin Line", tag = "Date line with an accent rule and battery", cat = Category.MINIMAL,
    sizes = listOf(WSize.STRIP, WSize.MEDIUM), needs = setOf(Need.BATTERY),
    fields = listOf(Field.Toggle("battery", "Show battery", true)),
    effects = listOf(Effect.GLASS, Effect.HUD),
    preset = { it.copy(alpha = 0f, glow = 0f, effects = emptySet(), textMode = TextMode.LIGHT, font = FontKey.LIGHT, radius = 0f) }
) { c ->
    val sp = min(c.h * 0.34f, 20f)
    c.root(
        Act.Calendar, 8f,
        col(
            HA.S, VA.C, M.Fill,
            row(VA.C, HA.S, M.FillW, c.C("EEEE '·' d MMMM", sp), spacer(), if (c.cfg.flag("battery", true)) c.T("${c.data.battery}%", sp * 0.8f, 0.7f) else gap()),
            gfx(PanelPainter(c.acc, c.acc.withAlpha(0.15f), -1), max(40f, c.w - 16f), 2f, m = M(pt = 6f))
        )
    )
}

val clockDesigns: List<Design> = listOf(aurora, pill, stack, classic, minimalAnalog, radar, minTime, minDate, minLine)
