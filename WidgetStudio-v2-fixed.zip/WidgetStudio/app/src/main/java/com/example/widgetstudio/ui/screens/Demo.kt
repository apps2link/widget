package com.example.widgetstudio.ui.screens

import androidx.compose.ui.graphics.Color

/** Catalog entries used by the gallery and navigation. */
enum class Demo(
    val title: String,
    val subtitle: String,
    val emoji: String,
    val tint: Color
) {
    CLOCK(
        title = "ساعة Flip & Pill",
        subtitle = "ساعة رقمية بتصميم زجاجي وحلقات مضيئة",
        emoji = "◷",
        tint = Color(0xFF51E5D2)
    ),
    WEATHER(
        title = "الطقس الزجاجي",
        subtitle = "بطاقة طقس أنيقة مع درجات الحرارة",
        emoji = "☀",
        tint = Color(0xFFFFC56E)
    ),
    PILLS(
        title = "أزرار الاختصارات",
        subtitle = "وصول سريع لتطبيقاتك وجهات اتصالك",
        emoji = "✦",
        tint = Color(0xFF63D6A5)
    ),
    HUD(
        title = "لوحة HUD المستقبلية",
        subtitle = "عدادات ومؤشرات مستوحاة من واجهات الخيال العلمي",
        emoji = "⌁",
        tint = Color(0xFF55DDF4)
    ),
    RING(
        title = "حلقة التطبيقات",
        subtitle = "حلقات متدرجة بتصميم دائري متعدد الألوان",
        emoji = "◎",
        tint = Color(0xFFB49AFF)
    )
}
