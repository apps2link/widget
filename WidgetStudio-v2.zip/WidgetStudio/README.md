# Widget Studio — Enhanced Build

A Kotlin + Jetpack Compose Android widget gallery with animated in-app previews and native home-screen widget pinning.

## Included
- Premium dark glass / aurora gallery UI.
- Category filters and featured collection.
- Animated previews for Clock, Weather, Shortcut Pills, HUD and Ring concepts.
- Direct Android `requestPinAppWidget` flow for the currently implemented native widgets:
  - Pill Clock
  - Shortcut Pills
- Existing Compose demo screens retained.

## Important platform note
The app previews can animate continuously while the app is open. Standard Android home-screen widgets are rendered through RemoteViews/Glance and are controlled by the launcher and Android's background limits. They cannot guarantee arbitrary continuous 60 FPS animation. The two currently implemented installable widgets use native Android widget rendering; the other three designs are previews only and are marked as coming soon in the gallery.

## Build
Open this folder in Android Studio, or build with Gradle 8.9+, JDK 17, Android SDK 35:

```bash
gradle assembleDebug
```

APK output:
`app/build/outputs/apk/debug/app-debug.apk`
