package com.example.widgetstudio.ui.screens

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.os.Build
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.widgetstudio.ui.effects.GlassCard
import com.example.widgetstudio.widgets.PillClockReceiver
import com.example.widgetstudio.widgets.ShortcutPillsReceiver

private val Ink = Color(0xFF080B13)
private val Muted = Color(0xFF9AA5BA)
private val Violet = Color(0xFF9B7BFF)
private val Cyan = Color(0xFF51E5D2)

@Composable
fun GalleryScreen(onOpen: (Demo) -> Unit) {
    var selected by remember { mutableStateOf("الكل") }
    val categories = listOf("الكل", "الساعات", "الطقس", "الاختصارات", "مستقبلي")
    val visibleDemos = when (selected) {
        "الساعات" -> Demo.entries.filter { it == Demo.CLOCK }
        "الطقس" -> Demo.entries.filter { it == Demo.WEATHER }
        "الاختصارات" -> Demo.entries.filter { it == Demo.PILLS }
        "مستقبلي" -> Demo.entries.filter { it == Demo.HUD || it == Demo.RING }
        else -> Demo.entries.toList()
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding(),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 14.dp, bottom = 30.dp),
        verticalArrangement = Arrangement.spacedBy(17.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("WIDGET LAB", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                    Text("Widget Studio", color = Color.White, fontSize = 31.sp, fontWeight = FontWeight.ExtraBold)
                    Text("خلّي شاشتك الرئيسية شبهك.", color = Muted, fontSize = 14.sp)
                }
                Box(
                    Modifier.size(48.dp).clip(CircleShape)
                        .background(Brush.linearGradient(listOf(Violet, Color(0xFF435BBD))))
                        .border(1.dp, Color.White.copy(.35f), CircleShape),
                    contentAlignment = Alignment.Center
                ) { Text("✦", color = Color.White, fontSize = 25.sp) }
            }
        }
        item { FeaturedHero() }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("استكشف المكتبة", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text("${visibleDemos.size} تصاميم", color = Muted, fontSize = 12.sp)
            }
            Row(Modifier.fillMaxWidth().horizontalScroll(androidx.compose.foundation.rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                categories.forEach { category ->
                    FilterChip(
                        selected = selected == category,
                        onClick = { selected = category },
                        label = { Text(category) }
                    )
                }
            }
        }
        items(visibleDemos, key = { it.name }) { demo ->
            WidgetCatalogCard(demo = demo, onPreview = { onOpen(demo) })
        }
        item {
            GlassCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("✦  مصمّم ليعيش على شاشتك", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(
                        "المعاينات داخل التطبيق متحركة بالكامل. أما الويدجت المثبتة فتستخدم إمكانيات أندرويد الأصلية، لذلك تختلف الحركة المستمرة حسب نوع الويدجت واللانشر للحفاظ على البطارية.",
                        color = Muted, fontSize = 12.sp, lineHeight = 19.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun FeaturedHero() {
    val transition = rememberInfiniteTransition(label = "heroGlow")
    val pulse by transition.animateFloat(0.88f, 1.08f, infiniteRepeatable(tween(1900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse")
    GlassCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(28.dp)) {
        Box(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF25244E), Color(0xFF111C2D), Color(0xFF102B32))))) {
            Canvas(Modifier.matchParentSize()) {
                drawCircle(Brush.radialGradient(listOf(Violet.copy(.38f), Color.Transparent)), size.minDimension * .65f, Offset(size.width * .88f, size.height * .1f))
                drawCircle(Brush.radialGradient(listOf(Cyan.copy(.22f), Color.Transparent)), size.minDimension * .58f, Offset(size.width * .12f, size.height * .9f))
            }
            Row(Modifier.padding(19.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("FEATURED COLLECTION", color = Cyan, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.8.sp)
                    Text("واجهة مختلفة\nكل يوم", color = Color.White, fontSize = 25.sp, lineHeight = 30.sp, fontWeight = FontWeight.ExtraBold)
                    Text("ساعات • زجاج • HUD • اختصارات", color = Color.White.copy(.68f), fontSize = 11.sp)
                    Box(Modifier.clip(CircleShape).background(Color.White.copy(.13f)).padding(horizontal = 12.dp, vertical = 7.dp)) {
                        Text("5 تجارب تفاعلية", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
                Box(Modifier.size(126.dp).scale(pulse), contentAlignment = Alignment.Center) {
                    Canvas(Modifier.fillMaxSize()) {
                        val sw = 5.dp.toPx()
                        drawCircle(Color.White.copy(.09f), style = Stroke(sw))
                        drawArc(Brush.sweepGradient(listOf(Cyan, Violet, Color(0xFFFF79C6), Cyan)), -90f, 285f, false, style = Stroke(sw, cap = StrokeCap.Round))
                        drawCircle(Color.White.copy(.06f), radius = size.minDimension * .31f)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("10:28", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Light)
                        Text("FRIDAY  •  13 NOV", color = Cyan, fontSize = 7.sp, letterSpacing = 1.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun WidgetCatalogCard(demo: Demo, onPreview: () -> Unit) {
    val context = LocalContext.current
    val tint = demo.tint
    GlassCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(25.dp)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(demo.title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text(demo.subtitle, color = Muted, fontSize = 11.sp)
                }
                Box(Modifier.clip(CircleShape).background(tint.copy(.16f)).padding(horizontal = 10.dp, vertical = 6.dp)) {
                    Text("${demo.emoji}  LIVE", color = tint, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }
            WidgetVisualPreview(demo = demo)
            Row(horizontalArrangement = Arrangement.spacedBy(9.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(
                    onClick = onPreview,
                    modifier = Modifier.weight(1f).height(43.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(.12f), contentColor = Color.White)
                ) { Text("معاينة وتخصيص", fontSize = 11.sp) }
                val canPin = demo == Demo.CLOCK || demo == Demo.PILLS
                Button(
                    onClick = {
                        when (demo) {
                            Demo.CLOCK -> pinWidget(context, PillClockReceiver::class.java)
                            Demo.PILLS -> pinWidget(context, ShortcutPillsReceiver::class.java)
                            else -> Toast.makeText(context, "التصميم ده متاح للمعاينة حاليًا، وسيتم دعم تثبيته في تحديث لاحق.", Toast.LENGTH_LONG).show()
                        }
                    },
                    modifier = Modifier.height(43.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = if (canPin) Color(0xFF5B4BD8) else Color(0xFF34394A))
                ) { Text(if (canPin) "＋ إضافة" else "قريبًا", fontSize = 11.sp) }
            }
        }
    }
}

private fun pinWidget(context: Context, receiver: Class<*>) {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
        Toast.makeText(context, "الإضافة المباشرة تحتاج Android 8 أو أحدث.", Toast.LENGTH_LONG).show()
        return
    }
    val manager = AppWidgetManager.getInstance(context)
    if (!manager.isRequestPinAppWidgetSupported) {
        Toast.makeText(context, "اللانشر الحالي لا يدعم الإضافة المباشرة. أضف الويدجت من قائمة Widgets.", Toast.LENGTH_LONG).show()
        return
    }
    val provider = ComponentName(context, receiver)
    val accepted = manager.requestPinAppWidget(provider, null, null)
    if (!accepted) Toast.makeText(context, "تعذر إرسال طلب الإضافة. جرّب من قائمة Widgets.", Toast.LENGTH_LONG).show()
}

@Composable
private fun WidgetVisualPreview(demo: Demo) {
    val loop = rememberInfiniteTransition(label = "widgetPreview")
    val pulse by loop.animateFloat(.94f, 1.04f, infiniteRepeatable(tween(1600), RepeatMode.Reverse), label = "previewPulse")
    val shape = RoundedCornerShape(19.dp)
    Box(
        Modifier.fillMaxWidth().height(126.dp).clip(shape)
            .background(Brush.linearGradient(listOf(Color(0xFF171D2C), Color(0xFF090D16))))
            .border(1.dp, Color.White.copy(.11f), shape),
        contentAlignment = Alignment.Center
    ) {
        when (demo) {
            Demo.CLOCK -> Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Column(Modifier.weight(1f).clip(RoundedCornerShape(15.dp)).background(Color(0xFFE5DDC9)).padding(12.dp)) {
                    Text("FRIDAY", color = Color(0xFF777064), fontSize = 9.sp, letterSpacing = 2.sp)
                    Text("10", color = Color(0xFF171717), fontSize = 38.sp, fontWeight = FontWeight.Light)
                    Text("13 NOVEMBER", color = Color(0xFF777064), fontSize = 8.sp)
                }
                Box(Modifier.size(94.dp).scale(pulse), contentAlignment = Alignment.Center) {
                    Canvas(Modifier.fillMaxSize()) { drawArc(Cyan, -90f, 270f, false, style = Stroke(5.dp.toPx(), cap = StrokeCap.Round)); drawCircle(Color.White.copy(.07f), style = Stroke(1.dp.toPx())) }
                    Text("28", color = Color.White, fontSize = 33.sp, fontWeight = FontWeight.Light)
                }
            }
            Demo.WEATHER -> Row(Modifier.padding(horizontal = 22.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("☀", fontSize = 52.sp)
                Spacer(Modifier.width(17.dp))
                Column { Text("27°", color = Color.White, fontSize = 37.sp, fontWeight = FontWeight.Light); Text("Sunny  •  Feels like 29°", color = Muted, fontSize = 10.sp); Text("MIN 19°     MAX 30°", color = Cyan, fontSize = 9.sp) }
            }
            Demo.PILLS -> Column(Modifier.padding(horizontal = 25.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("◎   Instagram", "◉   WhatsApp", "☎   Call").forEachIndexed { i, label ->
                    Row(Modifier.fillMaxWidth().height(29.dp).clip(CircleShape).background(listOf(Color(0xFF38445B), Color(0xFF174E43), Color(0xFF242A3C))[i]).padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(label, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Medium)
                        Spacer(Modifier.weight(1f)); Box(Modifier.size(17.dp).background(Color.White.copy(.18f), CircleShape))
                    }
                }
            }
            Demo.HUD -> Row(Modifier.padding(horizontal = 25.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(90.dp), contentAlignment = Alignment.Center) {
                    Canvas(Modifier.fillMaxSize()) { drawCircle(Cyan.copy(.15f), style = Stroke(1.dp.toPx())); drawArc(Cyan, -210f, 230f, false, style = Stroke(4.dp.toPx(), cap = StrokeCap.Round)); drawLine(Color.White, Offset(size.width/2,size.height/2), Offset(size.width*.72f,size.height*.3f), 2.dp.toPx()) }
                    Text("N", color = Color.White, fontSize = 17.sp)
                }
                Spacer(Modifier.width(20.dp)); Column { Text("SYSTEM ONLINE", color = Cyan, fontSize = 9.sp, letterSpacing = 1.sp); Text("084", color = Color.White, fontSize = 35.sp, fontWeight = FontWeight.Light); Text("KM / H     •     GPS", color = Muted, fontSize = 9.sp) }
            }
            Demo.RING -> Box(Modifier.size(108.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    listOf(Violet, Cyan, Color(0xFFFF79C6)).forEachIndexed { i, c -> drawArc(c, -90f + i*120f, 82f, false, style = Stroke(7.dp.toPx(), cap = StrokeCap.Round)) }
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) { Text("09:41", color = Color.White, fontSize = 21.sp); Text("FOCUS", color = Muted, fontSize = 8.sp, letterSpacing = 2.sp) }
            }
        }
    }
}
