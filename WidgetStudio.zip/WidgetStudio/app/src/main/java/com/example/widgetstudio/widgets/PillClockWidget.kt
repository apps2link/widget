package com.example.widgetstudio.widgets

import android.content.Context
import android.widget.RemoteViews
import androidx.compose.runtime.Composable
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.GlanceTheme
import androidx.glance.ImageProvider
import androidx.glance.LocalContext
import androidx.glance.action.clickable
import androidx.glance.appwidget.AndroidRemoteViews
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxHeight
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.padding
import androidx.glance.layout.size
import androidx.glance.layout.width
import androidx.compose.ui.unit.dp
import com.example.widgetstudio.MainActivity
import com.example.widgetstudio.R

/**
 * Dark glass pill clock: beige pill (day, hours, date) + black circle (minutes).
 * Time text is rendered by platform TextClock views, so it ticks by itself
 * with no work from the app (no alarms, no WorkManager).
 */
class PillClockWidget : GlanceAppWidget() {
    override val sizeMode = SizeMode.Exact

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        provideContent { GlanceTheme { PillClockContent() } }
    }
}

class PillClockReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = PillClockWidget()
}

@Composable
private fun PillClockContent() {
    val context = LocalContext.current
    Box(
        modifier = GlanceModifier
            .fillMaxSize()
            .background(ImageProvider(R.drawable.bg_pill_glass_dark))
            .clickable(actionStartActivity<MainActivity>()),
        contentAlignment = Alignment.CenterStart
    ) {
        Row(
            modifier = GlanceModifier.fillMaxSize().padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = GlanceModifier
                    .defaultWeight()
                    .fillMaxHeight()
                    .background(ImageProvider(R.drawable.bg_pill_beige)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    AndroidRemoteViews(RemoteViews(context.packageName, R.layout.clock_day))
                    AndroidRemoteViews(RemoteViews(context.packageName, R.layout.clock_hours))
                    AndroidRemoteViews(RemoteViews(context.packageName, R.layout.clock_date))
                }
            }
            Spacer(GlanceModifier.width(8.dp))
            Box(
                modifier = GlanceModifier
                    .size(96.dp)
                    .background(ImageProvider(R.drawable.bg_circle_black)),
                contentAlignment = Alignment.Center
            ) {
                AndroidRemoteViews(RemoteViews(context.packageName, R.layout.clock_minutes))
            }
        }
    }
}
